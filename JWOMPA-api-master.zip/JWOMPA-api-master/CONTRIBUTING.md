# Larapi Contribution Guide

All bugs and feature requests should be opened as an issue in the repository.