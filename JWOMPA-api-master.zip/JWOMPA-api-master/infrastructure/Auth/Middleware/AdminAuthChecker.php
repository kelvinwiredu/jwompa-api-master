<?php

namespace Infrastructure\Auth\Middleware;

use Closure;
use Auth;
use Illuminate\Foundation\Application;
use Illuminate\Auth\Middleware\Authenticate;
use Illuminate\Auth\AuthenticationException;
use Symfony\Component\HttpKernel\Exception\UnauthorizedHttpException;

class AdminAuthChecker
{
    private $app;

    private $oAuthMiddleware;

    public function __construct(
        Application $app,
        Authenticate $authenticate
    ) {
        $this->app = $app;
        $this->authenticate = $authenticate;
    }

    public function handle($request, Closure $next)
    {

        $url = url()->current();
        $pos = strpos($url,"admin/login");
        if ($pos) {
            return $next($request);
        }

        if (Auth::guard('admin')->user()) {
            return $next($request);
        }
        else {
            return View('admin.users.login');
        }

    }
}
