<?php

namespace Infrastructure\Auth;

use Illuminate\Foundation\Application;
use Infrastructure\Auth\Exceptions\InvalidCredentialsException;
use Api\Users\Repositories\UserRepository;
use Api\Master\Models\UserDevice;
use Carbon\Carbon;
use Auth;

class LoginProxy
{
    const REFRESH_TOKEN = 'refreshToken';

    private $apiConsumer;

    private $auth;

    private $cookie;

    private $db;

    private $request;

    private $userRepository;

    public function __construct(Application $app, UserRepository $userRepository) {
        $this->userRepository = $userRepository;

        $this->apiConsumer = $app->make('apiconsumer');
        $this->auth = $app->make('auth');
        $this->cookie = $app->make('cookie');
        $this->db = $app->make('db');
        $this->request = $app->make('request');
    }

    /**
     * Attempt to create an access token using user credentials
     *
     * @param string $email
     * @param string $password
     */
    public function attemptLogin($email, $password)
    {
        $user = $this->userRepository->getWhere('email', $email)->first();

        if (!is_null($user)) {

            if ($user->status != 1) {
                throw new InvalidCredentialsException();
            }

            return $this->proxy('password', [
                'username' => $email,
                'password' => $password,
            ]);
        }

        throw new InvalidCredentialsException();
    }

    public function register ($params) {
        $response = $this->userRepository->register($params);
        return $response;
    }

    public function googlelogin ($params) {
        $user = $this->userRepository->getGoogleLogin($params['email']);
        if (!$user) {
            $user = $this->userRepository->saveGoogleLogin($params);
        }
        $token = $user->createToken('Token')->accessToken;
        $user->last_logged_in = Carbon::now();
        $user->update();
        return [ 
            'access_token' => $token,
            'expires_in' => 864000,
            'user' => $user
        ];
    }

    public function fblogin ($params) {
        $user = $this->userRepository->getFBLogin($params['fb_id']);
        if (!$user) {
            $user = $this->userRepository->fblogin($params);
        }
        $token = $user->createToken('Token')->accessToken;
        $user->last_logged_in = Carbon::now();
        $user->update();
        return [ 
            'access_token' => $token,
            'expires_in' => 864000,
            'user' => $user
        ];
    }

    /**
     * Attempt to refresh the access token used a refresh token that 
     * has been saved in a cookie
     */
    public function attemptRefresh()
    {
        $refreshToken = $this->request->cookie(self::REFRESH_TOKEN);

        return $this->proxy('refresh_token', [
            'refresh_token' => $refreshToken
        ]);
    }

    /**
     * Proxy a request to the OAuth server.
     * 
     * @param string $grantType what type of grant type should be proxied
     * @param array $data the data to send to the server
     */
    public function proxy($grantType, array $data = [])
    {
        $client_id = 4;
        $client_secret = 'p3SCXI3nYtl7jMhyZ232vDQrIyXjnJyDIrYT9zuU';
        $email = $data['username'];
        $data = array_merge($data, [
            'client_id'     => $client_id,
            'client_secret' => $client_secret,
            'grant_type'    => $grantType
        ]);

        $response = $this->apiConsumer->post('/oauth/token', $data);

        if (!$response->isSuccessful()) {
            throw new InvalidCredentialsException();
        }

        $data = json_decode($response->getContent());

        $user = $this->userRepository->getModel()->select('id','email','password','first_name','last_name','country','currentcountry','email','fb_id','gplus_id','auth_level','mobile','gender','dob','profile_image','language','date_registered','last_logged_in','status')->where('email',$email)->first();
        $user->last_logged_in = Carbon::now();
        $user->update();

        // Create a refresh token cookie
        $this->cookie->queue(
            self::REFRESH_TOKEN,
            $data->refresh_token,
            864000, // 10 days
            null,
            null,
            false,
            true // HttpOnly
        );



        return [
            'access_token' => $data->access_token,
            'expires_in' => $data->expires_in,
            'user' => $user,
        ];
    }

    public function forgotPassword ($params) {
        $response = $this->userRepository->forgotPassword($params);
        return $response;
    }

    public function verifyOTP ($params) {
        return $this->userRepository->verifyOTP($params);
    }

    public function newPassword ($params) {
        return $this->userRepository->newPassword($params);
    }

    /**
     * Logs out the user. We revoke access token and refresh token. 
     * Also instruct the client to forget the refresh cookie.
     */
    public function logout()
    {
        $user_id = Auth::id();
        UserDevice::where('user_id',$user_id)->delete();
        $accessToken = $this->auth->user()->token();

        $refreshToken = $this->db
            ->table('oauth_refresh_tokens')
            ->where('access_token_id', $accessToken->id)
            ->update([
                'revoked' => true
            ]);

        $accessToken->revoke();

        $this->cookie->queue($this->cookie->forget(self::REFRESH_TOKEN));
    }
}
