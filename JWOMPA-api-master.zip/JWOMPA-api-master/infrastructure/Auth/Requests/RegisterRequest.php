<?php

namespace Infrastructure\Auth\Requests;

use Infrastructure\Http\ApiRequest;

class RegisterRequest extends ApiRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'email' => 'required|email',
            'password' => 'required',
            'first_name' => 'required',
            'last_name' => 'required',
            'dob' => 'required',
            'country' => 'required',
            'language' => 'nullable',
            'mobile' => 'nullable',
            'gender'  => 'nullable'
        ];
    }
}
