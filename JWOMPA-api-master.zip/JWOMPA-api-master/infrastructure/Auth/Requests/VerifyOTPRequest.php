<?php

namespace Infrastructure\Auth\Requests;

use Infrastructure\Http\ApiRequest;

class VerifyOTPRequest extends ApiRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'id' => 'required',
            'password_reset_code' => 'required'
        ];
    }
}
