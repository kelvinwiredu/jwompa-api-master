<?php

namespace Infrastructure\Auth\Requests;

use Infrastructure\Http\ApiRequest;

class FBLoginRequest extends ApiRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'email'    => 'nullable|email',
            'fb_id' => 'required',
            'first_name' => 'required',
            'last_name' => 'required',
            'country' => 'nullable',
            'mobile' => 'nullable',
            'gender' => 'nullable',
            'dob' => 'nullable',
            'language' => 'nullable'
        ];
    }
}
