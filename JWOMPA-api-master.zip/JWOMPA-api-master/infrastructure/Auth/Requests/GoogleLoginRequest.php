<?php

namespace Infrastructure\Auth\Requests;

use Infrastructure\Http\ApiRequest;

class GoogleLoginRequest extends ApiRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'email'    => 'required|email',
            'gplus_id' => 'required',
            'first_name' => 'required',
            'last_name' => 'required',
            'country' => 'nullable',
            'mobile' => 'nullable',
            'gender' => 'nullable',
            'dob' => 'nullable',
            'language' => 'nullable'
        ];
    }
}
