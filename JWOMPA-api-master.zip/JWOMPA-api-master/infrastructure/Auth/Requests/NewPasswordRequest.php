<?php

namespace Infrastructure\Auth\Requests;

use Infrastructure\Http\ApiRequest;

class NewPasswordRequest extends ApiRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'id' => 'required',
            'password' => 'required'
        ];
    }
}
