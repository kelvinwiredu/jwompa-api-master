<?php
$router->group(['prefix' => config('routes.identity_prefix')], function () use($router){
	$router->post('/logout', 'LoginController@logout');
});