<?php

namespace Infrastructure\Auth\Controllers;

use Illuminate\Http\Request;
use Infrastructure\Auth\LoginProxy;
use Infrastructure\Auth\Requests\LoginRequest;
use Infrastructure\Auth\Requests\GoogleLoginRequest;
use Infrastructure\Auth\Requests\FBLoginRequest;
use Infrastructure\Auth\Requests\RegisterRequest;
use Infrastructure\Auth\Requests\ForgotPasswordRequest;
use Infrastructure\Auth\Requests\VerifyOTPRequest;
use Infrastructure\Auth\Requests\NewPasswordRequest;
use Infrastructure\Http\Controller;
use Api\Users\Repositories\UserRepository;
use DB;
use Auth;
use Validator;

class LoginController extends Controller
{
    private $loginProxy;

    public function __construct(LoginProxy $loginProxy)
    {
        $this->loginProxy = $loginProxy;
    }

    public function register (RegisterRequest $request) {
        $params = $request->all();
        $response = $this->loginProxy->register($params);
        return response($response);
    }

    public function login(LoginRequest $request)
    {
        $email = $request->get('email');
        $password = $request->get('password');

        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'password' => 'required'
        ]);
        if($validator->errors()->all()) {
            $data['status_code']    =   0;
            $data['status_text']    =   'Failed';
            $data['message']        =   $validator->errors()->first();
        }
        else {
            $response = $this->loginProxy->attemptLogin($email, $password);
            $data['status_code']    =   1;
            $data['status_text']    =   'Logged In Successfully';
            $data['access_token']   =   $response['access_token'];
            $data['expires_in']     =   $response['expires_in'];
            $data['user_data']      =   $response['user'];
        }

        return response($data);
    }

    public function googlelogin (GoogleLoginRequest $request) {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'gplus_id' => 'required',
            'first_name' => 'required',
            'last_name' => 'required'
        ]);
        if($validator->errors()->all()) {
            $data['status_code']    =   0;
            $data['status_text']    =   'Failed';
            $data['message']        =   $validator->errors()->first();
        }
        else {
            $params = $request->all();
            $response = $this->loginProxy->googlelogin($params);
            $data['status_code']    =   1;
            $data['status_text']    =   'Logged In Successfully';
            $data['access_token']   =   $response['access_token'];
            $data['expires_in']     =   $response['expires_in'];
            $data['user_data']      =   $response['user'];
        }
        return $data;
    }

    public function fblogin (FBLoginRequest $request) {
        $validator = Validator::make($request->all(), [
            'fb_id' => 'required',
            'first_name' => 'required',
            'last_name' => 'required'
        ]);
        if($validator->errors()->all()) {
            $data['status_code']    =   0;
            $data['status_text']    =   'Failed';
            $data['message']        =   $validator->errors()->first();
        }
        else {
            $params = $request->all();
            $response = $this->loginProxy->fblogin($params);
            $data['status_code']    =   1;
            $data['status_text']    =   'Logged In Successfully';
            $data['access_token']   =   $response['access_token'];
            $data['expires_in']     =   $response['expires_in'];
            $data['user_data']      =   $response['user'];
        }
        return $data;
    }

    public function forgotPassword (ForgotPasswordRequest $request) {
        $params = $request->all();
        $response = $this->loginProxy->forgotPassword($params);
        return response($response);
    }

    public function verifyOTP (VerifyOTPRequest $request) {
        $params = $request->all();
        $response = $this->loginProxy->verifyOTP($params);
        return response($response);
    }

    public function newPassword (NewPasswordRequest $request) {
        $params = $request->all();
        $response = $this->loginProxy->newPassword($params);
        return response($response);
    }

    public function refresh(Request $request)
    {
        return $this->response($this->loginProxy->attemptRefresh());
    }

    public function logout()
    {
        $this->loginProxy->logout();
        $data['status_code']    =   1;
        $data['status_text']    =   'Success';
        $data['message']        =   'Logged Out Successfully';
        return $this->response($data, 200);
    }

    public function protest () {
        return Auth::user();
    }
}