<?php

$router->group(['prefix' => config('routes.identity_prefix')], function () use($router){
	$router->post('/register','LoginController@register');
	$router->post('/login', 'LoginController@login');
	$router->post('/login/refresh', 'LoginController@refresh');
	$router->post('/googlelogin','LoginController@googlelogin');
	$router->post('/fblogin','LoginController@fblogin');
	$router->post('/forgotpassword','LoginController@forgotPassword');
	$router->post('/verifyotp','LoginController@verifyOTP');
	$router->post('/newpassword','LoginController@newPassword');
});