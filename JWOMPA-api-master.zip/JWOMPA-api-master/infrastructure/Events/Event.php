<?php

namespace Infrastructure\Events;

abstract class Event
{
    //
}
