<?php

namespace Infrastructure\Database\Eloquent;

use Optimus\Genie\Repository as BaseRepository;

abstract class Repository extends BaseRepository
{
}
