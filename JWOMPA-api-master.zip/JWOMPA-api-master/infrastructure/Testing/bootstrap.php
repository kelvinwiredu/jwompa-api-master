<?php

require_once __DIR__ . '/../../bootstrap/autoload.php';

// bootstrap testing, e.g. seeding database etc.
