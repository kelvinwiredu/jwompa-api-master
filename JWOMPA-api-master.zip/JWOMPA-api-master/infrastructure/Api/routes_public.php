<?php

$router->get('/', 'DefaultApiController@index');