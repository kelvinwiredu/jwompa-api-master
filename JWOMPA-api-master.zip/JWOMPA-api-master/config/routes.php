<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Prefixes Used in Routes
    |--------------------------------------------------------------------------
    */

    'api_prefix' => 'api',

    'application_prefix' => 'application',

    'identity_prefix' => 'auth',

    'admin_prefix' => 'admin',
];