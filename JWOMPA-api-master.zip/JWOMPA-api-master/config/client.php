<?php

return [
    'clientId' => '38be6f938ab09a49c85fac7dc31cb37a',
    'clientSecret' => 'a6ff03d0d042d5921df9d1dae174a520',
    'callback' => 'http://127.0.0.1/jwompa/public/admin/searchSong',
    'userid'   => '202521994',
    'username'   => 'jwompa',
    'email' => 'jwompa@gmail.com',
    'password' => 'jwompa123',
    'no_of_records' => '50',
    'BASE_URL' => 'http://34.235.210.58/jwompa/public/',
];
