<?php

return [
    'driver' => env('FCM_PROTOCOL', 'http'),
    'log_enabled' => false,

    'http' => [
        'server_key' => env('FCM_SERVER_KEY', 'AAAAeYszgog:APA91bEpSfZp0MOmeYS4klFfzJNOH6ByFR4Rlt2gIqBH_slIwMONgN9QrJXMgYhJliwNp3n7ygTqPSfmYncGvbsB2Ch89We1-2WAUV1vUFuAvSuWrheqYqztGYewPzRrmEnujkIHrfWY'),
        'sender_id' => env('FCM_SENDER_ID', '522026451592'),
        'server_send_url' => 'https://fcm.googleapis.com/fcm/send',
        'server_group_url' => 'https://android.googleapis.com/gcm/notification',
        'timeout' => 30.0, // in second
    ],
];
