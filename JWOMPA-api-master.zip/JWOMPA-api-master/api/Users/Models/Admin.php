<?php

namespace Api\Users\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;

class Admin extends Authenticatable
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = 'users';
    public $timestamps = false;
     
   
    protected $fillable = [
        'username','fb_id','gplus_id', 'email','country', 'password', 'first_name','last_name', 'mobile', 'dob','profile_image',
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];
    
    public function usern()
    {
        return $this->belongsTo('Api\Users\Models\Admin', 'user_id');
    }
    
      public function is_admin()
      {
    	 $role = $this->role_id;
    	 if($role == 1)
    	 {
    	   return true;
    	 }
    	 return false;
     }

     public function getAuthPassword()
    {
         return $this->password;
    }

    
}
