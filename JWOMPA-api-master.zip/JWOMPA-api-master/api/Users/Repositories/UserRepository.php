<?php

namespace Api\Users\Repositories;

use Api\Users\Models\User;
use Api\Master\Models\LoginRecovery;
use Infrastructure\Database\Eloquent\Repository;

use Carbon\Carbon;
use DB;
use Mail;

class UserRepository extends Repository
{
    public function getModel()
    {
        return new User();
    }

    public function create(array $data)
    {
        $user = $this->getModel();

        $data['password'] = password_hash($data['password'], PASSWORD_BCRYPT);

        $user->fill($data);
        $user->save();

        return $user;
    }

    public function update(User $user, array $data)
    {
        $user->fill($data);

        $user->save();

        return $user;
    }

    public function getGoogleLogin($email) {
        $user = $this->getModel()->where('email', $email)->where('gplus_id','!=',0)->where('auth_level',2)->where('status',1)->first();
        return $user;
    }

    public function getFBLogin ($fb_id) {
        $user = $this->getModel()->where('fb_id',$fb_id)->where('auth_level',2)->where('status',1)->first();
        return $user;
    }

    public function saveGoogleLogin ($params) {
        $user = $this->getModel();
        $user->email            =   $params['email'];
        $user->gplus_id         =   $params['gplus_id'];
        $user->first_name       =   $params['first_name'];
        $user->last_name        =   $params['last_name'];
        $user->country          =   (array_key_exists('country', $params))?$params['country']:'';
        $user->mobile           =   (array_key_exists('mobile', $params))?$params['mobile']:'';
        $user->gender           =   (array_key_exists('gender', $params))?$params['gender']:'';
        $user->dob              =   (array_key_exists('dob', $params))?$params['dob']:'0000-00-00';
        $user->language         =   (array_key_exists('language', $params))?$params['language']:'';
        $user->save();
        return $user;
    }

    public function fblogin ($params) {
        $user = $this->getModel();
        $user->email            =   (array_key_exists('email', $params))?$params['email']:'';
        $user->fb_id            =   $params['fb_id'];
        $user->first_name       =   $params['first_name'];
        $user->last_name        =   $params['last_name'];
        $user->country          =   (array_key_exists('country', $params))?$params['country']:'';
        $user->mobile           =   (array_key_exists('mobile', $params))?$params['mobile']:'';
        $user->gender           =   (array_key_exists('gender', $params))?$params['gender']:'';
        $user->dob              =   (array_key_exists('dob', $params))?$params['dob']:'';
        $user->language         =   (array_key_exists('language', $params))?$params['language']:'';
        $user->save();
        return $user;
    }

    public function register ($params) {

        $user = $this->getModel()->where('email',$params['email'])->first();
        if ($user) {
            $data['status_code']    =   0;
            $data['status_text']    =   'Failed';             
            $data['message']        =   'The email has already been taken.'; 
        }
        else
        {
            $user = $this->getModel();
            $user->email            =   $params['email'];
            $user->first_name       =   $params['first_name'];
            $user->last_name        =   $params['last_name'];
            $user->password         =   bcrypt($params['password']);
            $user->dob              =   $params['dob'];
            $user->country          =   $params['country'];
            $user->language         =   (array_key_exists('language', $params))?$params['language']:'';
            $user->mobile           =   (array_key_exists('mobile', $params))?$params['mobile']:'';
            $user->gender           =   (array_key_exists('gender', $params))?$params['gender']:'';
            $user->save();
            $data['status_code']    =   1;
            $data['status_text']    =   'Success';
            $data['message']        =   'User has been created successfully';
            $data['user_id']        =   $user->id;
        }
        return $data;
    }

    public function forgotPassword ($params) {
        $mail = $params['email'];
        $user = $this->getModel()->where('email',$mail)->whereNotNull('password')->first();
        if ($user) {
            $LR = LoginRecovery::where('user_id',$user->id)->first();
            if ($LR) {
                $LR->otp                =   rand(100000,999999);
                $LR->token              =   $this->rand_string(10);
                $LR->expiry_time        =   Carbon::now()->addMinutes(5);
                $LR->update();
            }
            else {
                $LR = new LoginRecovery;
                $LR->user_id            =   $user->id;
                $LR->otp                =   rand(100000,999999);
                $LR->token              =   $this->rand_string(10);
                $LR->expiry_time        =   Carbon::now()->addMinutes(5);
                $LR->save();
            }

            $mail = DB::table('mails')->where('id', '11')->first();
            $email = $user->email;
            $emailData = array(
                'to'        => $email, 
                'from'      => 'jwompa.fekadu@gmail.com',
                'subject'   => $mail->subject,
                'view'      => 'admin.mail.forgotpassword',
                'six_digit_random_number'   => $LR->otp,
            );      
            Mail::send($emailData['view'], $emailData, function ($message) use ($emailData) {
                $message
                    ->to($emailData['to'])
                    ->from($emailData['from'])
                    ->subject($emailData['subject']);
            });

            $data['status_code']    =   1;
            $data['status_text']    =   'Success';
            $data['message']        =   'Your new otp sent on your email address.';
            $data['id']             =   $user->id;
        }
        else {
            $data['status_code']    =   0;
            $data['status_text']    =   'Failed';
            $data['message']        =   'Invalid Email address.';
        }
        return $data;
    }

    public function verifyOTP($params) {
        $id = $params['id'];
        $password_reset_code = $params['password_reset_code'];
        $LR = LoginRecovery::where('user_id',$id)->where('otp',$password_reset_code)->first();
        if ($LR) {
            $now = Carbon::now();
            if ($now > $LR->expiry_time) {
                $data['status_code']    =   0;
                $data['status_text']    =   'Failed';
                $data['message']        =   'Otp expired';
            }
            else {
                $data['status_code']    =   1;
                $data['status_text']    =   'Success';
                $data['message']        =   'Otp matches successfully';
                $data['user_id']        =   $LR->user_id;
            }
        }
        else {
            $data['status_code']    =   0;
            $data['status_text']    =   'Failed';
            $data['message']        =   'Invalid Otp';
        }

        return $data;
    }

    public function newPassword ($params) {
        $id = $params['id'];
        $password = $params['password'];
        $USER = $this->getModel()->where('id',$id)->first();
        if ($USER) {
            $USER->password         =   bcrypt($password);
            $USER->update();
            $data['status_code']    =   1;
            $data['status_text']    =   'Success';
            $data['message']        =   'Password changed successfully.';
            $data['user_id']        =   $USER->id;
        }
        else {
            $data['status_code']    =   0;
            $data['status_text']    =   'Failed';
            $data['message']        =   'Invalid user id';
        }
        return $data;
    }

    public function rand_string( $length ) 
    {
        $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        $str = '';
        $size = strlen( $chars );
        for( $i = 0; $i < $length; $i++ ) 
        {
            $str .= $chars[ rand( 0, $size - 1 ) ];
        }
        return $str;
    }
}
