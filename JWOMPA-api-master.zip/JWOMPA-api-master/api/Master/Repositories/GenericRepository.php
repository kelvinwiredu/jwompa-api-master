<?php

namespace Api\Master\Repositories;

use Api\Master\Models\User;
use Infrastructure\Database\Eloquent\Repository;

class GenericRepository extends Repository
{
    private function getUserModel ()
    {
        return new User();
    }

}
