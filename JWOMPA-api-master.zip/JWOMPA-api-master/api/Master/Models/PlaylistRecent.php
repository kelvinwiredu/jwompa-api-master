<?php

namespace Api\Master\Models;

use Illuminate\Database\Eloquent\Model;

class PlaylistRecent extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = 'playlist_recents' ;
     


    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        
    ];   
}