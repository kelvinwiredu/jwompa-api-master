<?php

namespace Api\Master\Models;

use Illuminate\Database\Eloquent\Model;

class Setting extends Model
{
    protected $table = 'settings';
    protected $fillable = ['sitename','siteemail','sitephone','meta_keyword','meta_description'];

}
