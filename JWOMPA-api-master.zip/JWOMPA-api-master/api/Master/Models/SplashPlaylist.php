<?php

namespace Api\Master\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;

class SplashPlaylist extends Authenticatable
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = 'splash_playlists' ;
     
   
    protected $fillable = [
        'playlist_name','playlist_id','sort_priority'
    ];
    
    public function ffavorite()
    {
        return $this->hasMany('App\PlaylistFavorite', 'playlist_id');
    }
    
    public function users()
    {
        return $this->hasMany('App\Users', 'user_id');
    }

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
       
    ];
    
    
    
      

    
}
