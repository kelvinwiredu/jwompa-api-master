<?php

namespace Api\Master\Models;

use Illuminate\Database\Eloquent\Model;

class ParentCategory extends Model
{
    protected $table = 'parent_category';
    protected $fillable = ['id','pcat_name','status'];

}
