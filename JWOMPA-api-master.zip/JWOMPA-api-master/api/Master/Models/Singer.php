<?php

namespace Api\Master\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;

class Singer extends Authenticatable
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = 'singers' ;
     
   
    protected $fillable = [
        'name',  'status',
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
       
    ];
    
    
    
      

    
}
