<?php

namespace Api\Master\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;

class ParentCategories extends Authenticatable
{
    /**
     * The attributes that are mass assignable. 
     *
     * @var array
     */
    protected $table = 'parent_category' ;
    

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
       
    ];

}
