<?php

namespace Api\Master\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class PlaylistTracks extends Model
{
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'playlist_track_ids';
    public $timestamps = false;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        
    ];

    protected $appends = [
        'streamable',
    ];

    public function getStreamableAttribute () {
        return true;
    }
}
