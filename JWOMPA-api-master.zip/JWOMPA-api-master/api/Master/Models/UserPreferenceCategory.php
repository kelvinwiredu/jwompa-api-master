<?php

namespace Api\Master\Models;

use Illuminate\Database\Eloquent\Model;

class UserPreferenceCategory extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = 'user_preference_categories' ;
    public $timestamps = false;


    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
       'id','created_at,'
    ];
    
    
    
      

    
}
