<?php

namespace Api\Master\Models;

use Illuminate\Database\Eloquent\Model;

class SkipSong extends Model
{
    protected $table = 'skip_song';
    protected $fillable = ['track_id','track_title','playlist_id','playlist_title','user_id'];

}
