<?php

namespace Api\Master\Models;

use Illuminate\Database\Eloquent\Model;

class LoginDetail extends Model
{
    protected $table = 'login_details';
    protected $fillable = ['id','user_id','status','time_duration','logout_time','created_at','updated_at'];
}
