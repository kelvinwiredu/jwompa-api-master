<?php

namespace Api\Master\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;

class TrackRate extends Authenticatable
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = 'track_ratings' ;
     
   
    protected $fillable = [
        'track_id','user_id','rating','track_title'
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
       
    ];
    
    
    
      

    
}
