<?php

namespace Api\Master\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = 'users';
    public $timestamps = false;
     
   
    protected $fillable = [
        'first_name','last_name', 'email', 'fb_id','gplus_id','country', 'password', 'mobile', 'dob','profile_image', 'gender', 'status', 'currentcountry' , 'language'
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];
    
    public function usern()
    {
        return $this->belongsTo('App\User', 'user_id');
    }
    
      public function is_admin()
      {
    	 $role = $this->role_id;
    	 if($role == 1)
    	 {
    	   return true;
    	 }
    	 return false;
     }

     public function getAuthPassword()
    {
         return $this->password;
    }

    
}
