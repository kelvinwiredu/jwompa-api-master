<?php

namespace Api\Master\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;

class TrackRatings extends Authenticatable
{
    /**
     * The attributes that are mass assignable. 
     *
     * @var array
     */
    protected $table = 'track_ratings' ;
    

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
       
    ];

}
