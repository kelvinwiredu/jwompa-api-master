<?php

namespace Api\Master\Models;

use Illuminate\Database\Eloquent\Model;

class LanguageMaster extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = 'language_master' ;
     
   
    protected $fillable = [

    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
       
    ];
    
    
    
      

    
}
