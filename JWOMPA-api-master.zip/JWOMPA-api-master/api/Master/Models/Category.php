<?php

namespace Api\Master\Models;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = 'categories' ;
     
   
    protected $fillable = [
        'name', 'pcat_name', 'description', 'status',
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
       
    ];
    
    public function categoryPlaylist()
    {
        return $this->hasMany('CategoryPlaylist', 'category_id');
    }
    
      

    
}
