<?php

namespace Api\Master\Models;

use Illuminate\Database\Eloquent\Model;

class CategoryPlaylist extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = 'category_playlists' ;
     
   
    protected $fillable = [
        'playlist_name',  'category_id','playlist_id'
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
       
    ];
    
  public function category()
  {
    return $this->belongsTo('App\Master\Models\Category', 'category_id');
  }
    
      

    
}
