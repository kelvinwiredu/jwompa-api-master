<?php

namespace Api\Master\Models;

use Illuminate\Database\Eloquent\Model;

class ListenSong extends Model
{
    protected $table = 'listen_song';
    protected $fillable = ['playlist_id','playlist_title','no_of_listen','track_id','track_title','user_id','status'];

}
