<?php

namespace Api\Master\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;

class PlayListFavorite extends Authenticatable
{
    /**
     * The attributes that are mass assignable. 
     *
     * @var array
     */
    protected $table = 'playlist_favorites' ;
     
   
    protected $fillable = [
        'user_id',  'playlist_id','status','no_of_favorites'
    ];
    
    public function user()
    {
        return $this->belongsTo('App\User');
    }
    

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
       
    ];
    
    
    
    
}
