<?php
$router->group(['prefix' => config('routes.api_prefix')], function () use($router){
	
});