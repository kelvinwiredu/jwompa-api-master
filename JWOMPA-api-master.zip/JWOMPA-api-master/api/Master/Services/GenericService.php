<?php

namespace Api\Master\Services;

use Exception;
use Illuminate\Auth\AuthManager;
use Illuminate\Database\DatabaseManager;
use Api\Master\Repositories\GenericRepository;

class GenericService
{
    private $auth;

    private $database;

    private $dispatcher;

    private $genericRepository;

    public function __construct(
        AuthManager $auth,
        DatabaseManager $database,
        Dispatcher $dispatcher,
        GenericRepository $genericRepository
    ) {
        $this->auth = $auth;
        $this->database = $database;
        $this->dispatcher = $dispatcher;
        $this->genericRepository = $genericRepository;
    }

    public function getPlayList () {
        return $this->genericRepository->getPlayList();
    }

    
}
