<?php

namespace Api\Web\Controllers;

use Api\Master\Models\User;
use DB;
use Api\Master\Models\CategoryPlaylist;
use Api\Master\Models\Playlists;
use Api\Master\Models\SplashPlaylist;
use Api\Master\Models\ParentCategory;
use Api\Master\Models\Categories;
use Api\Master\Models\UserDevice;
use Auth;
use Redirect;
use Validator;
use Hash;
use Carbon\Carbon;
use Storage;
use Infrastructure\Http\Controller;
use App\Classes\Services_Soundcloud;
use Njasm\Soundcloud\SoundcloudFacade;
// or soundcloud if you don't need a facade for specific tasks
use Njasm\Soundcloud\Soundcloud;
use Illuminate\Http\Request;
use Illuminate\Pagination\Paginator;
use Illuminate\Pagination\LengthAwarePaginator;
use Api\Mobile\Repositories\GenericRepository;

class PlaylistController extends Controller
{
   
  /* ********************* add playlist ******************** */
    public function create()
    {	
    	$category = ParentCategory::where('status' , 1)->select('id','pcat_name')->get();
    	
        return view('admin.playlist.create',compact('category'));
    }
    
    public function add(Request $request)
    {
    	$validator = Validator::make($request->all(), [
            'playlist_name' => 'required|string|min:2|unique:categories',
            'playlist_length' => 'required|numeric',
            //'image_url' => 'required|file',
            'playlist_description' => 'required|string',
            'pcat_name' => 'required|numeric',
            'scat_name' => 'required|numeric',
            'version' => 'required|numeric',
            'note' => 'required|string',
        ]);
        if($validator->errors()->all()) {
            return \Redirect::back()->withErrors($validator->errors()->first());
        }

        /*if (!$request->file('image_url')) {
        	return \Redirect::back()->withErrors( 'Please Upload Cover Image' );
        }*/

        $input = $request->all();
        $PL = new Playlists;
        $image = $request->file('image_url');
        if ($image) {
        	$image_full_name = $image->getClientOriginalName();
	        $image_name = explode('.', $image_full_name)[0];
          $image_name = str_replace(" ","_",$image_name);
	        $image_ext = explode( '.', $image_full_name)[1];
	        $now = Carbon::now();
	        $date_string = $now->year.$now->month.$now->day.$now->hour.$now->minute.$now->second;
	        $file_name = $image_name.$date_string;
	        $cover_img_link = Storage::disk('playlist_cover')->put($file_name, $image);
	        $PL->cover_img_link 		= 	config('client.BASE_URL').'playlist_cover/'.$cover_img_link;
        }

        $PL->name 					= 	$input['playlist_name'];
        $PL->length 				= 	$input['playlist_length'];
        $PL->creator_user_id 		= 	Auth::guard('admin')->id();
        $PL->description 			= 	$input['playlist_description'];
        $PL->time_created 			= 	Carbon::now();
        $PL->note 					= 	$input['note'];
        $PL->status 				= 	-1;
        $PL->version 				= 	$input['version'];
        $PL->save();

        $CP = new CategoryPlaylist;
        $CP->category_id 			= 	$input['scat_name'];
        $CP->playlist_id 			= 	$PL->id;
        $CP->save();
             
       return redirect('admin/displayPlaylist')->withSuccess( 'Playlist Created Successfully' );
       
       
    }
  

	  public function edit(Request $request, $id)
	  {
	  	$playlist = Playlists::select(DB::raw('playlists.*,parent_category.id as pcat_name,categories.id as scat_name,splash_playlists.id as sp_id'))->join('category_playlists', function ($join) {
                $join->on('category_playlists.playlist_id','=','playlists.id');
            })->join('categories', function ($join) {
                $join->on('categories.id','=','category_playlists.category_id');
            })->join('parent_category', function ($join) {
                $join->on('parent_category.id','=','categories.pcat_name');
            })->leftJoin('splash_playlists', function($join) {
                $join->on('splash_playlists.playlist_id','=','playlists.id');
            })->findOrFail($id);
	  	$category = ParentCategory::where('status' , 1)->select('id','pcat_name')->get();
		return view('admin.playlist.edit',compact('playlist','category'));
	  }
		
	public function update(Request $request, $id) { 

		$input = $request->all();
        $PL = Playlists::where('id',$input['playlist_id'])->first();
        if(!$PL)
        	return \Redirect::back()->withErrors( 'Playlist Not Found' );
		$validator = Validator::make($request->all(), [
            'playlist_name' => 'required|string',
            'playlist_length' => 'required|numeric',
            'splashboard' => 'required|numeric',
            'playlist_description' => 'required|string',
            'pcat_name' => 'required|numeric',
            'scat_name' => 'required|numeric',
            'version' => 'required|numeric',
            'note' => 'required|string',
        ]);

        if($validator->errors()->all()) {
            return \Redirect::back()->withErrors($validator->errors()->first());
        }

        if (!$request->file('image_url') && !$PL->cover_img_link) {
        	return \Redirect::back()->withErrors( 'Please Upload Cover Image' );
        }
        
        $image = $request->file('image_url');
        if ($image) {
        	$image_full_name = $image->getClientOriginalName();
	        $image_name = explode('.', $image_full_name)[0];
          $image_name = str_replace(" ","_",$image_name);
	        $image_ext = explode( '.', $image_full_name)[1];
	        $now = Carbon::now();
	        $date_string = $now->year.$now->month.$now->day.$now->hour.$now->minute.$now->second;
	        $file_name = $image_name.$date_string;
	        $cover_img_link = Storage::disk('playlist_cover')->put($file_name, $image);

	        $PL->cover_img_link 		= 	config('client.BASE_URL').'playlist_cover/'.$cover_img_link;
        }

        $PL->name 					= 	$input['playlist_name'];
        $PL->length 				= 	$input['playlist_length'];
        $PL->creator_user_id 		= 	Auth::guard('admin')->id();
        $PL->description 			= 	$input['playlist_description'];
        $PL->time_created 			= 	Carbon::now();
        $PL->note 					= 	$input['note'];
        $PL->status 				= 	1;
        $PL->version 				= 	$input['version'];
        $PL->update();

        CategoryPlaylist::where('playlist_id',$input['playlist_id'])->delete();
        $CP = new CategoryPlaylist;
        $CP->category_id 			= 	$input['scat_name'];
        $CP->playlist_id 			= 	$PL->id;
        $CP->save();

        if ($input['splashboard']) {
        	$SP = SplashPlaylist::select(DB::raw('max(sort_priority) as max'))->first();
    			$max = $SP->max;
    			$SP = SplashPlaylist::where('playlist_id',$input['playlist_id'])->first();
    			if (!$SP) {
    				$SP = new SplashPlaylist;
    				$SP->playlist_id  			= 	$input['playlist_id'];
    				$SP->sort_priority 			= 	$max+1;
    				$SP->save();
    			}
			
        }
        else {
          $SP = SplashPlaylist::where('playlist_id',$input['playlist_id'])->delete();
        }
     	return redirect('admin/displayGoLive')->withSuccess( 'Playlist Updated Successfully' );
    }
  /* ********************** display Playlist ******************* */    
 
   public function display()
   {
	   $user_id = \Auth::guard('admin')->user()->id;
	   $playlists = Playlists::select(DB::raw('playlists.*,categories.name as cat_name'))->join('category_playlists','category_playlists.playlist_id','=','playlists.id')->join('categories','categories.id','=','category_playlists.category_id')->orderBy('id','DESC')->get();

	   foreach ($playlists as $play) {
	   	$tracks = Playlists::select(DB::raw('playlists.id,(tracks.length) as total_listening_time'))->join('playlist_track_ids', function($join) {
		   		$join->on('playlists.id','=','playlist_track_ids.playlist_id');
		   })->join('tracks', function ($join) {
		   		$join->on('playlist_track_ids.track_id','=','tracks.id');
       })->where('playlists.id',$play['id'])->get();
      // $times = array($time1, $time2);
      $seconds = 0;
      foreach ($tracks as $timeListen)
      {
        $time = $timeListen->total_listening_time;
        // print_r($time);
        if(strpos($time, ':')){
          $time = $time;
        }else{
          $time = $time.':00';
        }
        list($minute,$second) = explode(':', $time);
        $hour = 00;
        $seconds += $hour*3600;
        $seconds += $minute*60;
        $seconds += $second;
      }
      $hours = floor($seconds/3600);
      $seconds -= $hours*3600;
      $minutes  = floor($seconds/60);
      $seconds -= $minutes*60;
      $varCheck = sprintf('%02d:%02d', $hours, $minutes);
	   	$play['total_listening_time'] = $varCheck;
	   }

      return view('admin.playlist.index',compact('playlists'));
   }

   /* ********************** display Go Live ******************* */

   public function displayGoLive () {
   		$user_id = \Auth::guard('admin')->user()->id;
	   $playlists = Playlists::select(DB::raw('playlists.*,categories.name as cat_name'))->join('category_playlists','category_playlists.playlist_id','=','playlists.id')->join('categories','categories.id','=','category_playlists.category_id')->orderBy('id','DESC')->paginate(config('client.no_of_records'));
     	return view('admin.golive.index',compact('playlists'));
   }

   public function changePlayListStatus($id, $status) {
   	$PL = Playlists::where('id',$id)->where('status','!=',$status)->first();
   	if($PL) {
   		if ($PL->status == 1) {
   			$now = Carbon::now();
		   	$end = Carbon::parse($PL->time_last_updated);
		   	$length = $end->diffInDays($now);
		   	$PL->live_duration = $PL->live_duration+$length;
   		}
   		$PL->status = $status;
   		$PL->time_last_updated = Carbon::now();
   		$PL->update();

   		if($PL->status != 1)
   			SplashPlaylist::where('playlist_id',$PL->id)->delete();
     	return redirect('admin/displayGoLive')->withSuccess( 'Playlist Updated Successfully' );
   	}
   	return redirect('admin/displayGoLive')->withErrors( 'Playlist Not Found' );
   }

   /* ********************** delete Playlist ******************* */    

   public function destroy($id)
   {
      DB::table('playlist_favorites')->where('playlist_id', $id)->delete();
      DB::table('playlist_recents')->where('playlist_id', $id)->delete();
      DB::table('playlist_track_ids')->where('playlist_id',$id)->delete();
      DB::table('splash_playlists')->where('playlist_id',$id)->delete();
      DB::table('skip_song')->where('playlist_id',$id)->delete();
      CategoryPlaylist::where('playlist_id',$id)->delete();
      $PL = Playlists::find($id);
      if(!$PL)
      	return \Redirect::back()->withErrors( 'Playlist Not Found' );

      $PL->cover_img_link = str_replace("playlist_cover/","",$PL->cover_img_link);
      if (Storage::disk('playlist_cover')->exists($PL->cover_img_link)) {
      	Storage::disk('playlist_cover')->delete($PL->cover_img_link);
      }
      $PL->delete();
      
      return redirect('admin/displayPlaylist')->withSuccess( 'Playlist Deleted Successfully' );	   
	   
   }
   /* ********************** View Playlist ******************* */     
   
   public function view($id)
   {   
	   $playlists = Playlist::findOrFail($id);
	   
	  /* $playlistSongs = DB::table('playlist_songs')
        ->leftJoin('tracks', 'playlist_songs.track_id', '=', 'tracks.id')
        ->leftJoin('play_lists', 'play_lists.id', '=', 'tracks.id')
        ->where('playlist_songs.playlist_id',$id)
        ->select('users.id', 'contacts.phone', 'orders.price')
        ->get(); */
        
        $playlistSongs = DB::table('play_lists')
        ->leftJoin('playlist_songs', 'play_lists.id', '=', 'playlist_songs.playlist_id')
        ->leftJoin('tracks', 'playlist_songs.track_id', '=', 'tracks.id')
        ->where('play_lists.id',$id)
        ->get();
	   
	  // $playlistSongs = DB::table('playlist_songs')->where('playlist_id',$id)->get();
	  echo '<pre>';
	  print_r($playlistSongs);
	  echo '</pre>';
	    die;
	   return view('admin.playlist.view',compact('playlists'));
   }
    
  /* **********************  addSondToPlayList  *************************** */
   public function addSoplay(Request $request)
    {  
	    $this->validate($request, [
        'catname' => 'required',
        'trackid' => 'required',
        ]);
       
       $input = array();
        
        $user_id = \Auth::user()->id;
		$tracks = DB::table('tracks')->where('track_id',$request->trackid)->first();
		
		if(!empty($tracks))
		{    
		  $tarck_id = $tracks->id;
		 
		}
		else
		{
			$tarck_id = DB::table('tracks')->insertGetId(['track_id' => $request->trackid, 'status' => 1]);
		}
		
		$playlists = DB::table('playlist_songs')->insertGetId(['track_id' => $tarck_id, 'playlist_id' => $request->catname, 'status' => 1]);
       
       return \Redirect::back()->withSuccess( 'Song Addedd To Playlist Successfully' );
    }
    
   /* ***********************   Admin Playlist ****************************** */
   
   public function myPlayList()
	  {
		  $clientId = config('client.clientId');
		  $clientSecret = config('client.clientSecret');
		  $callback = config('client.callback');
		  $client_userid = config('client.userid');
		  $client_username = config('client.username');
		  $url = 'http://api.soundcloud.com/users/'.$client_username.'/playlists/';
		  $soundcloud = new Services_Soundcloud($clientId, $clientSecret, $callback);
		  
		  $results = $soundcloud->get($url, array('q' => $query, 'limit' => '10'));
		  
		  //--- curl ----//

		  $Url = 'http://api.soundcloud.com/users/'.$client_username.'/playlists/?secret_token=s-ykwdd&client_id='.$clientId.'';
		  $ch = curl_init();
		  curl_setopt($ch, CURLOPT_URL, $Url);
		  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		  $data = curl_exec($ch);
		  curl_close($ch);
		  $api_content_array = json_decode($data, true);
		  
		  /*
		  $api_url =  'http://api.soundcloud.com/users/jwompa/playlists/?secret_token=s-ykwdd&client_id=38be6f938ab09a49c85fac7dc31cb37a';
		  $api_content = file_get_contents($api_url);
          $api_content_array = json_decode($api_content, true); */
          
         
          return view('admin.playlist.mylist',compact('api_content_array'));
      }
      
      public function categorystations(){
		  
		  $catstation_data = DB::table('cat_station')
            ->join('categories', 'categories.id', '=', 'cat_station.category_id')
            ->select('cat_station.*', 'categories.name')
            ->get();
            
            return view('admin.catstation.index',compact('catstation_data'));
		  
	  }
	  
	  public function deletecatstation($id){
		  
		  $deletecatstation = DB::table('cat_station')->where('id', '=', $id)->delete();
		  
		  return redirect('admin/categorystations')->withSuccess( 'Category Station Deleted Successfully.' );
	  }
	  
	  public function create_category_stations(){
		  
		 $input = array();
		 
		 $parent_category = DB::table('parent_category')->lists('pcat_name','id');
		 
		 $category = DB::table('categories')->lists('name','id');
		 
		 $first = DB::table('category_playlists')->select('playlist_name','playlist_id');

		 $playlist = DB::table('splash_playlists')
              ->union($first)->lists('playlist_name','playlist_id');
		
        return view('admin.catstation.create',compact('category','playlist','parent_category'));
	  }
	 
	  public function editCatStation($id){
		  
		  $cat_station = DB::table('cat_station')->where('id','=',$id)->first();
		  
		 $category = DB::table('categories')->get();
		 
		 if(!empty($category))
		{
		   foreach($category as $cat)
		   {  
			 $category_data[] = array("id" => $cat->id, "name" => $cat->name);
		   }
		}
		 
		 $first = DB::table('category_playlists')->select('playlist_name','playlist_id');

		 $playlist = DB::table('splash_playlists')
              ->union($first)->select('playlist_name','playlist_id')->get();
              
          if(!empty($playlist))
		{
		   foreach($playlist as $cat)
		   {  
			 $playlist_data[] = array("playlist_id" => $cat->playlist_id, "playlist_name" => $cat->playlist_name);
		   }
		}
              
              return view('admin.catstation.edit',compact('cat_station','category','playlist','playlist_data','category_data'));
		  
	  }
	  
	  public function updateCatStation(Request $request, $id){
		  
		  $input = $request->all();
		  
		 $category_playlists = DB::table('category_playlists')->where('playlist_id','=',$request->station)->first();
		 $splash_playlists = DB::table('splash_playlists')->where('playlist_id','=',$request->station)->first();
		 
		 if(count($category_playlists)==1){
			 $playlist_name = $category_playlists->playlist_name;
		 } if(count($splash_playlists)==1) {
			 $playlist_name = $splash_playlists->playlist_name;
			 
		 }
		 
		 $update_cat_station = DB::table('cat_station')->where('id','=',$id)
            ->update(['category_id' => $request->subcat,'playlist_id' => $request->station,'playlist_name' =>$playlist_name]);
            
            return redirect('admin/categorystations')->withSuccess( 'Category Station Updated Successfully.' );
	  }
	  
	  public function add_categorystations(Request $request){
		  
		  $this->validate($request, [
				'subcat' => 'required',
				'station' => 'required'
			]);
		 $category_playlists = DB::table('category_playlists')->where('playlist_id','=',$request->station)->first();
		 $splash_playlists = DB::table('splash_playlists')->where('playlist_id','=',$request->station)->first();
		 
		 if(count($category_playlists)==1){
			 $playlist_name = $category_playlists->playlist_name;
		 } if(count($splash_playlists)==1) {
			 $playlist_name = $splash_playlists->playlist_name;
			 
		 }
		 
		  $cat_station = DB::table('cat_station')->insert(
				['category_id' => $request->subcat, 'playlist_id' => $request->station,'playlist_name' => $playlist_name]
			);
			return redirect('admin/categorystations')->withSuccess( 'Category Station Added Successfully.' );
	  }
      
      public function playlistSongs(Request $request, $id)
	  {
		  
		  $clientId = config('client.clientId');
		  $clientSecret = config('client.clientSecret');
		  $callback = config('client.callback');
		  $client_userid = config('client.userid');
		  $client_username = config('client.username');
		  
		  $Url = 'http://api.soundcloud.com/users/'.$client_username.'/playlists/'.$id.'/?secret_token='.$clientSecret.'&client_id='.$clientId.'';
		  $ch = curl_init();
		  curl_setopt($ch, CURLOPT_URL, $Url);
		  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		  $data = curl_exec($ch);
		  curl_close($ch);
		  $api_content_array = json_decode($data, true);		  
		  /*
		  $api_url =  'http://api.soundcloud.com/users/jwompa/playlists/'.$id.'/?secret_token=a6ff03d0d042d5921df9d1dae174a520&client_id=38be6f938ab09a49c85fac7dc31cb37a';
		  $api_content = file_get_contents($api_url);
          $api_content_array = json_decode($api_content, true); */
          
          return view('admin.playlist.playlistsong', compact('api_content_array'));
      }

      //function for add splash playlist
      public function addSplash()
      {
      	$input = array();
		$category = DB::table('playlists')->select('id','name')->where('status',1)->whereNotIn('id', function($query) {
			$query->from('splash_playlists')->select('playlist_id')->get();
		})->get();
		if(!empty($category))
		{
		   foreach($category as $cat)
		   {  
			 $input[] = array("id" => $cat->id, "name" => $cat->name);
		   }
		}
      	 return view('admin.playlist.addSplash',compact('input'));
      }
      //function for store splash playlist
      public function storeSplash(Request $request)
      {
        $validator = Validator::make($request->all(), [
            'playlist_id' => 'required|unique:splash_playlists',
        ]);
        if($validator->errors()->all()) {
            return \Redirect::back()->withErrors($validator->errors()->first());
        }
        $SP = SplashPlaylist::where('playlist_id',$request->playlist_id)->first();
        if($SP) {
        	/*$category = DB::table('playlists')->select('id','name')->get();
			if(!empty($category))
			{
			   foreach($category as $cat)
			   {  
				 $input[] = array("id" => $cat->id, "name" => $cat->name);
			   }
			}*/
        	return view('admin.playlist.addSplash',compact('input'))->withErrors('Playlist Already Excists');
        }
        $MAX = SplashPlaylist::select(DB::raw('Max(sort_priority) as max'))->first();
        $new_max = $MAX->max+1;
	    $input = array();
		$input['playlist_id'] =  $request->playlist_id;
		$input['sort_priority'] = $new_max;

       	SplashPlaylist::create($input);
       	return redirect('admin/displaySplash')->withSuccess( 'Playlist Created Successfully' );
      }

      //function for display splash playlist
      public function displaySplash()
      { 
		  
		$valid_login = Auth::guard('admin')->user();
        if($valid_login->auth_level <> 1) { return redirect('admin/logout'); }
      
       $playlists = DB::table('splash_playlists')->select('splash_playlists.id','splash_playlists.playlist_id','playlists.name as playlist_name','parent_category.pcat_name as pcat_name', 'categories.name as sub_name')->join('playlists','splash_playlists.playlist_id','=','playlists.id')->join('category_playlists','category_playlists.playlist_id','=','playlists.id')->join('categories','category_playlists.category_id','=','categories.id')->join('parent_category','parent_category.id','=','categories.pcat_name')->orderBy("sort_priority",'ASC')->get();
	   	
	   return view('admin.playlist.splash',compact('playlists','valid_login'));
      }

      //function for edit splash playlist
      public function editSplash(Request $request, $id)
      {  
     	$playlist = SplashPlaylist::findOrFail($id);
		  return view('admin.playlist.editSplash',compact('playlist'));
	  }

	   //function for update splash playlist
      public function updateSplash(Request $request, $id)
	      { 
	        $this->validate($request,[
	        'playlist_name' => 'required|min:2|unique:splash_playlists,playlist_name,'.$id,
	        ]);
	        $playlist = SplashPlaylist::findOrFail($id);
          $input = $request->all();
          //print_r($input);die;
	        $clientId = config('client.clientId');
          $clientSecret = config('client.clientSecret');
          $client_userid = config('client.userid');
          $client_username = config('client.username');
          $client_email = config('client.email');
          $client_password = config('client.password');
          $facade = new SoundcloudFacade($clientId , $clientSecret);
          $facade->userCredentials($client_email,$client_password ); // on success, access_token is set by default for next requests.       
          // build playlist main array
          $playlistData = array(
            'playlist' => array('id'=>$playlist->playlist_id,'title' => $input['playlist_name'], 'sharing' => 'private')
            );
          $response = $facade->post('/playlists', $playlistData)->request()->bodyArray();
	        $playlist->fill($input)->save();
	        return redirect('admin/displaySplash')->withSuccess( 'Playlist Updated Successfully' );	   
	       //return \Redirect::back()->withSuccess( 'Category Updated Successfully' );
	      }


      //function for display splash playlist
      public function destroySplash($id)
      {  
      	//print_r($input);die;
        $playlist = SplashPlaylist::find($id);
        SplashPlaylist::find($id)->delete();
        return redirect('admin/displaySplash')->withSuccess( 'Playlist Deleted Successfully' );
      }

      public function sortSplashBoard (Request $request) {
      	$sort_list = $request->get('sort_list');
      	for ($i=0; $i < sizeof($sort_list); $i++) {
      		//Find Priority and Set 0
      		$FP = SplashPlaylist::where('sort_priority',$sort_list[$i])->first();
      		if ($FP) {
      			$FP->sort_priority 				= 	11111111111;
      			$FP->update();
      		}
      	}
      	for ($i=0; $i < sizeof($sort_list); $i++) {
      		//Set New Priority
      		$SP = SplashPlaylist::where('playlist_id',$sort_list[$i])->first();
      		if ($SP) {
      			$SP->sort_priority 				= 	$i+1;
      			$SP->update();
      		}
      	}
      	$this->displaySplash();
      }

      public function getSubCategoryById (Request $request) {
      	 $id = $request->get('id');
      	 $CAT = Categories::where('pcat_name',$id)->where('status',1)->select('id','pcat_name','name as scat_name')->get();
      	 return $CAT;
      }

      public function PlaylistNotification ($id) {
        $playlist = Playlists::findOrFail($id);
        if (!$playlist)
          return \Redirect::back()->withErrors( 'Playlist Not Found' );

        return view('admin.notification.playlist',compact('playlist'));
      }

      public function sendPlaylistNotification (Request $request) {
        $input = $request->all();
      	$users = UserDevice::select('device_id')->get();
  	  	$GR = new GenericRepository;
  	  	$failure_count = 0;
  	  	foreach ($users as $user) {
  	  		if ($user->device_id) {
  	  			$params['device_id'] = $user->device_id;
  		        $params['module'] = 'playlist';
              $params['message'] = $input['message'];
  		        $params['id'] = $input['id'];
  	  			$count = $GR->sendPushNotification($params);
  	  			$failure_count += $count;
  	  		}
  	  	}
  	    $playlists = Playlists::select(DB::raw('playlists.*,categories.name as cat_name'))->join('category_playlists','category_playlists.playlist_id','=','playlists.id')->join('categories','categories.id','=','category_playlists.category_id')->orderBy('id','DESC')->paginate(config('client.no_of_records'));
       	return redirect('admin/displayPlaylist')->withSuccess( 'Notification Sent Successfully' );
      }
      

      
}
