<?php

namespace Api\Web\Controllers;
use DB;
use Hash;
use Illuminate\Http\Request;
use Api\Master\Models\Mail;
use Api\Master\Models\Announcement;
use App\Http\Requests;
use Infrastructure\Http\Controller;
use Api\Master\Models\UserDevice;

use Api\Mobile\Repositories\GenericRepository;

class AnnouncementController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {  
    	 $announcement = Announcement::all();   
    	 //$mail = DB::table('mails')->where('id', '11')->first();
		return view('admin.announcement.index')->with('announcement',$announcement);
		
    }

    public function create () {
        return view('admin.announcement.create');
    }

    public function createAnnouncement (Request $request) {
        $announcement = $request->all();
        $AN = new Announcement;
        $AN->heading = $announcement['heading'];
        $AN->description = $announcement['description'];
        $AN->save();

        return redirect('/admin/announcements')->withSuccess('Announcement Added Successfully');
    }

    public function editAnnouncement ($id) {
        $AN = Announcement::find($id);
        if($AN) {
            return view('admin.announcement.edit')->with('announcement',$AN);
        }
        return redirect('/admin/announcements');
    }

   public function edit(Request $request, $id)
    {   
        $input = $request->all();
        $AN = Announcement::find($id);
        if ($AN) {
            $AN->heading = $input['heading'];
            $AN->description = $input['description'];
            $AN->update();
            return redirect('/admin/announcements')->withSuccess('Announcement Updated Successfully');
        }
        return redirect('/admin/announcements')->withError('Announcement Not Found');
	}

    public function delete ($id) {
        Announcement::where('id',$id)->delete();
        return redirect('/admin/announcements')->withSuccess('Announcement Deleted Successfully');
    }
	
	
	public function show($id)
	{
		$showmailtemp = Mail::findOrFail($id);
		return view('admin.mail.show',compact('showmailtemp'));
	}

    public function sendAnnouncementNotification ($id) {
        $users = UserDevice::select('device_id')->get();
        $announcements = Announcement::find($id);
        $GR = new GenericRepository;
        $failure_count = 0;
        foreach ($users as $user) {
            if ($user->device_id) {
                $params['device_id'] = $user->device_id;
                $params['module'] = 'news';
                $params['id'] = $id;
                $params['body'] = $announcements->description;
                $count = $GR->sendPushNotification($params);
                $failure_count += $count;
            }
        }
        return redirect('/admin/announcements')->withSuccess('Announcement Send Successfully');
    }
}
