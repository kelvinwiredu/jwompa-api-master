<?php

namespace Api\Web\Controllers;

use Api\Master\Models\Category;
Use DB;
use Auth;
use Redirect;
use Validator;
Use Hash;
use Api\Master\Models\FeedbackCategory;
use Api\Master\Models\Feedback;
use Api\Master\Models\User;
use Infrastructure\Http\Controller;

		
use Illuminate\Http\Request;


class FeedbackCategoryController extends Controller
{
     
    public function index()
    {   
		$feedback = DB::table('feedback_category')->get();
		
        return view('admin.feedbackcategory.index',compact('feedback'));
    }
    
    public function create()
    {
        return view('admin.feedbackcategory.create');
    }
    
    public function store(Request $request)
    {
       $this->validate($request, [
        'cat_name' => 'required',
       ]);
       
       $input = $request->all();
		 
         $feedbackCategory = FeedbackCategory::create($input);
        
         return \Redirect::back()->withSuccess( 'Feedback Category Created Successfully.' );
        
    }
    
    public function edit(Request $request, $id)
	    {   
			$feedback = FeedbackCategory::findOrFail($id);
			return view('admin.feedbackcategory.edit',compact('feedback'));
		}
    
    public function update(Request $request, $id)
	      { 
	        $feedback = FeedbackCategory::findOrFail($id);
			$input = $request->all();
			$feedback->fill($input)->save();
	        return redirect('admin/feedbackcategory')->withSuccess( 'Feedback Category Updated Successfully' );	   
	       }
	       
	public function destroy(Request $request, $id)
	      { 
	        $feedback_category_delete = DB::table('feedback_category')->where('id', '=', $id)->delete();
	        return redirect('admin/feedbackcategory')->withSuccess( 'Feedback Category Deleted Successfully' );	   
	       }
	       
	public function feedbacks(){
		//$feedbacks = Feedback::get();
		
		$feedbacks = DB::table('feedback')
						  ->join('users', 'users.id', '=', 'feedback.user_id')
						  ->join('feedback_category', 'feedback_category.id', '=', 'feedback.feedback_cat')
						  ->select('users.first_name','users.last_name','feedback_category.cat_name','feedback.subject','feedback.message')
						  ->get();
		return view('admin.feedbackcategory.feedbacklist',compact('feedbacks'));
		
	}
}
