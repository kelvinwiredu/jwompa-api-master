<?php

namespace Api\Web\Controllers;
use DB;
use Hash;
use Illuminate\Http\Request;
use Api\Master\Models\Mail;
use App\Http\Requests;
use Infrastructure\Http\Controller;

class MailController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {  
    	 $mail = Mail::all();   
    	 //$mail = DB::table('mails')->where('id', '11')->first();
		return view('admin.mail.index')->with('mail',$mail);
		
    }

   public function edit(Request $reuest, $id)
    {   
		$user = Mail::findOrFail($id);
		return view('admin.mail.edit',compact('user'));
	}
	
	 public function update(Request $request, $id)
      {
        
         $this->validate($request, [
        'subject' => 'required|max:255',
        'message' => 'required',
        ]);
         $email = Mail::findOrFail($id);
        	
         $input = $request->all();
         $email->fill($input)->save();
       return redirect('admin/emails')->withSuccess( 'Email Template Updated Successfully.' );
      }
	
	
	public function show($id)
	{
		$showmailtemp = Mail::findOrFail($id);
		return view('admin.mail.show',compact('showmailtemp'));
	}
}
