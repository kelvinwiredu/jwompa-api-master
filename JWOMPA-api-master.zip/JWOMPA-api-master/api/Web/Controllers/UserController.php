<?php

namespace Api\Web\Controllers;

use DB;
use Api\Master\Models\User;
use Auth;
use Redirect;
use Validator;
Use Hash;
use Api\Master\Models\TrackRate;
use Api\Master\Models\Tracks;
use Api\Master\Models\SkipSong;
use Api\Master\Models\CategoryPlaylist;
use Api\Master\Models\SplashPlaylist;
use Api\Master\Models\LanguageMaster;
use Api\Master\Models\Playlists;
use Api\Master\Models\ParentCategory;
use Api\Master\Models\Categories;
use Api\Master\Models\UserSearchKeyword;
use Infrastructure\Http\Controller;
use Api\Master\Models\UserPreference;
use Api\Master\Models\TrackLikes;
use Illuminate\Http\Request;


class UserController extends Controller
{
   /* ******************* Add User ************************** */
     public function create()
    {
      $languages = LanguageMaster::orderBy('name')->get();
      return view('admin.userlist.create',compact('languages'));
    }
    
     public function downloadSplash()
    {
      // $playlists = SplashPlaylist::select(DB::raw('playlists.id,playlists.name as playlist_name,playlists.live_duration as days_live'))->join('playlists', function($join) {
        // $join->on('playlists.id','=','splash_playlists.playlist_id');
      // })->orderBy('sort_priority')->get();
     $playlists = DB::table('splash_playlists')->select('splash_playlists.id','splash_playlists.playlist_id','playlists.name as playlist_name','parent_category.pcat_name as pcat_name', 'categories.name as sub_name', 'playlists.live_duration as days_live')->join('playlists','splash_playlists.playlist_id','=','playlists.id')->join('category_playlists','category_playlists.playlist_id','=','playlists.id')->join('categories','category_playlists.category_id','=','categories.id')->join('parent_category','parent_category.id','=','categories.pcat_name')->orderBy("sort_priority",'ASC')->get();

       
     return view('admin.playlist.download',compact('playlists'));
        
    }

    public function downloadTrack () {

      $Tracks = Tracks::select(DB::raw('tracks.id,track_name as title,playlists.name as pl_name'))->join('playlist_track_ids','playlist_track_ids.track_id','=','tracks.id')->join('playlists','playlists.id','=','playlist_track_ids.playlist_id')->orderBy('tracks.id')->get();
      foreach ($Tracks as $track) {
        $track->likes = 0;
        $track->dislikes = 0;
        $TL = TrackLikes::select(DB::raw('SUM(no_of_likes) as likes,SUM(no_of_dislikes) as dislikes'))->where('track_id',$track->id)->first();
        if ($TL) {
          $track->likes = $TL->likes;
          $track->dislikes = $TL->dislikes;
        }
        $ST = SkipSong::select(DB::raw('SUM(no_of_skip) as no_of_skip'))->where('track_id',$track->id)->groupBy('track_id')->first();
        $track->no_of_skip = $ST['no_of_skip'];
      }
      $tracks = $Tracks;
      return view('admin.track.download',compact('tracks'));
    }
    
    public function downloadLoginUser()
    {
    $logindetail_download = DB::table('login_details')
      ->join('users', 'login_details.user_id', '=', 'users.id')
      ->select('users.id','users.username','users.first_name','users.last_name','users.profile_image','login_details.created_at','login_details.logout_time','login_details.user_id','login_details.time_duration')
      ->get();  
       
     return view('admin.logindetail.download',compact('logindetail_download'));
        
    }
    
    public function downloadPlaylistLike()
    {
    $downloadPlaylistLike = DB::select("SELECT splash_playlists.playlist_name,SUM(CASE WHEN type = 1 THEN 1 ELSE 0 END) AS LikeCount, 
       SUM(CASE WHEN type = 0 THEN 1 ELSE 0 END) AS DisLikeCount FROM splash_playlists LEFT JOIN playlist_likes ON (playlist_likes.playlist_id=splash_playlists.playlist_id)  GROUP BY splash_playlists.id");
            
       
     return view('admin.playlistlike.download',compact('downloadPlaylistLike'));
        
    }
    
    public function downloadRatingList()
    {
    $rating_data = DB::table('track_ratings')->select('track_id','track_title','rating')->get();
        $unique_records = array();
        foreach($rating_data as $rating_datas){
      
        $data_rate = TrackRate::select('rating','track_title')->whereTrackId($rating_datas->track_id)->get();
           
                $total_record = count($data_rate->toArray());
                
                $sum = 0;
                foreach ($data_rate->toArray() as $key => $value) {
          
                    $sum = $sum + $value['rating'];
                }
            $average = round($sum/$total_record);
            $unique_records[$value['track_title']] = $average;
        
           }  
     return view('admin.ratelist.download',compact('unique_records','rating_data'));
        
    }
    
    public function downloadFavourite()
    {
    $Favourite_data = DB::select("SELECT splash_playlists.playlist_name,playlist_favorites.playlist_id,count(playlist_favorites.user_id) AS favcount
FROM playlist_favorites LEFT JOIN splash_playlists ON (playlist_favorites.playlist_id=splash_playlists.id) GROUP BY splash_playlists.id");
    
     return view('admin.favourite.download',compact('Favourite_data'));
        
    }
    
    public function downloadListensongs()
    {
    $listensong = DB::table('listen_song')->select('playlist_title','track_title','no_of_listen')
    ->groupBy('track_id')->get();
          
     return view('admin.listensongs.download',compact('listensong'));
        
    }
    
    public function downloadskipsongs()
    {
    $skipsongs = DB::table('skip_song')->select('playlist_title','track_title','no_of_skip')
    ->groupBy('track_id')->get();
  
          
     return view('admin.skipsongs.download',compact('skipsongs'));
        
    }
    
    public function downloadMyPlaylists()
    {
      $playlists = Playlists::select(DB::raw('playlists.*,categories.name as cat_name'))->join('category_playlists','category_playlists.playlist_id','=','playlists.id')->join('categories','categories.id','=','category_playlists.category_id')->orderBy('id','DESC')->get();

       foreach ($playlists as $play) {
      $tracks = Playlists::select(DB::raw('playlists.id,(tracks.length) as total_listening_time'))->join('playlist_track_ids', function($join) {
          $join->on('playlists.id','=','playlist_track_ids.playlist_id');
       })->join('tracks', function ($join) {
          $join->on('playlist_track_ids.track_id','=','tracks.id');
       })->where('playlists.id',$play['id'])->get();
      // $times = array($time1, $time2);
      $seconds = 0;
      foreach ($tracks as $timeListen)
      {
        $time = $timeListen->total_listening_time;
        // print_r($time);
        if(strpos($time, ':')){
          $time = $time;
        }else{
          $time = $time.':00';
        }
        list($minute,$second) = explode(':', $time);
        $hour = 00;
        $seconds += $hour*3600;
        $seconds += $minute*60;
        $seconds += $second;
      }
      $hours = floor($seconds/3600);
      $seconds -= $hours*3600;
      $minutes  = floor($seconds/60);
      $seconds -= $minutes*60;
      $varCheck = sprintf('%02d:%02d', $hours, $minutes);
      $play['total_listening_time'] = $varCheck;
     }
          
     return view('admin.playlist.downloadmyplaylist',compact('playlists'));
        
    }
    
    public function store(Request $request)
    {
       $validator = Validator::make($request->all(), [
        'email' => 'required|email|max:255|unique:users',
        'dob' => 'required|date',
        'password' => 'required|min:6',
        'first_name' => 'required|string|max:255',
        'last_name' => 'required|string|max:255',
        'dob' => 'required|date_format:"Y-m-d"',
        'country' => 'required|string',
        'currentcountry' => 'required|string',
        'status' => 'numeric|required',
        'language' => 'string|required',
       ]);

      if($validator->errors()->all()) {
        return \Redirect::back()->withErrors($validator->errors()->first());
      }
       
      $input = array();
      $input = $request->all();
      $input['password'] = Hash::make($request->password); 
      $input['staus'] =  1;
       User::create($input);
      return redirect('admin/dashboard')->withSuccess( 'Thanks,User Created Successfully.' );
        
    }
    
    
    /* ******************* Add User ************************** */
    
     /* ******************* User Listing ************************** */
    public function index()
    {   
  $users = User::where('id', '!=', 1)->orderby('id', 'DSC')->get();
        foreach ($users as $key => $user) {
          $user['likes'] = 0;
          $user['dislikes'] = 0;
          $user['tracks_played'] = 0;
          $listensong = DB::table('listen_song')->select('playlist_title','track_title','no_of_listen')->where('user_id',$user->id)->groupBy('track_id')->get();
          if (isset($listensong) && !empty($listensong)) {
            $user['tracks_played'] = count($listensong);
          }

          $TL = TrackLikes::select(DB::raw('SUM(no_of_likes) as likes,SUM(no_of_dislikes) as dislikes'))->where('user_id',$user->id)->first();
          if (isset($TL) && !empty($TL)) {
            if($TL->likes!=''){
              $user['likes'] = $TL->likes;
            }
            if($TL->dislikes!=''){
              $user['dislikes'] = $TL->dislikes;
            }
          }
          $ST = SkipSong::select(DB::raw('SUM(no_of_skip) as no_of_skip'))->where('user_id',$user->id)->groupBy('user_id')->first();
          $user['no_of_skip'] = 0;
          if (isset($ST) && !empty($ST)){
            if($ST['no_of_skip'] !=''){
              $user['no_of_skip'] = $ST['no_of_skip'];
            }
          }

          $user['preference_one'] = UserPreference::select('preference_one_id as po_id', 'preference_one.name as name')->join('preference_one', function($join) {
              $join->on('user_preferences.preference_one_id','=','preference_one.id');
          })->where('user_id',$user->id)->whereNotNull('user_preferences.preference_one_id')->get();

          $user['preference_two'] = UserPreference::select('preference_two_id as pt_id', 'preference_two.name as name')->join('preference_two', function($join) {
            $join->on('user_preferences.preference_two_id', '=', 'preference_two.id');
          })->where('user_id',$user->id)->whereNotNull('user_preferences.preference_two_id')->get();
        }
        return view('admin.userlist.index',compact('users'));
    }
    
     /* ******************* User View ************************** */
    
    public function view(Request $reuest, $id)
    {   
    $user = User::findOrFail($id);
    return view('admin.userlist.view',compact('user'));
  }
   
   /* ******************* User Edit ************************** */
   
    public function edit(Request $reuest, $id)
    {   
    $user = User::findOrFail($id);
    $languages = LanguageMaster::orderBy('name')->get();
    return view('admin.userlist.edit',compact('user','languages'));
  }
  
   public function update(Request $request, $id)
  {
    $validator = Validator::make($request->all(), [
      'email' => 'required|email|max:255',
      'first_name' => 'required|string|max:255',
      'last_name' => 'required|string|max:255',
      'dob' => 'required|date_format:"Y-m-d"',
      'country' => 'required|string',
      'currentcountry' => 'required|string',
      'status' => 'numeric|required',
      'language' => 'string|required',
    ]);
    if($validator->errors()->all()) {
        return redirect('admin/editUser/'.$id)->withInput($request->input())->withErrors($validator->errors()->first());
    }
    $user = User::findOrFail($id);
    
    $input = $request->all();        
    $user->fill($input)->save();
    return redirect('admin/dashboard')->withSuccess( 'Thanks,User Updated Successfully.' );
   
   //return \Redirect::back()->withSuccess( 'User Updated Successfully' );
  }
      
     /* ***************** Singer delete *************** */
     
    public function destroy($id)
    {  
        DB::table('user_device')->where('user_id',$id)->delete();
        DB::table('user_preferences')->where('user_id',$id)->delete();
        DB::table('user_search_keywords')->where('user_id',$id)->delete();
        DB::table('playlist_favorites')->where('user_id',$id)->delete();
        DB::table('playlist_recents')->where('user_id',$id)->delete();
        DB::table('skip_song')->where('user_id',$id)->delete();
        $user = User::find($id)->delete();
        return redirect('admin/displayUser')->withSuccess( 'Thanks,User Deleted Successfully.' );;
    } 

    public function pdf () {
      
    }

    public function downloadFeedback () {
      $feedbacks = DB::table('feedback')
              ->join('users', 'users.id', '=', 'feedback.user_id')
              ->join('feedback_category', 'feedback_category.id', '=', 'feedback.feedback_cat')
              ->select('users.first_name','users.last_name','feedback_category.cat_name','feedback.subject','feedback.message')
              ->get();
      return view('admin.feedbackcategory.download',compact('feedbacks'));
    }

    public function downloadCategory () {
        $category = DB::table('categories')
          ->join('parent_category', 'categories.pcat_name', '=', 'parent_category.id')
          ->select('parent_category.pcat_name','categories.name','categories.id')
          ->orderBy('categories.id','ASC')
          ->get();
    
      return view('admin.category.downloadcategory',compact('category'));
    }

    public function downloadParentCategory () {
      $category = DB::table('parent_category')
          ->select('id','pcat_name')
          ->get();
      
      return view('admin.category.downloadparentcategory',compact('category'));
    }

    public function downloadUserList () {
      $users = User::where('id', '!=', 1)->orderby('id', 'DSC')->get();
         foreach($users as $key => $userlist){
          $preOne = array();
          $preTwo = array();
          $valuePreOne = '';
          $valuePreTwo = '';
          $usersPreferences = UserPreference::select('po.name as pre_one','pt.name as pre_two')->where('user_id', '=', $userlist->id)->leftJoin('preference_one as po','po.id','=','user_preferences.preference_one_id')
        ->leftJoin('preference_two as pt','pt.id','=','user_preferences.preference_two_id')->get();
        if(isset($usersPreferences) && !empty($usersPreferences)){
          foreach($usersPreferences as $keyIn => $listPre){
            if($listPre->pre_one!=null && $listPre->pre_one!=''){
              $preOne[] =  $listPre->pre_one;
            }
            if($listPre->pre_two!=null && $listPre->pre_two!=''){
              $preTwo[] =  $listPre->pre_two;
            }
          }
          if(isset($preOne) && !empty($preOne))
          {
            $valuePreOne = implode(', ',$preOne);
          }
          if(isset($preTwo) && !empty($preTwo))
          {
            $valuePreTwo = implode(', ',$preTwo);
          }
        }
           $users[$key]['pre_one'] = $valuePreOne;
           $users[$key]['pre_two'] = $valuePreTwo;

           $users[$key]['likes'] = 0;
           $users[$key]['dislikes'] = 0;
           $users[$key]['tracks_played'] = 0;
           $listensong = DB::table('listen_song')->select('playlist_title','track_title','no_of_listen')->where('user_id',$userlist->id)->groupBy('track_id')->get();
           if (isset($listensong) && !empty($listensong)) {
            $users[$key]['tracks_played'] = count($listensong);
          }
          
           $TL = TrackLikes::select(DB::raw('SUM(no_of_likes) as likes,SUM(no_of_dislikes) as dislikes'))->where('user_id',$userlist->id)->first();
           if (isset($TL) && !empty($TL)) {
            if($TL->likes!=''){
              $users[$key]['likes'] = $TL->likes;
            }
            if($TL->dislikes!=''){
              $users[$key]['dislikes'] = $TL->dislikes;
            }
          }
          $ST = SkipSong::select(DB::raw('SUM(no_of_skip) as no_of_skip'))->where('user_id',$userlist->id)->groupBy('user_id')->first();
          $users[$key]['no_of_skip'] = 0;
          if (isset($ST) && !empty($ST)){
            if($ST['no_of_skip'] !=''){
              $users[$key]['no_of_skip'] = $ST['no_of_skip'];
            }
          }
        }
      return view('admin.userlist.download',compact('users'));
    }

    public function downloadSearchHistory () {
      $searchhistory = UserSearchKeyword::orderBy('id','desc')->get();
      return view('admin.song.downloadsearchhistory',compact('searchhistory'));
    }
      
    
}
