<?php

namespace Api\Web\Controllers;

use Illuminate\Http\Request;
use Infrastructure\Http\Controller;
use Api\Web\Services\GenericService;
use Illuminate\Contracts\Auth\Guard;

//Requests
use Api\Web\Requests\LoginRequest;

//Models
use Api\Users\Models\User;
use Api\Master\Models\UserPreference;
use Api\Master\Models\TrackLikes;
use Api\Master\Models\SkipSong;
use Validator;
use Auth;
use DB;
/**
 * @resource Playlist
 *
 * 
 */
class LoginController extends Controller
{

    /**
     * User model instance
     * @var User
     */
    protected $user; 
    
    /**
     * For Guard
     *
     * @var Authenticator
     */
    protected $auth;

    private $genericService;

    public function __construct(GenericService $genericService,Guard $auth, User $user)
    {
        $this->genericService = $genericService;
        $this->user = $user; 
        $this->auth = $auth;
    }

    /* Login get post methods */
    protected function getLogin() {
    
        return View('admin.users.login');
    }

    protected function postLogin(LoginRequest $request) {
        
        $field = filter_var($request->input('login'), FILTER_VALIDATE_EMAIL) ? 'email' : 'user_id';
        $request->merge([$field => $request->input('login')]);
        $request->merge(['remember_token' => (array_key_exists('remember_token', $request)) ? true : false]);

        if (Auth::guard('admin')->attempt($request->only($field, 'password', 'auth_level'),$request['remember_token']))
        {
            return redirect()->route('admin/dashboard');
        }
        
       return redirect('admin/login')->withErrors([
            'password' => 'The email or the password is invalid. Please try again.',
        ]);
    }

    public function getDashboard()
    {   
        $users = User::where('id', '!=', 1)->orderby('id', 'DSC')->get();   
        foreach ($users as $key => $user) {
          $users[$key]['likes'] = 0;
          $users[$key]['dislikes'] = 0;
          $user['tracks_played'] = 0;
          $listensong = DB::table('listen_song')->select('playlist_title','track_title','no_of_listen')->where('user_id',$user->id)->groupBy('track_id')->get();
          if (isset($listensong) && !empty($listensong)) {
            $user['tracks_played'] = count($listensong);
          }

          $TL = TrackLikes::select(DB::raw('SUM(no_of_likes) as likes,SUM(no_of_dislikes) as dislikes'))->where('user_id',$user->id)->first();
          if (isset($TL) && !empty($TL)) {
            if($TL->likes!=''){
              $users[$key]['likes'] = $TL->likes;
            }
            if($TL->dislikes!=''){
              $users[$key]['dislikes'] = $TL->dislikes;
            }
          }
          $ST = SkipSong::select(DB::raw('SUM(no_of_skip) as no_of_skip'))->where('user_id',$user->id)->groupBy('user_id')->first();
          $users[$key]['no_of_skip'] = 0;
          if (isset($ST) && !empty($ST)){
            if($ST['no_of_skip'] !=''){
              $users[$key]['no_of_skip'] = $ST['no_of_skip'];
            }
          }
          $user['preference_one'] = UserPreference::select('preference_one_id as po_id', 'preference_one.name as name')->join('preference_one', function($join) {
              $join->on('user_preferences.preference_one_id','=','preference_one.id');
          })->where('user_id',$user->id)->whereNotNull('user_preferences.preference_one_id')->get();

          $user['preference_two'] = UserPreference::select('preference_two_id as pt_id', 'preference_two.name as name')->join('preference_two', function($join) {
            $join->on('user_preferences.preference_two_id', '=', 'preference_two.id');
          })->where('user_id',$user->id)->whereNotNull('user_preferences.preference_two_id')->get();
        }     
        return view('admin.userlist.index',compact('users'));
    }

    protected function getLogout() {
        Auth::guard('admin')->logout();
        return redirect('admin/login');
    }

}
