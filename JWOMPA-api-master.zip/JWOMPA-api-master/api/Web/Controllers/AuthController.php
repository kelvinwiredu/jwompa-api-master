<?php

namespace Api\Web\Controllers;

use Api\Master\Models\User;
use Validator;
use Infrastructure\Http\Controller;
use Illuminate\Foundation\Auth\ThrottlesLogins;
use Illuminate\Foundation\Auth\AuthenticatesAndRegistersUsers;

use Illuminate\Contracts\Auth\Guard;
use App\Http\Requests\Admin\LoginRequest; 
use App\Http\Requests\Admin\RegisterRequest;



class AuthController extends Controller
{
   /**
     * User model instance
     * @var User
     */
    protected $user; 
    
    /**
     * For Guard
     *
     * @var Authenticator
     */
    protected $auth;

    use AuthenticatesAndRegistersUsers, ThrottlesLogins;

    /**
     * Create a new authentication controller instance.
     *
     * @return void
     */
    public function __construct(Guard $auth, User $user)
    {
        $this->user = $user; 
        $this->auth = $auth;
        $this->middleware('guest', ['except' => 'getLogout']);
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'username' => 'required|max:255',
            'email' => 'required|email|max:255|unique:users',
            'password' => 'required|confirmed|min:6',
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return User
     */
    protected function create(array $data)
    {
       return User::create([
            'username' => $data['username'],
            'email' => $data['email'],
            'password' => bcrypt($data['password']),
        ]);
    }

    /* Login get post methods */
    protected function getLogin() {
	
        return View('admin.users.login');
    }
    
    protected function getRegister() {
	
        return View('admin.users.register');
    }

    protected function postLogin(LoginRequest $request) {
        
        $field = filter_var($request->input('login'), FILTER_VALIDATE_EMAIL) ? 'email' : 'username';
		$request->merge([$field => $request->input('login')]);

		if ($this->auth->attempt($request->only($field, 'password', 'role_id')))
		{
			return redirect()->route('admin/dashboard');
		}
        
       return redirect('admin/login')->withErrors([
            'password' => 'The email or the password is invalid. Please try again.',
        ]);
    }

    

    protected function postRegister(RegisterRequest $request) {
        $this->user->username = $request->username;
        $this->user->email = $request->email;
        $this->user->password = bcrypt($request->password);
        $this->user->save();
        return redirect('admin/login');
    }
    
    
    

    

    /**
     * Log the user out of the application.
     *
     * @return Response
     */
    protected function getLogout()
    {
        $this->auth->logout();
        return redirect('admin/login');
    }
}
