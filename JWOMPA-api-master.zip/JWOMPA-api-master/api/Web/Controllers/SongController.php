<?php

namespace Api\Web\Controllers;

use Api\Master\Models\User;
Use Api\Master\Models\Song;
Use Api\Master\Models\ListenSong;
Use Api\Master\Models\Playlist;
use Api\Master\Models\Tracks;
use Api\Master\Models\TrackLikes;
use Api\Master\Models\SkipSong;
use Api\Master\Models\UserDevice;
use Api\Master\Models\UserSearchKeyword;
use Auth;
use Redirect;
use Validator;
Use Hash;
Use DB;
use Infrastructure\Http\Controller;
use App\Classes\Services_Soundcloud;
use Njasm\Soundcloud\SoundcloudFacade;
use Illuminate\Http\Request;
use Api\Mobile\Repositories\GenericRepository;


class SongController extends Controller
{
   /* ******************* Add Singer ************************** */
     public function create()
    {
        return view('admin.song.create');
    }
    
    public function store(Request $request)
    {
       $this->validate($request, [
        'title' => 'required|min:4|unique:songs',
       ]);
       
       $input = array();
		
		 $input['title'] =  $request->title;
		
		 $input['staus'] =  1;
         Song::create($input);
        
         return \Redirect::back()->withSuccess( 'Song Created Successfully' );
        
    }
    
    /* ******************* Add Singer ************************** */
    
     /* ******************* Singer Listing ************************** */
    public function index()
    {   
		$songs = Song::paginate(config('client.no_of_records'));
		
        return view('admin.song.index',compact('songs'));
    }
    
     /* ******************* Singer View ************************** */
    
    public function view(Request $reuest, $id)
    {   
		$singer = Singer::findOrFail($id);
		return view('admin.singer.view',compact('singer'));
	}
   
   /* ******************* Singer Edit ************************** */
   
    public function edit(Request $reuest, $id)
    {   
		$singer = Singer::findOrFail($id);
		return view('admin.singer.edit',compact('singer'));
	}
	
	 public function update(Request $request, $id)
      {
        
         $this->validate($request, [
        'name' => 'required|min:4|unique:singers,name,'.$id,
        ]);

        $singer = Singer::findOrFail($id);
        
         $input = $request->all();
        
          $singer->fill($input)->save();
        
       return \Redirect::back()->withSuccess( 'Singer Updated Successfully' );
      }
      
     /* ***************** Singer delete *************** */
     
     public function destroy($id)
    {
       
        $singer = Singer::find($id)->delete();
        return redirect('admin/displaySinger')->withSuccess( 'Singer Deleted Successfully' );;
    } 
      
      
      public function searchSong()
      {  
		  return view('admin.song.search');
		   
	  }
	  
	  public function searchSongList(Request $request)
      {  
		  $this->validate($request, [
        'title' => 'required|min:2',
       ]);
         $categories = array();
		  $user_id ="";
		   $clientId = config('client.clientId');
		  $clientSecret = config('client.clientSecret');
		  $callback = config('client.callback');
		  $client_userid = config('client.userid');
		  
		 $key = strip_tags(trim($request->title));
		  
		  $soundcloud = new Services_Soundcloud($clientId, $clientSecret, $callback);
	  $api_url = 'http://api.soundcloud.com/users/jwompa/tracks/?client_id='.$clientId.'&q='.urlencode($key).'&limit=10';
         //$api_url = 'http://api.soundcloud.com/tracks?genres=rock&client_id='.$clientId.'';
       // $api_url = ' http://api.soundcloud.com/users/{$userid}/tracks.json?client_id={$clientid}';
        
      // $api_url =  'http://api.soundcloud.com/users/jwompa/playlists/?client_id=38be6f938ab09a49c85fac7dc31cb37a';
        
         //$api_url = "http://api.soundcloud.com/users/{$client_userid}/playlists";
        $user_id = \Auth::user()->id;
        $categories = DB::table('play_lists')->where('user_id' , $user_id)->select('id','name')->get();
  
         
          $api_content = file_get_contents($api_url);
          $api_content_array = json_decode($api_content, true);
		
		
		  
		  return view('admin.song.search',compact('api_content_array','categories'));
		   
	  }
	  
	  public function listensongs(){
		  
		  //$listensong = DB::select("SELECT playlist_title,track_title,Count(id) as ListenCount FROM listen_song GROUP BY track_id");
           
           $listensong = DB::table('listen_song')
							->select('playlist_title','track_title','no_of_listen')
								->groupBy('track_id')
									->paginate(config('client.no_of_records'));
           
		  return view('admin.listensongs.index',compact('listensong'));
	  }
	  
	  public function skipsongs(){
//$skipsongs = DB::select("SELECT playlist_title,track_title,Count(id) as SkipCount FROM skip_song GROUP BY track_id");
           
			$skipsongs = DB::table('skip_song')
							->select('playlist_title','track_title','no_of_skip')
								->groupBy('track_id')
									->paginate(config('client.no_of_records'));
		  return view('admin.skipsongs.index',compact('skipsongs'));
		  
	  }
	  
	  public function all_track(){
		 
		$Tracks = Tracks::select(DB::raw('tracks.id,track_name as title,playlists.name as pl_name'))->join('playlist_track_ids','playlist_track_ids.track_id','=','tracks.id')->join('playlists','playlists.id','=','playlist_track_ids.playlist_id')->orderBy('tracks.id')->get();
		foreach ($Tracks as $track) {
      $track->likes = 0;
      $track->dislikes = 0;
      $TL = TrackLikes::select(DB::raw('SUM(no_of_likes) as likes,SUM(no_of_dislikes) as dislikes'))->where('track_id',$track->id)->first();
      if ($TL) {
        $track->likes = $TL->likes;
        $track->dislikes = $TL->dislikes;
      }
			$ST = SkipSong::select(DB::raw('SUM(no_of_skip) as no_of_skip'))->where('track_id',$track->id)->groupBy('track_id')->first();
			$track->no_of_skip = $ST['no_of_skip'];
		}
		$response = $Tracks;

		return view('admin.track.index',compact('response'));
  }

  public function displayPlaylistTrack ($id) {
    $Tracks = Tracks::select(DB::raw('tracks.id,track_name as title,playlists.name as playlist_name'))->join('playlist_track_ids', function ($join) {
      $join->on('playlist_track_ids.track_id','=','tracks.id');
    })->join('playlists', function ($join) {
      $join->on('playlists.id','=','playlist_track_ids.playlist_id');
    })->where('playlist_track_ids.playlist_id',$id)->get();
    if ($Tracks->count() < 1)
          return \Redirect::back()->withErrors( 'Track Not Found' );
    foreach ($Tracks as $track) {
      $track->likes = 0;
      $track->dislikes = 0;
      $TL = TrackLikes::select(DB::raw('SUM(no_of_likes) as likes,SUM(no_of_dislikes) as dislikes'))->where('track_id',$track->id)->first();
      if ($TL) {
        $track->likes = $TL->likes;
        $track->dislikes = $TL->dislikes;
      }
      $ST = SkipSong::select(DB::raw('SUM(no_of_skip) as no_of_skip'))->where('track_id',$track->id)->groupBy('track_id')->first();
      $track->no_of_skip = $ST['no_of_skip'];
    }

    $response = $Tracks;

    return view('admin.track.playlisttrack',compact('response'));
  }

  public function TrackNotification ($id) {
    $Track = Tracks::select(DB::raw('tracks.id,track_name as title'))->where('id',$id)->first();
    if (!$Track)
          return \Redirect::back()->withErrors( 'Track Not Found' );
    $Track->likes = 0;
    $Track->dislikes = 0;
    $TL = TrackLikes::select(DB::raw('SUM(no_of_likes) as likes,SUM(no_of_dislikes) as dislikes'))->where('track_id',$Track->id)->first();
    if ($TL) {
      $Track->likes = $TL->likes;
      $Track->dislikes = $TL->dislikes;
    }
    $ST = SkipSong::select(DB::raw('SUM(no_of_skip) as no_of_skip'))->where('track_id',$Track->id)->groupBy('track_id')->first();
    $Track->no_of_skip = $ST['no_of_skip'];
    $track = $Track;

    return view('admin.notification.track',compact('track'));
  }

  public function sendTrackNotification (Request $request) {
    $input = $request->all();
  	$users = UserDevice::select('device_id')->get();
  	$GR = new GenericRepository;
  	$failure_count = 0;
  	foreach ($users as $user) {
  		if ($user->device_id) {
  			$params['device_id'] = $user->device_id;
	        $params['module'] = 'track';
          $params['message'] = $input['message'];
	        $params['id'] = $input['id'];
    			$count = $GR->sendPushNotification($params);
    			$failure_count += $count;
  		}
  	}
  	$Tracks = Tracks::select(DB::raw('tracks.id,track_name as title,tracks_likes.no_of_likes as likes,tracks_likes.no_of_dislikes as dislikes'))->leftJoin('tracks_likes', function($join) {
		$join->on('tracks_likes.track_id','=','tracks.id');
	})->groupBy('tracks.id')->orderBy('tracks.id')->get();
	foreach ($Tracks as $track) {
		$ST = SkipSong::select(DB::raw('SUM(no_of_skip) as no_of_skip'))->where('track_id',$track->id)->groupBy('track_id')->first();
		$track->no_of_skip = $ST['no_of_skip'];
	}
	$response = $Tracks;
	return redirect('admin/displayTrack')->withSuccess( 'Notification Send Successfully' );
  }

  public function searchHistory (Request $request) {
  	$searchhistory = UserSearchKeyword::orderBy('id','desc')->get();
  	return view('admin.song.searchhistory',compact('searchhistory'));
  }

  public function search (Request $request) {
  	$validator = Validator::make($request->all(), [
        'from' => 'date_format:"Y-m-d"|nullable',
        'to' => 'date_format:"Y-m-d"|nullable',
    ]);
    if($validator->errors()->all()) {
        return \Redirect::back()->withErrors($validator->errors()->first());
    }
    $from = $request->get('from');
    $to = $request->get('to');
    $searchhistory = UserSearchKeyword::orderBy('id','desc');
    if ($from)
    	$searchhistory = $searchhistory->whereDate('created_at','>',$from);
    if ($to)
    	$searchhistory = $searchhistory->whereDate('created_at','<',$to);
    $searchhistory = $searchhistory->get();
  	return view('admin.song.searchhistory',compact('searchhistory'))->withSuccess( 'Search History Fetched Successfully' );
  }
    
}
