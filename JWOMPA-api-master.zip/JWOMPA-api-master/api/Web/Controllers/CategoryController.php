<?php

namespace Api\Web\Controllers;

use Api\Master\Models\User;
use Api\Master\Models\Category;
Use DB;
use Auth;
use Redirect;
use Validator;
Use Hash;
use Carbon\Carbon;
use Api\Master\Models\ParentCategory;
use Infrastructure\Http\Controller;
use Api\Master\Models\CategoryPlaylist;

		
use Illuminate\Http\Request;


class CategoryController extends Controller
{
   /* ******************* Add Category ************************** */
    public function create()
    { 
		//$category = Category::lists('id', 'name');
		$input = array();
		$category = DB::table('parent_category')->select('id','pcat_name')->get();
		if(!empty($category))
		{
		   foreach($category as $cat)
		   {  
			 $input[] = array("id" => $cat->id, "pcat_name" => $cat->pcat_name);
		   }
		}  
		return view('admin.category.create',compact('input'));
    }
    
    public function store(Request $request)
    {
       $validator = Validator::make($request->all(), [
            'name' => 'required|min:2|unique:categories'
        ]);
       if($validator->errors()->all()) {
	        return \Redirect::back()->withErrors($validator->errors()->first());
	    }
        $input = array();
        $input = $request->all();
        
       if(empty($request->pcat_name))
       {
		 $input['pcat_name'] = $request->input('name');
		 $input['status'] = 1;  
         ParentCategory::create($input);  
	   } else {
		   
		   $input['status'] = 1;  
         Category::create($input);
	   }
         
         return redirect('admin/displayCategory')->withSuccess( 'Category Added Successfully' );	   
         //return \Redirect::back()->withSuccess( 'Category Created Successfully' );
        
    }
    
    
    /* ******************* Add Category ************************** */
    
     /* ******************* Category Listing ************************** */
    public function index()
    {   
		$input = DB::table('categories')
			->join('parent_category', 'categories.pcat_name', '=', 'parent_category.id')
			->select('parent_category.pcat_name','categories.name','categories.id')
			->orderBy('categories.id','ASC')
			->get();
		/*$category = DB::table('categories')->select('id','name')->get();
		$input = array();
		if(!empty($category))
		{
		   foreach($category as $cat)
		   {  
			   
			  $input[] = array("id" => $cat->id, "name" => $cat->name, "parent" => "");
			  $str = $cat->name;
			  
			 $input = $this->findChildListing($input,$cat->id, $str);
		   }
		}*/
		
        return view('admin.category.index',compact('input'));
    }
    
    public function displayParentCategory(){
		
		$parent_category = DB::table('parent_category')
					->select('id','pcat_name')
					->get();
			
			return view('admin.category.parent',compact('parent_category'));
		
	}
    
     /* ******************* Category View ************************** */
    
    public function view(Request $reuest, $id)
    {   
		$category = Category::findOrFail($id);
		return view('admin.category.view',compact('category'));
	}
   

       /* ******************* Category Playlist ************************** */
    
    public function viewPlaylist(Request $reuest, $category_id)
    {   

    	$playlists = CategoryPlaylist::whereCategoryId($category_id)->paginate(10);
    	return view('admin.category.viewPlaylist',compact('playlists'));
	}
   
   /* ******************* Category Edit ************************** */
   
    public function edit($id)
    {   
		$category = Category::find($id);
		$pcat_name = DB::table('parent_category')->pluck('pcat_name','id')->all();
		 
		return view('admin.category.edit',compact('category','pcat_name'));
	}
	
	 public function update(Request $request, $id)
      {
        $validator = Validator::make($request->all(), [
            'pcat_name' => 'required|numeric',
            'name' => 'required|string',
            'cat_id' => 'required|numeric',
        ]);
        if($validator->errors()->all()) {
            return \Redirect::back()->withErrors($validator->errors()->first());
        }

        $category = Category::findOrFail($id);
        if ($category) {
        	$input = $request->all();
        	$category->pcat_name 			= 	$input['pcat_name'];
        	$category->name 				= 	$input['name'];
        	$category->updated_at 			= 	Carbon::now();
        	$category->update();
        	return redirect('admin/displayCategory')->withSuccess( 'Category Updated Successfully' );
        }
        
        return \Redirect::back()->withErrors('Category Not Found');
        
        
      }
      
     /* ***************** Category delete *************** */
     
     public function destroy($id)
    {
   		$allcategory = Category::where('categories.id','=',$id)->get();
   		/*if(count($allcategory->toArray())!= 0)
   		{
   		$child_category = array();
   		foreach ($allcategory as $child_category) 
   		{
   			$child_id = $child_category->id;
   			$child_category = Category::find($child_id)->delete();
   		}	
   				$category = Category::find($id)->delete();
   				return redirect('admin/displayCategory')->withSuccess( 'Category Deleted Successfully' );
		}
   		else
   		{
   			$category = Category::find($id)->delete();
   			return redirect('admin/displayCategory')->withSuccess( 'Category Deleted Successfully' );
   		}*/
   		//print_r($allcategory->toArray());die;
        $category = Category::find($id)->delete();
        //print_r($category);die;
        return redirect('admin/displayCategory')->withSuccess( 'Category Deleted Successfully.' );
    } 
      public function delete_parent($id){
		  
		  $category = ParentCategory::find($id)->delete();
        
        return redirect('admin/displayParentCategory')->withSuccess( 'Parent Category Deleted Successfully.' );
		  
	  }
      
    /* *********************** find  Child ************* */
     public function findChild($input = array(), $id, $sr)
    {
		
		$category = DB::table('categories')->where('pid' , $id)->select('id','name')->get();
		$prefix = "";
		if($sr == 0)
		{ 
		  $prefix = "--";
		}
		elseif($sr == 1)
		{
		  $prefix = "----";
		}
		elseif($sr == 2)
		{
		  $prefix = "------";
		}
		elseif($sr == 3)
		{
		  $prefix = "--------";
		}
		elseif($sr == 4)
		{
		  $prefix = "----------";
		}
		elseif($sr == 5)
		{
		  $prefix = "------------";	
		}
		elseif($sr == 6)
		{
		  $prefix = "--------------";	
		}
		else
		{
		  $prefix = "----------------";	
		}
		
		
		
		if(!empty($category))
		{
		   foreach($category as $cat)
		   {   
			 
			  $sr++; 
			  $input[] = array("id" => $cat->id, "name" => $prefix.$cat->name);
			  $input =  $this->findChild($input,$cat->id,$sr++);
			  
		   }
		}   
		else
		{
			return $input;
		}
		
		
		return $input;
	}
    
    /* *********************** find  Child ************* */  
    
    /* ********************** Child Listing *********** */
    
    public function findChildListing($input = array(), $id, $str)
    {
		
		$category = DB::table('categories')->where('pid' , $id)->select('id','name')->get();
		
		if(!empty($category))
		{
		   foreach($category as $cat)
		   {   
			 
			  $str = $str;
			  $input[] = array("id" => $cat->id, "name" => $cat->name, "parent" =>  $str);
			  $input =  $this->findChildListing($input,$cat->id, $str);
			  
		   }
		}   
		else
		{
			return $input;
		}
		
		
		return $input;
	}
    
    
    /* ********************** Parent Listing ************ */
   //get sub category using ajax
    public function findSubCategory(Request $request)
    {	

    	$input = $request->all();    	
    	$data = DB::table('categories')->where('pcat_name' ,$input['category_id'])->select('id','name')->get();
    	if($data)
    	{
   		return view('admin.category.subcategory',compact('data'));
    	}
    	else
    	{
    		die;
    	}
    	
    	

    	//die('sdf');
    }

}
