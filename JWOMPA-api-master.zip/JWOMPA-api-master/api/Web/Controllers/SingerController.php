<?php

namespace Api\Web\Controllers;

use Api\Master\Models\User;
Use Api\Master\Models\Singer;
use Auth;
use Redirect;
use Validator;
Use Hash;
use Infrastructure\Http\Controller;

use Illuminate\Http\Request;


class SingerController extends Controller
{
   /* ******************* Add Singer ************************** */
     public function create()
    {
        return view('admin.singer.create');
    }
    
    public function store(Request $request)
    {
       $this->validate($request, [
        'name' => 'required|min:4|unique:singers',
       ]);
       
       
       
       $input = array();
        
        
		
		 $input['name'] =  $request->name;
		
		 $input['staus'] =  1;
         Singer::create($input);
        
         return \Redirect::back()->withSuccess( 'Singer Created Successfully' );
        
    }
    
    
    /* ******************* Add Singer ************************** */
    
     /* ******************* Singer Listing ************************** */
    public function index()
    {   
		$singers = Singer::paginate(10);
		
        return view('admin.singer.index',compact('singers'));
    }
    
     /* ******************* Singer View ************************** */
    
    public function view(Request $reuest, $id)
    {   
		$singer = Singer::findOrFail($id);
		return view('admin.singer.view',compact('singer'));
	}
   
   /* ******************* Singer Edit ************************** */
   
    public function edit(Request $reuest, $id)
    {   
		$singer = Singer::findOrFail($id);
		return view('admin.singer.edit',compact('singer'));
	}
	
	 public function update(Request $request, $id)
      {
        
         $this->validate($request, [
        'name' => 'required|min:4|unique:singers,name,'.$id,
        ]);

        $singer = Singer::findOrFail($id);
        
      
        
        
         $input = $request->all();
        
       
        
		
	  
        
          $singer->fill($input)->save();
        
        
       return \Redirect::back()->withSuccess( 'Singer Updated Successfully' );
      }
      
     /* ***************** Singer delete *************** */
     
     public function destroy($id)
    {
       
        $singer = Singer::find($id)->delete();
        return redirect('admin/displaySinger')->withSuccess( 'Singer Deleted Successfully' );;
    } 
      
    
}
