<?php

namespace Api\Web\Controllers;

use Api\Master\Models\User;
Use Api\Master\Models\Singer;
use Auth;
use Redirect;
use Validator;
Use Hash;
use Infrastructure\Http\Controller;
use Soundcloud;

use Illuminate\Http\Request;


class HomeController extends Controller
{
   
     public function index()
    {
        echo Soundcloud::getAuthUrl();
        die;
    }  
    
}
