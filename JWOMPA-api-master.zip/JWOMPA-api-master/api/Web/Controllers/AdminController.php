<?php

namespace Api\Web\Controllers;

use Api\Master\Models\User;
use Auth;
use Redirect;
use Validator;
Use Hash;
use Infrastructure\Http\Controller;

use Illuminate\Http\Request;
use App\Http\Requests\Admin\ProfileRequest;




class AdminController extends Controller
{
   
    /* ******************* Admin DashBoard ************************** */
    protected function dashboard(Request $request) 
    {
		$user_id ="";
	   
	  if($request->user()->is_admin())
      {  
		   $user_id = \Auth::user()->id;
		  
		   return View('admin.users.dashboard', compact('user_id'));
      }    
      else 
      {
         return redirect('/')->withErrors('You have not sufficient permissions for writing post');
      }
    
    }
    
    /* ******************* Admin DashBoard ************************** */
    
    /* ******************* Admin Profile **************************** */
    
     protected function getProfile(Request $request, $id) 
    {
		
	    $user_id ="";
  	  if(Auth::guard('admin')->user()->auth_level == 1)
      {    
  	    $user = User::where('id',$id)->first();
        if($user && (Auth::guard('admin')->user()->id == $user->id))
  		   return view('admin.users.profile', compact('user'));
  			return redirect('/')->withErrors('you have not sufficient permissions');

  	  }    
      else 
      {
         return redirect('/')->withErrors('You have not sufficient permissions for writing post');
      }
    
    }
    
    /* ******************* Admin Profile **************************** */
    
      public function postProfile(Request $request, $id)
      {
        
        $validator = Validator::make($request->all(), [
        'first_name' => 'required|max:255',
        'last_name' => 'required|max:255',
        'email' => 'required|email|max:255|unique:users,email,'.$id,
        'mobile' => 'required|numeric|min:10'
        ]);

        if($validator->errors()->all()) {
            return \Redirect::back()->withErrors($validator->errors()->first());
        }

        $user = User::findOrFail($id);
        
         $imageName = "";
         $input = $request->all();
        
        if($request->file('profile_image') != "")
         {
  
    		   $imageName = time() . '.' . $request->file('profile_image')->getClientOriginalExtension();
    		   
    		   $path = public_path().'/avatars/'.$id;
    		   if(!is_dir($path)) { mkdir($path); }  
    		   
    		   $request->file('profile_image')->move(base_path() . '/public/avatars/'.$id,$imageName); 
    		   
    		  /* if($request->file('profile_image')!="uplode_photo.png"){
    			@unlink($path . "/" . $user->photo);
    		   }*/
       
    		}
		if(!empty($imageName))
		{
		   $input['profile_image'] = $imageName;
	    }
	    if($request->password)
	    {
        $input['password'] = Hash::make($request->password); 
        }
        else
        {
        	unset($input['password']);
        }
        $user->fill($input)->save();

        
        
       return \Redirect::back()->withSuccess( 'Profile Updated Successfully.' );
       
       
      }
      /* ******************* Admin Profile **************************** */
      
     /* ******************** Change Password ************************** */ 
     protected function changePassword(Request $request) 
    {
		$user_id ="";
	   
	  if($request->user()->is_admin())
      {  
		   
		  
		   return View('admin.users.changePassword');
      }    
      else 
      {
         return redirect('/')->withErrors('You have not sufficient permissions for writing post');
      }
    
    }
    
     /* ******************** Change Password ************************** */ 
    /* ******************** Change Password ************************** */  
     protected function setPassword(Request $request) 
    {
		
		$this->validate($request, [
        'old_password' => 'required|min:6',
        'new_password' => 'required|min:6|confirmed',
        'new_password_confirmation' => 'required|min:6',
        ]);
		$user_id = ""; $old_password = ""; $new_password = "";  $confirm_password = "";
		$user_id = \Auth::user()->id;
		
		 $user = User::where('id',$user_id)->first();
		 
		 $old_password = $request->old_password;
		 $new_password = $request->new_password;
		 $confirm_password = $request->new_password_confirmation;
		 
		 $input = array();
		 $input['id'] =  $user_id;
		 
		 
		 if(Hash::check($old_password , $user->password))
		 {
			  $input['password'] =  Hash::make($new_password);
			  $user->fill($input)->save();
         }
		 
		 else
		 {
			  return \Redirect::back()->withWarning( 'Your Old Password Does Not Match' );
		 }
		 
        return \Redirect::back()->withSuccess( 'Profile Updated Successfully' );
		
	}
    /* ******************** Change Password ************************** */  
      
    
}
