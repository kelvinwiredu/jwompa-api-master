<?php

namespace Api\Web\Controllers;

use Hash;
use Illuminate\Http\Request;

use App\Http\Requests;
use Infrastructure\Http\Controller;
use Api\Master\Models\Setting;

class SettingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {  

        $setting = Setting::find(1);                
        return view('admin.setting.index',compact('setting',$setting));
    }

    public function update(Request $request)
    {
        $this->validate($request, [
        'sitename' => 'required|max:255',
        'siteemail' => 'required|email|max:255',
        'sitephone' => 'required|max:255',
        'meta_keyword' => 'required|max:255',
        'meta_description' => 'required|max:255',        
        ]);

        $setting = Setting::findOrFail(1);

        $input = $request->all();

        $setting->fill($input)->save();
       
        return redirect()->action('Admin\SettingController@index');
    }

}
