<?php

namespace Api\Web\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use Infrastructure\Http\Controller;
use Api\Master\Models\LoginDetail;
use Api\Master\Models\TrackRate;
use Api\Master\Models\SplashPlaylist;
use Api\Master\Models\PlaylistFavorite;
use Auth;
use Njasm\Soundcloud\SoundcloudFacade;
use Njasm\Soundcloud\Soundcloud;
use Illuminate\Foundation\Http\FormRequest;
 
class LoginDetailController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
		
        $valid_login = Auth::user();
        if($valid_login->role_id <> 1) { return redirect('admin/auth/logout'); }
        
        $flogindetail_data = DB::table('login_details')
			->join('users', 'login_details.user_id', '=', 'users.id')
			->select('users.id','users.username','users.first_name','users.last_name','users.profile_image','login_details.created_at','login_details.logout_time','login_details.user_id','login_details.time_duration')
			//->orderBy('users.first_name','asc')
			->paginate(config('client.no_of_records'));
			
		$flogindetail_count = DB::table('login_details')
			->join('users', 'login_details.user_id', '=', 'users.id')
			->select('users.id','users.username','users.first_name','users.last_name','users.profile_image','login_details.created_at','login_details.logout_time','login_details.user_id','login_details.time_duration')
			->get();
			
		$no_of_user = count($flogindetail_count);
              
        return view('admin.logindetail.index',compact('flogindetail_data','valid_login','no_of_user'));
    }
    
    public function logindetail_asc(){
		
		$valid_login = Auth::user();
        if($valid_login->role_id <> 1) { return redirect('admin/auth/logout'); }
        
		$flogindetail_data = DB::table('login_details')
			->join('users', 'login_details.user_id', '=', 'users.id')
			->select('users.id','users.username','users.first_name','users.last_name','users.profile_image','login_details.created_at','login_details.logout_time','login_details.user_id','login_details.time_duration')
			->orderBy('users.first_name','asc')
			->get();
			return view('admin.logindetail.sort',compact('valid_login','flogindetail_data'));
		
	}
	
	public function logindetail_desc(){
		
		$valid_login = Auth::user();
        if($valid_login->role_id <> 1) { return redirect('admin/auth/logout'); }
        
		$flogindetail_data = DB::table('login_details')
			->join('users', 'login_details.user_id', '=', 'users.id')
			->select('users.id','users.username','users.first_name','users.last_name','users.profile_image','login_details.created_at','login_details.logout_time','login_details.user_id','login_details.time_duration')
			->orderBy('users.first_name','desc')
			->get();
			return view('admin.logindetail.sort',compact('valid_login','flogindetail_data'));
		
	}
	
	public function rating_desc(){
		
		$valid_login = Auth::user();
        if($valid_login->role_id <> 1) { return redirect('admin/auth/logout'); }
        
        $rating_data = DB::table('track_ratings')->select('track_id','track_title','rating')
        ->orderBy('track_title','desc')
        ->get();
        $unique_records = array();
        foreach($rating_data as $rating_datas){
			
        $data_rate = TrackRate::select('rating','track_title')->whereTrackId($rating_datas->track_id)->get();
           
                $total_record = count($data_rate->toArray());
                
                $sum = 0;
                foreach ($data_rate->toArray() as $key => $value) {
					
                    $sum = $sum + $value['rating'];
                }
            $average = round($sum/$total_record);
            $unique_records[$value['track_title']] = $average;
        
           }
           return view('admin.ratelist.sort',compact('unique_records','rating_data','valid_login'));
	}
	
	public function rating_asc(){
		
		$valid_login = Auth::user();
        if($valid_login->role_id <> 1) { return redirect('admin/auth/logout'); }
        
        $rating_data = DB::table('track_ratings')->select('track_id','track_title','rating')
        ->orderBy('track_title','asc')
        ->get();
        $unique_records = array();
        foreach($rating_data as $rating_datas){
			
        $data_rate = TrackRate::select('rating','track_title')->whereTrackId($rating_datas->track_id)->get();
           
                $total_record = count($data_rate->toArray());
                
                $sum = 0;
                foreach ($data_rate->toArray() as $key => $value) {
					
                    $sum = $sum + $value['rating'];
                }
            $average = round($sum/$total_record);
            $unique_records[$value['track_title']] = $average;
        
           }
           return view('admin.ratelist.sort',compact('unique_records','rating_data','valid_login'));
	}

	public function playlistlike(){
		
	$valid_login = Auth::user();
        if($valid_login->role_id <> 1) { return redirect('admin/auth/logout'); }
        
           $playlistlike_data = DB::select("SELECT splash_playlists.playlist_name,SUM(CASE WHEN type = 1 THEN 1 ELSE 0 END) AS LikeCount, 
       SUM(CASE WHEN type = 0 THEN 1 ELSE 0 END) AS DisLikeCount FROM splash_playlists LEFT JOIN playlist_likes ON (playlist_likes.playlist_id=splash_playlists.playlist_id)  GROUP BY splash_playlists.id");
               
        return view('admin.playlistlike.index',compact('playlistlike_data','valid_login'));
	}
	
	public function rating(){
		
		$valid_login = Auth::user();
        if($valid_login->role_id <> 1) { return redirect('admin/auth/logout'); }
        
        $rating_data = DB::table('track_ratings')->select('track_id','track_title','rating')->paginate(20);
        $unique_records = array();
        foreach($rating_data as $rating_datas){
			
        $data_rate = TrackRate::select('rating','track_title')->whereTrackId($rating_datas->track_id)->get();
           
                $total_record = count($data_rate->toArray());
                
                $sum = 0;
                foreach ($data_rate->toArray() as $key => $value) {
					
                    $sum = $sum + $value['rating'];
                }
            $average = round($sum/$total_record);
            $unique_records[$value['track_title']] = $average;
        
           }
           return view('admin.ratelist.index',compact('unique_records','rating_data','valid_login'));
	   }  
        
	public function Favourite(){
		 
		$valid_login = Auth::user();
        if($valid_login->role_id <> 1) { return redirect('admin/auth/logout'); }
        
			$Favourite_data = DB::table('playlist_favorites')
			->join('splash_playlists', 'playlist_favorites.playlist_id','=','splash_playlists.id')
			->select('splash_playlists.playlist_name','playlist_favorites.no_of_favorites','playlist_favorites.user_id')
			->groupBy('splash_playlists.id')->paginate(config('client.no_of_records'));
			
/*$Favourite_data = DB::select("SELECT splash_playlists.playlist_name,playlist_favorites.playlist_id,count(playlist_favorites.user_id) AS favcount
FROM playlist_favorites LEFT JOIN splash_playlists ON (playlist_favorites.playlist_id=splash_playlists.id) GROUP BY splash_playlists.id");
*/			
           return view('admin.favourite.index',compact('Favourite_data','valid_login'));
	   }
	   
	   public function favourite_asc(){
		 
		$valid_login = Auth::user();
        if($valid_login->role_id <> 1) { return redirect('admin/auth/logout'); }
        
			$Favourite_data = DB::table('playlist_favorites')
			->join('splash_playlists', 'playlist_favorites.playlist_id','=','splash_playlists.id')
			->select('splash_playlists.playlist_name','playlist_favorites.no_of_favorites','playlist_favorites.user_id')
			->orderBy('splash_playlists.playlist_name','asc')
			->groupBy('splash_playlists.id')->get();
					
           return view('admin.favourite.sort',compact('Favourite_data','valid_login'));
	   }
	   
	   public function favourite_desc(){
		 
		$valid_login = Auth::user();
        if($valid_login->role_id <> 1) { return redirect('admin/auth/logout'); }
        
			$Favourite_data = DB::table('playlist_favorites')
			->join('splash_playlists', 'playlist_favorites.playlist_id','=','splash_playlists.id')
			->select('splash_playlists.playlist_name','playlist_favorites.no_of_favorites','playlist_favorites.user_id')
			->orderBy('splash_playlists.playlist_name','desc')
			->groupBy('splash_playlists.id')->get();
					
           return view('admin.favourite.sort',compact('Favourite_data','valid_login'));
	   }
	   
	   public function listensongs_asc(){
		 
		$valid_login = Auth::user();
        if($valid_login->role_id <> 1) { return redirect('admin/auth/logout'); }
        
			$listensong = DB::table('listen_song')
							->select('track_id','playlist_title','track_title','no_of_listen')
							   ->orderBy('track_title','asc')
								->groupBy('track_id')
									->get();
					
           return view('admin.listensongs.sort',compact('listensong','valid_login'));
	   }
	   
	   public function listensongs_desc(){
		 
		$valid_login = Auth::user();
        if($valid_login->role_id <> 1) { return redirect('admin/auth/logout'); }
        
			$listensong = DB::table('listen_song')
							->select('track_id','playlist_title','track_title','no_of_listen')
							   ->orderBy('track_title','desc')
								->groupBy('track_id')
									->get();
					
           return view('admin.listensongs.sort',compact('listensong','valid_login'));
	   }
	   
	   public function skipsongs_asc(){
		 
		$valid_login = Auth::user();
        if($valid_login->role_id <> 1) { return redirect('admin/auth/logout'); }
        
			$skipsongs = DB::table('skip_song')
							->select('track_id','playlist_title','track_title','no_of_skip')
							  ->orderBy('track_title','asc')
								->groupBy('track_id')
									->get();
					
           return view('admin.skipsongs.sort',compact('skipsongs'));
	   }
	   
	   public function skipsongs_desc(){
		 
		$valid_login = Auth::user();
        if($valid_login->role_id <> 1) { return redirect('admin/auth/logout'); }
        
			$skipsongs = DB::table('skip_song')
							->select('track_id','playlist_title','track_title','no_of_skip')
							  ->orderBy('track_title','desc')
								->groupBy('track_id')
									->get();
					
           return view('admin.skipsongs.sort',compact('skipsongs'));
	   }
	
	
		public function daily_login(Request $request, $day){
			
			$valid_login = Auth::user();
        if($valid_login->role_id <> 1) { return redirect('admin/auth/logout'); }
        
    if($day==1){
        $start_cur_date = date("Y-m-d",strtotime('monday this week'));
        $start_cur_date = $start_cur_date." 00:00:00";
        
        $end_cur_date = date("Y-m-d",strtotime('monday this week'));
        $end_cur_date = $end_cur_date." 23:59:59";
	} 
	
	if($day==2){
        $start_cur_date = date("Y-m-d",strtotime('tuesday this week'));
        $start_cur_date = $start_cur_date." 00:00:00";
        
        $end_cur_date = date("Y-m-d",strtotime('tuesday this week'));
        $end_cur_date = $end_cur_date." 23:59:59";
	} 
	
	if($day==3){
        $start_cur_date = date("Y-m-d",strtotime('wednesday this week'));
        $start_cur_date = $start_cur_date." 00:00:00";
        
        $end_cur_date = date("Y-m-d",strtotime('wednesday this week'));
        $end_cur_date = $end_cur_date." 23:59:59";
	} 
	
	if($day==4){
        $start_cur_date = date("Y-m-d",strtotime('thursday this week'));
        $start_cur_date = $start_cur_date." 00:00:00";
        
        $end_cur_date = date("Y-m-d",strtotime('thursday this week'));
        $end_cur_date = $end_cur_date." 23:59:59";
	} 
	
	if($day==5){
        $start_cur_date = date("Y-m-d",strtotime('friday this week'));
        $start_cur_date = $start_cur_date." 00:00:00";
        
        $end_cur_date = date("Y-m-d",strtotime('friday this week'));
        $end_cur_date = $end_cur_date." 23:59:59";
	} 
	
	if($day==6){
        $start_cur_date = date("Y-m-d",strtotime('saturday this week'));
        $start_cur_date = $start_cur_date." 00:00:00";
        
        $end_cur_date = date("Y-m-d",strtotime('saturday this week'));
        $end_cur_date = $end_cur_date." 23:59:59";
	} 
	
	if($day==7){
        $start_cur_date = date("Y-m-d",strtotime('sunday this week'));
        $start_cur_date = $start_cur_date." 00:00:00";
        
        $end_cur_date = date("Y-m-d",strtotime('sunday this week'));
        $end_cur_date = $end_cur_date." 23:59:59";
	} 
	
		$flogindetail_data = DB::select("SELECT login_details.user_id,login_details.created_at,login_details.logout_time,login_details.time_duration,users.username,users.first_name,users.last_name
       FROM login_details LEFT JOIN users ON (login_details.user_id=users.id) where login_details.created_at between '".$start_cur_date."' and '".$end_cur_date."'");
		
	return view('admin.logindetail.daily',compact('flogindetail_data','valid_login','day'));		
		}
		
		public function daily_skipsongs(Request $request, $day){
			
			$valid_login = Auth::user();
        if($valid_login->role_id <> 1) { return redirect('admin/auth/logout'); }
        
    if($day==1){
        $start_cur_date = date("Y-m-d",strtotime('monday this week'));
        $start_cur_date = $start_cur_date." 00:00:00";
        
        $end_cur_date = date("Y-m-d",strtotime('monday this week'));
        $end_cur_date = $end_cur_date." 23:59:59";
	} 
	
	if($day==2){
        $start_cur_date = date("Y-m-d",strtotime('tuesday this week'));
        $start_cur_date = $start_cur_date." 00:00:00";
        
        $end_cur_date = date("Y-m-d",strtotime('tuesday this week'));
        $end_cur_date = $end_cur_date." 23:59:59";
	} 
	
	if($day==3){
        $start_cur_date = date("Y-m-d",strtotime('wednesday this week'));
        $start_cur_date = $start_cur_date." 00:00:00";
        
        $end_cur_date = date("Y-m-d",strtotime('wednesday this week'));
        $end_cur_date = $end_cur_date." 23:59:59";
	} 
	
	if($day==4){
        $start_cur_date = date("Y-m-d",strtotime('thursday this week'));
        $start_cur_date = $start_cur_date." 00:00:00";
        
        $end_cur_date = date("Y-m-d",strtotime('thursday this week'));
        $end_cur_date = $end_cur_date." 23:59:59";
	} 
	
	if($day==5){
        $start_cur_date = date("Y-m-d",strtotime('friday this week'));
        $start_cur_date = $start_cur_date." 00:00:00";
        
        $end_cur_date = date("Y-m-d",strtotime('friday this week'));
        $end_cur_date = $end_cur_date." 23:59:59";
	} 
	
	if($day==6){
        $start_cur_date = date("Y-m-d",strtotime('saturday this week'));
        $start_cur_date = $start_cur_date." 00:00:00";
        
        $end_cur_date = date("Y-m-d",strtotime('saturday this week'));
        $end_cur_date = $end_cur_date." 23:59:59";
	} 
	
	if($day==7){
        $start_cur_date = date("Y-m-d",strtotime('sunday this week'));
        $start_cur_date = $start_cur_date." 00:00:00";
        
        $end_cur_date = date("Y-m-d",strtotime('sunday this week'));
        $end_cur_date = $end_cur_date." 23:59:59";
	} 
	
		$skipsongs = DB::select("SELECT playlist_title,track_title,Count(id) as SkipCount FROM skip_song WHERE created_at BETWEEN '".$start_cur_date."' AND '".$end_cur_date."' GROUP BY track_id");
  
	return view('admin.skipsongs.daily',compact('skipsongs','valid_login','day'));
				
		}
		
	public function daily_favorites(Request $request, $day){
			
			$valid_login = Auth::user();
        if($valid_login->role_id <> 1) { return redirect('admin/auth/logout'); }
        
    if($day==1){
        $start_cur_date = date("Y-m-d",strtotime('monday this week'));
        $start_cur_date = $start_cur_date." 00:00:00";
        
        $end_cur_date = date("Y-m-d",strtotime('monday this week'));
        $end_cur_date = $end_cur_date." 23:59:59";
	} 
	
	if($day==2){
        $start_cur_date = date("Y-m-d",strtotime('tuesday this week'));
        $start_cur_date = $start_cur_date." 00:00:00";
        
        $end_cur_date = date("Y-m-d",strtotime('tuesday this week'));
        $end_cur_date = $end_cur_date." 23:59:59";
	} 
	
	if($day==3){
        $start_cur_date = date("Y-m-d",strtotime('wednesday this week'));
        $start_cur_date = $start_cur_date." 00:00:00";
        
        $end_cur_date = date("Y-m-d",strtotime('wednesday this week'));
        $end_cur_date = $end_cur_date." 23:59:59";
	} 
	
	if($day==4){
        $start_cur_date = date("Y-m-d",strtotime('thursday this week'));
        $start_cur_date = $start_cur_date." 00:00:00";
        
        $end_cur_date = date("Y-m-d",strtotime('thursday this week'));
        $end_cur_date = $end_cur_date." 23:59:59";
	} 
	
	if($day==5){
        $start_cur_date = date("Y-m-d",strtotime('friday this week'));
        $start_cur_date = $start_cur_date." 00:00:00";
        
        $end_cur_date = date("Y-m-d",strtotime('friday this week'));
        $end_cur_date = $end_cur_date." 23:59:59";
	} 
	
	if($day==6){
        $start_cur_date = date("Y-m-d",strtotime('saturday this week'));
        $start_cur_date = $start_cur_date." 00:00:00";
        
        $end_cur_date = date("Y-m-d",strtotime('saturday this week'));
        $end_cur_date = $end_cur_date." 23:59:59";
	} 
	
	if($day==7){
        $start_cur_date = date("Y-m-d",strtotime('sunday this week'));
        $start_cur_date = $start_cur_date." 00:00:00";
        
        $end_cur_date = date("Y-m-d",strtotime('sunday this week'));
        $end_cur_date = $end_cur_date." 23:59:59";
	} 
	
		$Favourite_data = DB::select("SELECT splash_playlists.playlist_name,playlist_favorites.playlist_id,count(playlist_favorites.user_id) AS favcount
FROM playlist_favorites LEFT JOIN splash_playlists ON (playlist_favorites.playlist_id=splash_playlists.id) WHERE playlist_favorites.created_at BETWEEN '".$start_cur_date."' AND '".$end_cur_date."' GROUP BY splash_playlists.id");
	
	return view('admin.favourite.daily',compact('Favourite_data','valid_login','day'));		
		}
		 
	public function weekly_login(Request $request, $week){
		
		$valid_login = Auth::user();
        if($valid_login->role_id <> 1) { return redirect('admin/auth/logout'); }
        
		if($week==1){
			$start_cur_date = date('Y-m-')."01"." 00:00:00";
			$end_cur_date = date('Y-m-')."07"." 23:59:59";
		}
		if($week==2){
			$start_cur_date = date('Y-m-')."07"." 00:00:00";
			$end_cur_date = date('Y-m-')."14"." 23:59:59";
		}
		if($week==3){
			$start_cur_date = date('Y-m-')."14"." 00:00:00";
			$end_cur_date = date('Y-m-')."21"." 23:59:59";
		}
		if($week==4){
			$start_cur_date = date('Y-m-')."21"." 00:00:00";
			$end_cur_date = date('Y-m-')."28"." 23:59:59";
		}
		
		$flogindetail_data = DB::select("SELECT login_details.user_id,login_details.created_at,login_details.logout_time,login_details.time_duration,users.username,users.first_name,users.last_name
       FROM login_details LEFT JOIN users ON (login_details.user_id=users.id) where login_details.created_at between '".$start_cur_date."' and '".$end_cur_date."'");
		
		return view('admin.logindetail.weekly',compact('flogindetail_data','valid_login','week'));	
	}
	
	
	public function weekly_skipsongs(Request $request, $week){
			
			$valid_login = Auth::user();
        if($valid_login->role_id <> 1) { return redirect('admin/auth/logout'); }
        
		if($week==1){
			$start_cur_date = date('Y-m-')."01"." 00:00:00";
			$end_cur_date = date('Y-m-')."07"." 23:59:59";
		}
		if($week==2){
			$start_cur_date = date('Y-m-')."07"." 00:00:00";
			$end_cur_date = date('Y-m-')."14"." 23:59:59";
		}
		if($week==3){
			$start_cur_date = date('Y-m-')."14"." 00:00:00";
			$end_cur_date = date('Y-m-')."21"." 23:59:59";
		}
		if($week==4){
			$start_cur_date = date('Y-m-')."21"." 00:00:00";
			$end_cur_date = date('Y-m-')."28"." 23:59:59";
		}
	
		$skipsongs = DB::select("SELECT playlist_title,track_title,Count(id) as SkipCount FROM skip_song WHERE created_at BETWEEN '".$start_cur_date."' AND '".$end_cur_date."' GROUP BY track_id");
  
	return view('admin.skipsongs.weekly',compact('skipsongs','valid_login','week'));
				
		}
	
	public function weekly_favorites(Request $request, $week){
		
		$valid_login = Auth::user();
		
        if($valid_login->role_id <> 1) { return redirect('admin/auth/logout'); }
        
		if($week==1){
			$start_cur_date = date('Y-m-')."01"." 00:00:00";
			$end_cur_date = date('Y-m-')."07"." 23:59:59";
		}
		if($week==2){
			$start_cur_date = date('Y-m-')."07"." 00:00:00";
			$end_cur_date = date('Y-m-')."14"." 23:59:59";
		}
		if($week==3){
			$start_cur_date = date('Y-m-')."14"." 00:00:00";
			$end_cur_date = date('Y-m-')."21"." 23:59:59";
		}
		if($week==4){
			$start_cur_date = date('Y-m-')."21"." 00:00:00";
			$end_cur_date = date('Y-m-')."28"." 23:59:59";
		}
		
		$Favourite_data = DB::select("SELECT splash_playlists.playlist_name,playlist_favorites.playlist_id,count(playlist_favorites.user_id) AS favcount
FROM playlist_favorites LEFT JOIN splash_playlists ON (playlist_favorites.playlist_id=splash_playlists.id) WHERE playlist_favorites.created_at BETWEEN '".$start_cur_date."' AND '".$end_cur_date."' GROUP BY splash_playlists.id");
	
		return view('admin.favourite.weekly',compact('Favourite_data','valid_login','week'));
		
	}
	
	public function monthly_login(Request $request, $month){
		
		$valid_login = Auth::user();
        if($valid_login->role_id <> 1) { return redirect('admin/auth/logout'); }
		
		$flogindetail_data = DB::select("SELECT login_details.user_id,login_details.created_at,login_details.logout_time,login_details.time_duration,users.username,users.first_name,users.last_name
       FROM login_details LEFT JOIN users ON (login_details.user_id=users.id) where login_details.created_at LIKE '%".date("Y")."-".$month."%'");
		
		return view('admin.logindetail.monthly',compact('flogindetail_data','valid_login','month'));	
	}
	
	public function monthly_favorites(Request $request, $month){
		
		$valid_login = Auth::user();
		
        if($valid_login->role_id <> 1) { return redirect('admin/auth/logout'); }
        
		$Favourite_data = DB::select("SELECT splash_playlists.playlist_name,playlist_favorites.playlist_id,count(playlist_favorites.playlist_id) AS favcount
FROM playlist_favorites RIGHT JOIN splash_playlists ON (playlist_favorites.playlist_id=splash_playlists.id) WHERE playlist_favorites.created_at LIKE '%".date("Y")."-".$month."%' GROUP BY playlist_favorites.playlist_id");
	
		return view('admin.favourite.monthly',compact('Favourite_data','valid_login','month'));
		
	}
	
	public function monthly_skipsongs(Request $request, $month){
		
		$valid_login = Auth::user();
		
        if($valid_login->role_id <> 1) { return redirect('admin/auth/logout'); }
        
		$skipsongs = DB::select("SELECT playlist_title,track_title,Count(id) as SkipCount FROM skip_song WHERE created_at LIKE '%".date("Y")."-".$month."%' GROUP BY track_id");
  
	return view('admin.skipsongs.monthly',compact('skipsongs','valid_login','month'));
		
	}
	
	public function search(Request $reuest, $type){
		
		$valid_login = Auth::user();
        if($valid_login->role_id <> 1) { return redirect('admin/auth/logout'); }
        
        $cur_date = date('Y-m-d H:i:s');
		$cur_date = strtotime($cur_date);
		$week_start_date = strtotime('-7 day', $cur_date);
			
		$week_start_date = date('Y-m-d h:i:s', $week_start_date);
		$week_end_date = date('Y-m-d').' 23:59:59';
        
		if($type=="daily"){
			
		$start_cur_date = date("Y-m-d");
		$end_cur_date = date("Y-m-d")." 23:59:59";
			
		$search_result = DB::select("SELECT login_details.user_id,login_details.created_at,login_details.logout_time,login_details.time_duration,users.username,users.first_name,users.last_name
       FROM login_details LEFT JOIN users ON (login_details.user_id=users.id) where login_details.created_at between '".$start_cur_date."' and '".$end_cur_date."'");
		}
		
		if($type=="weekly"){
			
			$search_result = DB::select("SELECT login_details.user_id,login_details.created_at,login_details.logout_time,login_details.time_duration,users.username,users.first_name,users.last_name
       FROM login_details LEFT JOIN users ON (login_details.user_id=users.id) where login_details.created_at between '".$week_start_date."' and '".$week_end_date."'");
		
		}
		
		if($type=="monthly"){
			
			$search_result = DB::select("SELECT login_details.user_id,login_details.created_at,login_details.logout_time,login_details.time_duration,users.username,users.first_name,users.last_name
       FROM login_details LEFT JOIN users ON (login_details.user_id=users.id) where login_details.created_at LIKE '%".date("m")."%'");
		
		}
		return view('admin.logindetail.search',compact('search_result','valid_login','type','week_start_date','week_end_date'));
		
	}
	
	public function search_playlist_like(Request $request, $type){
		$valid_login = Auth::user();
        if($valid_login->role_id <> 1) { return redirect('admin/auth/logout'); }
        
        $cur_date = date('Y-m-d H:i:s');
		$cur_date = strtotime($cur_date);
		$week_start_date = strtotime('-7 day', $cur_date);
			
		$week_start_date = date('Y-m-d h:i:s', $week_start_date);
		$week_end_date = date('Y-m-d').' 23:59:59';
        
		if($type=="daily"){
			
		$start_cur_date = date("Y-m-d");
		$end_cur_date = date("Y-m-d")." 23:59:59";
		
$playlistlike_data = DB::select("SELECT splash_playlists.playlist_name,SUM(CASE WHEN type = 1 THEN 1 ELSE 0 END) AS LikeCount, 
       SUM(CASE WHEN type = 0 THEN 1 ELSE 0 END) AS DisLikeCount FROM splash_playlists LEFT JOIN playlist_likes ON (playlist_likes.playlist_id=splash_playlists.playlist_id) WHERE playlist_likes.created_at BETWEEN '".$start_cur_date."' AND '".$end_cur_date."' GROUP BY splash_playlists.id");
           
		}
		
		if($type=="weekly"){
		
$playlistlike_data = DB::select("SELECT splash_playlists.playlist_name,SUM(CASE WHEN type = 1 THEN 1 ELSE 0 END) AS LikeCount, 
       SUM(CASE WHEN type = 0 THEN 1 ELSE 0 END) AS DisLikeCount FROM splash_playlists LEFT JOIN playlist_likes ON (playlist_likes.playlist_id=splash_playlists.playlist_id) where playlist_likes.created_at between '".$week_start_date."' and '".$week_end_date."' GROUP BY splash_playlists.id");
           
		}
		
		if($type=="monthly"){
			
			$playlistlike_data = DB::select("SELECT splash_playlists.playlist_name,SUM(CASE WHEN type = 1 THEN 1 ELSE 0 END) AS LikeCount, 
       SUM(CASE WHEN type = 0 THEN 1 ELSE 0 END) AS DisLikeCount FROM splash_playlists LEFT JOIN playlist_likes ON (playlist_likes.playlist_id=splash_playlists.playlist_id) where playlist_likes.created_at LIKE '%".date("m")."%' GROUP BY splash_playlists.id");
           
		}
		
		return view('admin.playlistlike.searchplaylistlike',compact('playlistlike_data','valid_login','type','week_start_date','week_end_date'));
		
	}
	
	public function search_rating(Request $request, $type){
		die($type);
		
	}
	
	public function search_favorite(Request $request, $type){
		$valid_login = Auth::user();
        if($valid_login->role_id <> 1) { return redirect('admin/auth/logout'); }
        
        $cur_date = date('Y-m-d H:i:s');
		$cur_date = strtotime($cur_date);
		$week_start_date = strtotime('-7 day', $cur_date);
			
		$week_start_date = date('Y-m-d h:i:s', $week_start_date);
		$week_end_date = date('Y-m-d').' 23:59:59';
        
		if($type=="daily"){
			
		$start_cur_date = date("Y-m-d");
		$end_cur_date = date("Y-m-d")." 23:59:59";
		
$Favourite_data = DB::select("SELECT splash_playlists.playlist_name,playlist_favorites.playlist_id,count(playlist_favorites.user_id) AS favcount
FROM playlist_favorites LEFT JOIN splash_playlists ON (playlist_favorites.playlist_id=splash_playlists.id) WHERE playlist_favorites.created_at BETWEEN '".$start_cur_date."' AND '".$end_cur_date."' GROUP BY splash_playlists.id");
		
		}
		
		if($type=="weekly"){
		
$Favourite_data = DB::select("SELECT splash_playlists.playlist_name,playlist_favorites.playlist_id,count(playlist_favorites.user_id) AS favcount
FROM playlist_favorites LEFT JOIN splash_playlists ON (playlist_favorites.playlist_id=splash_playlists.id) WHERE playlist_favorites.created_at BETWEEN '".$week_start_date."' AND '".$week_end_date."' GROUP BY splash_playlists.id");
        
		}
		
		if($type=="monthly"){
			
			$Favourite_data = DB::select("SELECT splash_playlists.playlist_name,playlist_favorites.playlist_id,count(playlist_favorites.user_id) AS favcount
FROM playlist_favorites LEFT JOIN splash_playlists ON (playlist_favorites.playlist_id=splash_playlists.id) WHERE playlist_favorites.created_at LIKE '%".date("m")."%' GROUP BY splash_playlists.id");
   
		}
		
		return view('admin.favourite.searchfavorite',compact('Favourite_data','valid_login','type','week_start_date','week_end_date'));
		
	}
	
	public function search_listensongs(Request $request, $type){
		$valid_login = Auth::user();
        if($valid_login->role_id <> 1) { return redirect('admin/auth/logout'); }
        
        $cur_date = date('Y-m-d H:i:s');
		$cur_date = strtotime($cur_date);
		$week_start_date = strtotime('-7 day', $cur_date);
			
		$week_start_date = date('Y-m-d h:i:s', $week_start_date);
		$week_end_date = date('Y-m-d').' 23:59:59';
        
		if($type=="daily"){
			
		$start_cur_date = date("Y-m-d");
		$end_cur_date = date("Y-m-d")." 23:59:59";
		
$listensong = DB::select("SELECT playlist_title,track_title,Count(id) as ListenCount FROM listen_song WHERE created_at BETWEEN '".$start_cur_date."' AND '".$end_cur_date."' GROUP BY track_id");
          
		}
		
		if($type=="weekly"){
		
$listensong = DB::select("SELECT playlist_title,track_title,Count(id) as ListenCount FROM listen_song WHERE created_at BETWEEN '".$week_start_date."' AND '".$week_end_date."' GROUP BY track_id");
       
		}
		
		if($type=="monthly"){
			
$listensong = DB::select("SELECT playlist_title,track_title,Count(id) as ListenCount FROM listen_song WHERE created_at LIKE '%".date("m")."%' GROUP BY track_id");
  
		}
		
		return view('admin.listensongs.searchlistensongs',compact('listensong','valid_login','type','week_start_date','week_end_date'));
		
	}
	
	
	public function daily_listensongs(Request $request,$day){
		
		
		$valid_login = Auth::user();
        if($valid_login->role_id <> 1) { return redirect('admin/auth/logout'); }
        
    if($day==1){
        $start_cur_date = date("Y-m-d",strtotime('monday this week'));
        $start_cur_date = $start_cur_date." 00:00:00";
        
        $end_cur_date = date("Y-m-d",strtotime('monday this week'));
        $end_cur_date = $end_cur_date." 23:59:59";
	} 
	
	if($day==2){
        $start_cur_date = date("Y-m-d",strtotime('tuesday this week'));
        $start_cur_date = $start_cur_date." 00:00:00";
        
        $end_cur_date = date("Y-m-d",strtotime('tuesday this week'));
        $end_cur_date = $end_cur_date." 23:59:59";
	} 
	
	if($day==3){
        $start_cur_date = date("Y-m-d",strtotime('wednesday this week'));
        $start_cur_date = $start_cur_date." 00:00:00";
        
        $end_cur_date = date("Y-m-d",strtotime('wednesday this week'));
        $end_cur_date = $end_cur_date." 23:59:59";
	} 
	
	if($day==4){
        $start_cur_date = date("Y-m-d",strtotime('thursday this week'));
        $start_cur_date = $start_cur_date." 00:00:00";
        
        $end_cur_date = date("Y-m-d",strtotime('thursday this week'));
        $end_cur_date = $end_cur_date." 23:59:59";
	} 
	
	if($day==5){
        $start_cur_date = date("Y-m-d",strtotime('friday this week'));
        $start_cur_date = $start_cur_date." 00:00:00";
        
        $end_cur_date = date("Y-m-d",strtotime('friday this week'));
        $end_cur_date = $end_cur_date." 23:59:59";
	} 
	
	if($day==6){
        $start_cur_date = date("Y-m-d",strtotime('saturday this week'));
        $start_cur_date = $start_cur_date." 00:00:00";
        
        $end_cur_date = date("Y-m-d",strtotime('saturday this week'));
        $end_cur_date = $end_cur_date." 23:59:59";
	} 
	
	if($day==7){
        $start_cur_date = date("Y-m-d",strtotime('sunday this week'));
        $start_cur_date = $start_cur_date." 00:00:00";
        
        $end_cur_date = date("Y-m-d",strtotime('sunday this week'));
        $end_cur_date = $end_cur_date." 23:59:59";
	}
	
	$listensong = DB::select("SELECT playlist_title,track_title,Count(id) as ListenCount FROM listen_song WHERE created_at BETWEEN '".$start_cur_date."' AND '".$end_cur_date."' GROUP BY track_id");
    
    return view('admin.listensongs.daily',compact('listensong','valid_login','day'));
		
	}
	
	
	public function weekly_listensongs(Request $request,$week){
		
		$valid_login = Auth::user();
		
        if($valid_login->role_id <> 1) { return redirect('admin/auth/logout'); }
        
		if($week==1){
			$start_cur_date = date('Y-m-')."01"." 00:00:00";
			$end_cur_date = date('Y-m-')."07"." 23:59:59";
		}
		if($week==2){
			$start_cur_date = date('Y-m-')."07"." 00:00:00";
			$end_cur_date = date('Y-m-')."14"." 23:59:59";
		}
		if($week==3){
			$start_cur_date = date('Y-m-')."14"." 00:00:00";
			$end_cur_date = date('Y-m-')."21"." 23:59:59";
		}
		if($week==4){
			$start_cur_date = date('Y-m-')."21"." 00:00:00";
			$end_cur_date = date('Y-m-')."28"." 23:59:59";
		}
	
	$listensong = DB::select("SELECT playlist_title,track_title,Count(id) as ListenCount FROM listen_song WHERE created_at BETWEEN '".$start_cur_date."' AND '".$end_cur_date."' GROUP BY track_id");
    
    return view('admin.listensongs.weekly',compact('listensong','valid_login','week'));
		
	}
	
	
	public function monthly_listensongs(Request $request,$month){
	
	
	$listensong = DB::select("SELECT playlist_title,track_title,Count(id) as ListenCount FROM listen_song WHERE created_at LIKE '%".date("Y")."-".$month."%' GROUP BY track_id");
    
    return view('admin.listensongs.monthly',compact('listensong','valid_login','month'));
		
	}
	
	public function search_skipsongs(Request $request, $type){
		
		$valid_login = Auth::user();
        if($valid_login->role_id <> 1) { return redirect('admin/auth/logout'); }
        
        $cur_date = date('Y-m-d H:i:s');
		$cur_date = strtotime($cur_date);
		$week_start_date = strtotime('-7 day', $cur_date);
			
		$week_start_date = date('Y-m-d h:i:s', $week_start_date);
		$week_end_date = date('Y-m-d').' 23:59:59';
        
		if($type=="daily"){
			
		$start_cur_date = date("Y-m-d");
		$end_cur_date = date("Y-m-d")." 23:59:59";
		
$skipsongs = DB::select("SELECT playlist_title,track_title,Count(id) as SkipCount FROM skip_song WHERE created_at BETWEEN '".$start_cur_date."' AND '".$end_cur_date."' GROUP BY track_id");
               
		}
		
		if($type=="weekly"){
		
$skipsongs = DB::select("SELECT playlist_title,track_title,Count(id) as SkipCount FROM skip_song WHERE created_at BETWEEN '".$week_start_date."' AND '".$week_end_date."' GROUP BY track_id");
        
		}
		
		if($type=="monthly"){
			
$skipsongs = DB::select("SELECT playlist_title,track_title,Count(id) as SkipCount FROM skip_song WHERE created_at LIKE '%".date("m")."%' GROUP BY track_id");
  
		}
		
		 return view('admin.skipsongs.searchskipsongs',compact('skipsongs','valid_login','type','week_start_date','week_end_date'));
		
	}
	    
}
