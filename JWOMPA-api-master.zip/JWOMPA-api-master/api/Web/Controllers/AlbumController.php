<?php

namespace Api\Web\Controllers;

use Api\Master\Models\User;
Use Api\Master\Models\Album;
use Auth;
use Redirect;
use Validator;
Use Hash;
use Infrastructure\Http\Controller;

use Illuminate\Http\Request;


class AlbumController extends Controller
{
   /* ******************* Add Album ************************** */
     public function create()
    {
        return view('admin.album.create');
    }
    
    public function store(Request $request)
    {
       $this->validate($request, [
        'name' => 'required|min:4|unique:albums',
       ]);
       
       $imageName = "";
       
       $input = array();
        
        if($request->file('image_url') != "")
         {
  
		   $imageName = time() . '.' . $request->file('image_url')->getClientOriginalExtension();
		   
		   $path = public_path().'/albums/';
		   if(!is_dir($path)) { mkdir($path); }  
		   
		   $request->file('image_url')->move(base_path() . '/public/albums/', $imageName); 
		   
		  /* if($request->file('profile_image')!="uplode_photo.png"){
			@unlink($path . "/" . $user->photo);
		   }*/
   
		}
		
		 $input['name'] =  $request->name;
		 $input['image_url'] =  $imageName;
		 $input['staus'] =  1;
         Album::create($input);
        
         return \Redirect::back()->withSuccess( 'Album Created Successfully' );
        
    }
    
    
    /* ******************* Add Album ************************** */
    
     /* ******************* Album Listing ************************** */
    public function index()
    {   
		$albums = Album::paginate(10);
		
        return view('admin.album.index',compact('albums'));
    }
    
     /* ******************* Album View ************************** */
    
    public function view(Request $reuest, $id)
    {   
		$album = Album::findOrFail($id);
		return view('admin.album.view',compact('album'));
	}
   
   /* ******************* Album Edit ************************** */
   
    public function edit(Request $reuest, $id)
    {   
		$album = Album::findOrFail($id);
		return view('admin.album.edit',compact('album'));
	}
	
	 public function update(Request $request, $id)
      {
        
         $this->validate($request, [
        'name' => 'required|min:4|unique:albums,name,'.$id,
        ]);

        $album = Album::findOrFail($id);
        
      
        
         $imageName = "";
         $input = $request->all();
        
       
        if($request->file('image_url') != "")
         {
  
		   $imageName = time() . '.' . $request->file('image_url')->getClientOriginalExtension();
		   
		   $path = public_path().'/albums/';
		   if(!is_dir($path)) { mkdir($path); }  
		   
		   $request->file('image_url')->move(base_path() . '/public/albums/',$imageName); 
		   
		  /* if($request->file('profile_image')!="uplode_photo.png"){
			@unlink($path . "/" . $user->photo);
		   }*/
   
		}
		if(!empty($imageName))
		{
		   $input['image_url'] = $imageName;
	    }
	  
        
          $album->fill($input)->save();
        
        
       return \Redirect::back()->withSuccess( 'Album Updated Successfully' );
      }
      
     /* ***************** Album delete *************** */
     
     public function destroy($id)
    {
       
        $album = Album::find($id)->delete();
        return redirect('admin/displayAlbum')->withSuccess( 'Album Deleted Successfully' );;
    } 
      
    
}
