<?php

namespace Api\Web\Controllers;

use Api\Master\Models\User;
use Api\Master\Models\Category;
Use DB;
use Auth;
use Redirect;
use Validator;
Use Hash;
use Api\Master\Models\Cms;
use Infrastructure\Http\Controller;

		
use Illuminate\Http\Request;


class CmsController extends Controller
{
     /* ******************* Cms Listing ************************** */
    public function index()
    {   
		$cms = DB::table('cms')->get();
        return view('admin.cms.index',compact('cms'));
    }
    
    public function edit(Request $request, $id)
	    {   
			$cmslist = Cms::findOrFail($id);
			return view('admin.cms.edit',compact('cmslist'));
		}
    
    public function update(Request $request, $id)
	      { 
	        $Cmslist = Cms::findOrFail($id);
			$input = $request->all();
			$Cmslist->fill($input)->save();
	        return redirect('admin/cms')->withSuccess( 'Cms List Updated Successfully' );	   
	       }
}
