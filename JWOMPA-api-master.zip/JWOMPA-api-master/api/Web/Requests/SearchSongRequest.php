<?php

namespace Api\Web\Requests;

use Infrastructure\Http\ApiRequest;

class SearchSongRequest extends ApiRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'keyword' => 'required'
        ];
    }
}
