<?php

$router->group(['prefix' => config('routes.admin_prefix'), 'middleware' => ['web','admin']], function () use($router){
	$router->get('/login',['as'=>'admin/login', 'uses' =>'LoginController@getLogin']);
	$router->post('/login',['as'=>'admin/login', 'uses' =>'LoginController@postLogin']);
	$router->get('/logout',['as'=>'admin/logout', 'uses' =>'LoginController@getLogout']);
	$router->get('/dashboard',['as'=>'admin/dashboard', 'uses' =>'LoginController@getDashboard']);
		//User Edit
	$router->get('/editUser/{id}', ['as' => 'admin/editUser', 'uses' =>'UserController@edit']);
	$router->post('/editUser/{id}', ['as' => 'admin/edituser', 'uses' =>'UserController@update']);
	//User Delete
	$router->get('/deleteuser/{id}', ['as' => 'admin/deleteUser', 'uses' =>'UserController@destroy']);
	$router->get('/profile/{id}', ['as' => 'admin/profile', 'uses' =>'AdminController@getProfile']);
	$router->post('/profile/{id}', ['as' => 'admin/profile', 'uses' =>'AdminController@postProfile']);
	// Admin Change Password 
	$router->get('/changePassword', ['as' => 'admin/changePassword', 'uses' =>'AdminController@changePassword']);
	$router->post('/changePassword', ['as' => 'admin/changePassword', 'uses' =>'AdminController@setPassword']);
	//Add New Album
	$router->get('/addAlbum', ['as' => 'admin/addAlbum', 'uses' =>'AlbumController@create']);
	$router->post('/addAlbum', ['as' => 'admin/addAlbum', 'uses' =>'AlbumController@store']);
	//Album Listing
	$router->get('/displayAlbum', ['as' => 'admin/displayAlbum', 'uses' =>'AlbumController@index']);
	//Album View
	$router->get('/viewAlbum/{id}', ['as' => 'admin/viewAlbum', 'uses' =>'AlbumController@view']);
	//Album Edit
	$router->get('/editAlbum/{id}', ['as' => 'admin/editAlbum', 'uses' =>'AlbumController@edit']);
	$router->post('/editAlbum/{id}', ['as' => 'admin/editAlbum', 'uses' =>'AlbumController@update']);
	//Album Delete
	$router->get('/deleteAlbum/{id}', ['as' => 'admin/deleteAlbum', 'uses' =>'AlbumController@destroy']);
	//Add New Singer
	$router->get('/addSinger', ['as' => 'admin/addSinger', 'uses' =>'SingerController@create']);
	$router->post('/addSinger', ['as' => 'admin/addSinger', 'uses' =>'SingerController@store']);
	//Singer Listing
	$router->get('/displaySinger', ['as' => 'admin/displaySinger', 'uses' =>'SingerController@index']);
	//Singer View
	$router->get('/viewSinger/{id}', ['as' => 'admin/viewSinger', 'uses' =>'SingerController@view']);
	//Singer Edit
	$router->get('/editSinger/{id}', ['as' => 'admin/editSinger', 'uses' =>'SingerController@edit']);
	$router->post('/editSinger/{id}', ['as' => 'admin/editSinger', 'uses' =>'SingerController@update']);
	//Singer Delete
	$router->get('/deleteSinger/{id}', ['as' => 'admin/deleteSinger', 'uses' =>'SingerController@destroy']);
	//Add New User
	$router->get('/addUser', ['as' => 'admin/addUser', 'uses' =>'UserController@create']);
	$router->post('/addUser', ['as' => 'admin/addUser', 'uses' =>'UserController@store']);
	//User Listing
	$router->get('/displayUser', ['as' => 'admin/displayUser', 'uses' =>'UserController@index']);
	//User View
	$router->get('/viewUser/{id}', ['as' => 'admin/viewUser', 'uses' =>'UserController@view']);
	
	/* ****************************** Category ********************************* */
	
	//Add New Category
	$router->get('/addCategory', ['as' => 'admin/addCategory', 'uses' =>'CategoryController@create']);
	$router->post('/addCategory', ['as' => 'admin/addCategory', 'uses' =>'CategoryController@store']);
	
	//Category Listing
	$router->get('/displayCategory', ['as' => 'admin/displayCategory', 'uses' =>'CategoryController@index']);
	$router->get('/displayParentCategory', ['as' => 'admin/displayParentCategory', 'uses' =>'CategoryController@displayParentCategory']);
	
	//Category View
	$router->get('/viewCategory/{id}', ['as' => 'admin/viewCategory', 'uses' =>'CategoryController@view']);

	$router->get('/viewPlaylist/{id}', ['as' => 'admin/viewPlaylist', 'uses' =>'CategoryController@viewPlaylist']);
	
	//Category Edit
	$router->get('/editCategory/{id}', ['as' => 'admin/editCategory', 'uses' =>'CategoryController@edit']);
	$router->post('/editCategory/{id}',['as'=>'editCategory','uses'=>'CategoryController@update']);
	
	$router->get('/editUser/{id}', ['as' => 'admin/editUser', 'uses' =>'UserController@edit']);
	$router->post('/editUser/{id}', ['as' => 'admin/edituser', 'uses' =>'UserController@update']);
	
	//Category Delete
	$router->get('/deleteCategory/{id}', ['as' => 'admin/deleteCategory', 'uses' =>'CategoryController@destroy']);
	$router->get('/deleteParentCategory/{id}', ['as' => 'admin/deleteParentCategory', 'uses' =>'CategoryController@delete_parent']);
	
	/* ****************************** Category ********************************* */
	
	/* ****************************** Cms ********************************* */
	
	$router->get('/cms', ['as' => 'admin/cms', 'uses' =>'CmsController@index']);
	$router->get('/cmsedit/{id}', ['as' => 'admin/cmsedit', 'uses' =>'CmsController@edit']);
	$router->post('/cmsedit/{id}', ['as' => 'admin/cmsedit', 'uses' =>'CmsController@update']);
	
	/* ****************************** Cms ********************************* */
	
	$router->get('/feedbacCategory', ['as' => 'admin/feedbacCategory', 'uses' =>'CmsController@index']);
	$router->get('/cmsedit/{id}', ['as' => 'admin/cmsedit', 'uses' =>'CmsController@edit']);
	
	/* ****************************** Feedback ********************************* */
	
	$router->get('/feedbackcategory', ['as' => 'admin/feedbackcategory', 'uses' =>'FeedbackCategoryController@index']);
	$router->get('/addFeedbackCategory', ['as' => 'admin/addFeedbackCategory', 'uses' =>'FeedbackCategoryController@create']);
	$router->post('/addFeedbackCategory', ['as' => 'admin/addFeedbackCategory', 'uses' =>'FeedbackCategoryController@store']);
	$router->get('/feedbackcategoryedit/{id}', ['as' => 'admin/feedbackcategoryedit', 'uses' =>'FeedbackCategoryController@edit']);
	$router->post('/feedbackcategoryedit/{id}', ['as' => 'admin/feedbackcategoryedit', 'uses' =>'FeedbackCategoryController@update']);
	$router->get('/deletefeedbackcategory/{id}', ['as' => 'admin/deletefeedbackcategory', 'uses' =>'FeedbackCategoryController@destroy']);
	$router->get('/feedbacks', ['as' => 'admin/feedbacks', 'uses' =>'FeedbackCategoryController@feedbacks']);
	/* ****************************** Song ********************************* */
	//Add New Song
	$router->get('/addSong', ['as' => 'admin/addSong', 'uses' =>'SongController@create']);
	$router->post('/addSong', ['as' => 'admin/addSong', 'uses' =>'SongController@store']);
	//Song Listing
	$router->get('/displaySong', ['as' => 'admin/displaySong', 'uses' =>'SongController@index']);
	/* ****************************** Song ********************************* */
	$router->get('/searchSong', ['as' => 'admin/searchSong', 'uses' =>'SongController@searchSong']);
	$router->post('/searchSong', ['as' => 'admin/searchSong', 'uses' =>'SongController@searchSongList']);	
   /* ****************************** Admin Playlist List ************************** */
   // Add Playlist
   $router->get('/addPlaylist', ['as' => 'admin/addPlaylist', 'uses' =>'PlaylistController@create']);
   $router->post('/addPlaylist', ['as' => 'admin/addPlaylist', 'uses' =>'PlaylistController@add']);
   $router->get('/displayPlaylist', ['as' => 'admin/displayPlaylist', 'uses' =>'PlaylistController@display']);
   $router->get('/displayGoLive',['as' => 'admin/displayGoLive', 'uses' =>'PlaylistController@displayGoLive']);
   //Playlist View
   $router->get('/viewPlayList/{id}', ['as' => 'admin/viewPlayList', 'uses' =>'PlaylistController@view']);
   $router->post('/addSondToPlayList', ['as' => 'admin/addSondToPlayList', 'uses' =>'PlaylistController@addSoplay']);
	//Playlist Edit
   $router->get('/editPlayList/{id}', ['as' => 'admin/editPlayList', 'uses' =>'PlaylistController@edit']);
   $router->get('/changePlayListStatus/{id}/{status}', ['as' => 'admin/changePlayListStatus', 'uses' =>'PlaylistController@changePlayListStatus']);
   $router->post('/editPlayList/{id}', ['as' => 'admin/editPlayList', 'uses' =>'PlaylistController@update']);
	//Playlist Delete
   $router->get('/deletePlayList/{id}', ['as' => 'admin/deletePlayList', 'uses' =>'PlaylistController@destroy']);
   $router->get('/TrackNotification/{id}', ['as' => 'admin/TrackNotification', 'uses' =>'SongController@TrackNotification']);
   $router->post('/sendTrackNotification', ['as' => 'admin/sendTrackNotification', 'uses' =>'SongController@sendTrackNotification']);
   $router->get('/PlaylistNotification/{id}', ['as' => 'admin/PlaylistNotification', 'uses' =>'PlaylistController@PlaylistNotification']);
   $router->post('/sendPlaylistNotification', ['as' => 'admin/sendPlaylistNotification', 'uses' =>'PlaylistController@sendPlaylistNotification']);
   /* ****************************** Admin Playlist List *************************** */	
   $router->get('/myPlayList', ['as' => 'admin/myPlayList', 'uses' =>'PlaylistController@myPlayList']);
   $router->get('/playlistSongs/{id}', ['as' => 'admin/playlistSongs', 'uses' =>'PlaylistController@playlistSongs']);
	//Email Manager
	$router->get('/emails', ['as' => 'admin/emails', 'uses' =>'MailController@index']);
	$router->get('/announcements', ['as' => 'admin/announcements', 'uses' =>'AnnouncementController@index']);
	$router->get('/addAnnouncement', ['as' => 'admin/addAnnouncement', 'uses' =>'AnnouncementController@create']);
	$router->post('/addAnnouncement', ['as' => 'admin/addAnnouncement', 'uses' =>'AnnouncementController@createAnnouncement']);
	$router->get('/editAnnouncement/{id}', ['as' => 'admin/editAnnouncement', 'uses' =>'AnnouncementController@editAnnouncement']);
	$router->post('/editAnnouncement/{id}', ['as' => 'admin/editAnnouncement', 'uses' =>'AnnouncementController@edit']);
	$router->get('/deleteAnnouncement/{id}', ['as' => 'admin/deleteAnnouncement', 'uses' =>'AnnouncementController@delete']);
	$router->get('/sendAnnouncementNotification/{id}', ['as' => 'admin/sendAnnouncementNotification', 'uses' =>'AnnouncementController@sendAnnouncementNotification']);
	$router->get('/viewEmail/{id}', ['as' => 'admin/viewEmail', 'uses' =>'MailController@show']);
	$router->get('/editEmail/{id}', ['as' => 'admin/editEmail', 'uses' =>'MailController@edit']);
	$router->post('/editEmail/{id}', ['as' => 'admin/editEmail', 'uses' =>'MailController@update']);
	$router->get('/editSetting', ['as' => 'admin/editSetting', 'uses' =>'SettingController@index']);
	$router->post('/editSetting', ['as' => 'admin/editSetting', 'uses' =>'SettingController@update']);
	$router->post('/editSetting', ['as' => 'admin/editSetting', 'uses' =>'SettingController@update']);
	//Login Manager
	$router->get('/logindetail', ['as' => 'admin/logindetail', 'uses' =>'LoginDetailController@index']);
	$router->get('/search/{type}', ['as' => 'admin/search', 'uses' =>'LoginDetailController@search']);
	//Playlist Like Manager
	$router->get('/playlistlike', ['as' => 'admin/playlistlike', 'uses' =>'LoginDetailController@playlistlike']);
	$router->get('/search-playlist-like/{type}', ['as' => 'admin/search-playlist-like', 'uses' =>'LoginDetailController@search_playlist_like']);
	//Rating Manager
	$router->get('/rating', ['as' => 'admin/rating', 'uses' =>'LoginDetailController@rating']);
	$router->get('/search-rating/{type}', ['as' => 'admin/search-rating', 'uses' =>'LoginDetailController@search_rating']);
	//Favourite Manager
	$router->get('/favourite', ['as' => 'admin/favourite', 'uses' =>'LoginDetailController@Favourite']);
	$router->get('/search-favorite/{type}', ['as' => 'admin/search-favorite', 'uses' =>'LoginDetailController@search_favorite']);
	//Listen Song Manager
	$router->get('/listensongs', ['as' => 'admin/listensongs', 'uses' =>'SongController@listensongs']);
	$router->get('/search-listensongs/{type}', ['as' => 'admin/search-listensongs', 'uses' =>'LoginDetailController@search_listensongs']);
	//Listen Song Manager 
	$router->get('/skipsongs', ['as' => 'admin/skipsongs', 'uses' =>'SongController@skipsongs']);
	$router->get('/search-skipsongs/{type}', ['as' => 'admin/search-skipsongs', 'uses' =>'LoginDetailController@search_skipsongs']);
	//find subcategory using ajax
	$router->get('/findSubCategory', ['as' => 'admin/findSubCategory', 'uses' =>'CategoryController@findSubCategory']);
	//Splashboard playlist
	$router->get('/addSplash', ['as' => 'admin/addSplash', 'uses' =>'PlaylistController@addSplash']);
	$router->post('/storeSplash', ['as' => 'admin/storeSplash', 'uses' =>'PlaylistController@storeSplash']);
	$router->get('/displaySplash', ['as' => 'admin/displaySplash', 'uses' =>'PlaylistController@displaySplash']);
	$router->get('/destroySplash/{id}', ['as' => 'admin/destroySplash', 'uses' =>'PlaylistController@destroySplash']);
	$router->get('/editSplash/{id}', ['as' => 'admin/editSplash', 'uses' =>'PlaylistController@editSplash']);
	$router->post('/editSplash/{id}', ['as' => 'admin/editSplash', 'uses' =>'PlaylistController@updateSplash']);
	$router->get('/pdf', ['as' => 'admin/pdf', 'uses' =>'UserController@pdf']);
	//Download Lists
	$router->get('/downloadSplash', ['as' => 'admin/downloadSplash', 'uses' =>'UserController@downloadSplash']);
	$router->get('/downloadPlaylistLike', ['as' => 'admin/downloadPlaylistLike', 'uses' =>'UserController@downloadPlaylistLike']);
	$router->get('/downloadLoginUser', ['as' => 'admin/downloadLoginUser', 'uses' =>'UserController@downloadLoginUser']);
	$router->get('/downloadRatingList', ['as' => 'admin/downloadRatingList', 'uses' =>'UserController@downloadRatingList']);
	$router->get('/downloadFavourite', ['as' => 'admin/downloadFavourite', 'uses' =>'UserController@downloadFavourite']);
	$router->get('/downloadListensongs', ['as' => 'admin/downloadListensongs', 'uses' =>'UserController@downloadListensongs']);
	$router->get('/downloadskipsongs', ['as' => 'admin/downloadskipsongs', 'uses' =>'UserController@downloadskipsongs']);
	$router->get('/downloadMyPlaylists', ['as' => 'admin/downloadMyPlaylists', 'uses' =>'UserController@downloadMyPlaylists']);
	$router->get('/downloadTrack', ['as' => 'admin/downloadTrack', 'uses' =>'UserController@downloadTrack']);
	$router->get('/downloadFeedback', ['as' => 'admin/downloadFeedback', 'uses' =>'UserController@downloadFeedback']);
	$router->get('/downloadCategory', ['as' => 'admin/downloadCategory', 'uses' =>'UserController@downloadCategory']);
	$router->get('/downloadParentCategory', ['as' => 'admin/downloadParentCategory', 'uses' =>'UserController@downloadParentCategory']);
	$router->get('/downloadUserList', ['as' => 'admin/downloadUserList', 'uses' =>'UserController@downloadUserList']);
	$router->get('/downloadSearchHistory', ['as' => 'admin/downloadSearchHistory', 'uses' =>'UserController@downloadSearchHistory']);

	$router->get('daily-login/{id}', ['as' => 'daily-login', 'uses' =>'LoginDetailController@daily_login']); 
	$router->get('weekly-login/{id}', ['as' => 'weekly-login', 'uses' =>'LoginDetailController@weekly_login']);
	$router->get('monthly-login/{id}', ['as' => 'monthly-login', 'uses' =>'LoginDetailController@monthly_login']);

	$router->get('daily-favorites/{id}', ['as' => 'daily-favorites', 'uses' =>'LoginDetailController@daily_favorites']);
	$router->get('weekly-favorites/{id}', ['as' => 'weekly-favorites', 'uses' =>'LoginDetailController@weekly_favorites']);
	$router->get('monthly-favorites/{id}', ['as' => 'monthly-favorites', 'uses' =>'LoginDetailController@monthly_favorites']);
	 
	$router->get('daily-listensongs/{id}', ['as' => 'daily-listensongs', 'uses' =>'LoginDetailController@daily_listensongs']);
	$router->get('weekly-listensongs/{id}', ['as' => 'weekly-listensongs', 'uses' =>'LoginDetailController@weekly_listensongs']);
	$router->get('monthly-listensongs/{id}', ['as' => 'monthly-listensongs', 'uses' =>'LoginDetailController@monthly_listensongs']);

	$router->get('daily-skipsongs/{id}', ['as' => 'daily-skipsongs', 'uses' =>'LoginDetailController@daily_skipsongs']);
	$router->get('weekly-skipsongs/{id}', ['as' => 'weekly-skipsongs', 'uses' =>'LoginDetailController@weekly_skipsongs']);
	$router->get('monthly-skipsongs/{id}', ['as' => 'monthly-skipsongs', 'uses' =>'LoginDetailController@monthly_skipsongs']);

	$router->get('displayTrack', ['as' => 'admin/displayTrack', 'uses' =>'SongController@all_track']);
	$router->get('displayPlaylistTrack/{id}', ['as' => 'admin/displayPlaylistTrack', 'uses' =>'SongController@displayPlaylistTrack']);

	$router->get('admin/editCatStation/{id}', ['as' => 'admin/editCatStation', 'uses' =>'PlaylistController@editCatStation']);
	$router->post('admin/editCatStation/{id}', ['as' => 'admin/editCatStation', 'uses' =>'PlaylistController@updateCatStation']);
	$router->get('admin/categorystations', ['as' => 'admin/categorystations', 'uses' =>'PlaylistController@categorystations']);
	$router->get('admin/create-category-stations', ['as' => 'admin/create-category-stations', 'uses' =>'PlaylistController@create_category_stations']);
	$router->post('admin/add_categorystations', ['as' => 'admin/add_categorystations', 'uses' =>'PlaylistController@add_categorystations']);
	$router->get('admin/deletecatstation/{id}', ['as' => 'admin/deletecatstation', 'uses' =>'PlaylistController@deletecatstation']);

	$router->post('/sort_splashboard',['as' => 'admin/sort_splashboard', 'uses' => 'PlaylistController@sortSplashBoard']);
	$router->get('/getsubcategorybyid',['as' => 'admin/getsubcategorybyid', 'uses' => 'PlaylistController@getSubCategoryById']);
	$router->get('/searchHistory',['as' => 'admin/searchHistory', 'uses' => 'SongController@searchHistory']);
	$router->post('/searchHistory',['as' => 'admin/searchHistory', 'uses' => 'SongController@search']);
});
