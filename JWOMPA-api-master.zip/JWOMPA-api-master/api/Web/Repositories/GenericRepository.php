<?php

namespace Api\Web\Repositories;

use Api\Master\Models\User;
use Api\Master\Models\Playlists;
use Api\Master\Models\PlaylistTracks;
use Api\Master\Models\Tracks;
use Api\Master\Models\UserSearchKeyword;
use Api\Master\Models\Artists;
use Infrastructure\Database\Eloquent\Repository;
use Api\Master\Models\ValueScreenDetails;
use Api\Master\Models\PlaylistRecent;
use Api\Master\Models\FeedbackCategory;
use Api\Master\Models\Feedback;

use Carbon\Carbon;
use DB;
use Auth;

class GenericRepository extends Repository
{
    public function getModel ()
    {
        return new User();
    }

    private function getPlaylistModel () {
    	return new Playlists;
    }

    private function getPlaylistTracksModel () {
    	return new PlaylistTracks;
    }

    private function getTracksModel () {
    	return new Tracks;
    }

    private function getUserSearchKeywordModel () {
        return new UserSearchKeyword;
    }

    private function getValueScreenDetailsModel () {
        return new ValueScreenDetails;
    }

    private function getPlaylistRecentModel () {
        return new PlaylistRecent;
    }

    private function getArtistModel () {
        return new Artists;
    }

    private function getFeedbackCategoryModel () {
        return new FeedbackCategory;
    }

    private function getFeedbackModel () {
        return new Feedback;
    }

}
