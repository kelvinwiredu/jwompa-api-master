<?php

namespace Api\Mobile\Repositories;

use Api\Mobile\Models\User;
use Api\Master\Models\Playlists;
use Api\Master\Models\PlaylistTracks;
use Api\Master\Models\Tracks;
use Api\Master\Models\UserSearchKeyword;
use Api\Master\Models\Artists;
use Infrastructure\Database\Eloquent\Repository;
use Api\Master\Models\ValueScreenDetails;
use Api\Master\Models\PlaylistRecent;
use Api\Master\Models\FeedbackCategory;
use Api\Master\Models\Feedback;
use Api\Master\Models\PlayListFavorite;
use Api\Master\Models\UserDevice;
use Api\Master\Models\PreferenceOne;
use Api\Master\Models\PreferenceTwo;
use Api\Master\Models\UserPreference;
use Api\Master\Models\TrackLikes;
use Api\Master\Models\TrackRatings;
use Api\Master\Models\ParentCategories;
use Api\Master\Models\Categories;
use Api\Master\Models\CategoryPlaylist;
use Api\Master\Models\Cms;
use Api\Master\Models\TellFriend;
use Api\Master\Models\ListenSong;
use Api\Master\Models\SkipTracks;
use Api\Master\Models\SplashPlaylist;
use Api\Master\Models\SkipSong;

use LaravelFCM\Message\OptionsBuilder;
use LaravelFCM\Message\PayloadDataBuilder;
use LaravelFCM\Message\PayloadNotificationBuilder;
use FCM;
use Carbon\Carbon;
use DB;
use Auth;
use Mail;

class GenericRepository extends Repository
{
    public function getModel ()
    {
        return new User();
    }

    private function getPlaylistModel () {
    	return new Playlists;
    }

    private function getPlaylistTracksModel () {
    	return new PlaylistTracks;
    }

    private function getTracksModel () {
    	return new Tracks;
    }

    private function getUserSearchKeywordModel () {
        return new UserSearchKeyword;
    }

    private function getValueScreenDetailsModel () {
        return new ValueScreenDetails;
    }

    private function getPlaylistRecentModel () {
        return new PlaylistRecent;
    }

    private function getArtistModel () {
        return new Artists;
    }

    private function getFeedbackCategoryModel () {
        return new FeedbackCategory;
    }

    private function getFeedbackModel () {
        return new Feedback;
    }

    private function getPlaylistFavoriteModel () {
        return new PlayListFavorite;
    }

    private function getUserDeviceModel () {
        return new UserDevice;
    }

    private function getPreferenceOneModel () {
        return new PreferenceOne;
    }

    private function getPreferenceTwoModel () {
        return new PreferenceTwo;
    }

    private function getUserPreferenceModel () {
        return new UserPreference;
    }

    private function getTrackLikesModel () {
        return new TrackLikes;
    }

    private function getTrackRatingsModel () {
        return new TrackRatings;
    }

    private function getParentCategoriesModel () {
        return new ParentCategories;
    }

    private function getCategoriesModel () {
        return new Categories;
    }

    private function getCategoryPlaylistModel () {
        return new CategoryPlaylist;
    }

    private function getCmsModel () {
        return new Cms;
    }

    private function getTellFriendModel () {
        return new TellFriend;
    }

    private function getListenSongModel () {
        return new ListenSong;
    }

    private function getSkipTracksModel () {
        return new SkipTracks;
    }

    private function getSplashPlaylistModel () {
        return new SplashPlaylist;
    }

    public function getPlayList () {
    	try {
    		$PL = $this->getPlaylistModel()->select(DB::raw('playlists.*,categories.name as subcatagory,parent_category.pcat_name as catagory'))->join('category_playlists', function ($join) {
                $join->on('category_playlists.playlist_id','=','playlists.id');
            })->join('categories', function ($join) {
                $join->on('categories.id','=','category_playlists.category_id');
            })->join('parent_category', function ($join) {
                $join->on('parent_category.id','=','categories.pcat_name');
            })->get();
    		$data['status_code']	=   1;
            $data['status_text']    =   'Success';
            $data['message'] 		= 	'Playlist fetched successfully';
            $data['playlists'] 		= 	$PL;
    	} catch (Exception $e) {
    		$data['status_code']	=   0;
            $data['status_text']    =   'Failed';
            $data['message']        =   $e->getMessage();
    	}
    	return $data;
    }

    public function getPlaylistTracks ($playlist_id) {
    	try {
    		$PLT = $this->getPlaylistTracksModel()->select(DB::raw('p.name as playlist_name,t.id,t.track_name as title,t.track_name as label_name,t.image_location as artwork_url,t.file_location as stream_url,t.catagory,if(tr.rating Is NULL, 0, tr.rating) As rating,if(tl.no_of_likes Is NULL, 0, tl.no_of_likes) As no_of_likes,if(tl.no_of_dislikes Is NULL, 0, tl.no_of_dislikes) As no_of_dislikes,t.length,t.note,t.genre,t.sub_genre,t.language,a.name as artist,t.country'))->join('tracks as t', function ($join) {
        			$join->on('t.id','=','playlist_track_ids.track_id');
        	})->join('playlists as p', function($join) {
        		$join->on('p.id','=','playlist_track_ids.playlist_id');
        	})->join('artists as a', function ($join) {
                $join->on('a.id','=','t.artist_id');
            })->leftJoin('tracks_likes as tl', function ($join) {
                $join->on('tl.track_id','=','t.id');
            })->leftJoin('track_ratings as tr', function ($join) {
                $join->on('tr.track_id','=','t.id');
            })->where('playlist_track_ids.playlist_id',$playlist_id)/*->groupBy('t.id')*/->get();

            $PL = $this->getPlaylistModel()->select(DB::Raw('playlists.*,playlists.name as title'))->where('id',$playlist_id)->first();

            if ($PL) {
                $PL->total_listens      =   $PL->total_listens+1;
                $PL->update();
                /*get skip remain*/
                $user_id = Auth::user()->id;
                $ST = SkipSong::select(DB::raw('SUM(no_of_skip) as no_of_skip'))->where('user_id',$user_id)->where('playlist_id',$PL->id)->groupBy('playlist_id')->first();
                $PL = (array) json_decode($PL);
                $PL['no_of_skip'] = 0;
                $PL['remaining_skip'] = intval($PL['skip_count']);
                if (isset($ST) && !empty($ST)){
                    if($ST['no_of_skip'] !=''){
                        $PL['no_of_skip'] = $ST['no_of_skip'];
                        $remainCount = intval($PL['skip_count']) - intval($ST['no_of_skip']);
                        $remainCount = $remainCount < 0 ? 0 : $remainCount;
                        $PL['remaining_skip'] = $remainCount;
                    }
                }

                $data['status_code']            =   1;
                $data['status_text']            =   'Success';             
                $data['message']                =   'Playlist Tracks fetched successfully';
                /*$data['favorite']               =   0;
                $data['like']                   =   2;*/
                $data['playlist']               =   $PL;
                $data['playlist']['tracks']     =   $PLT;
            }
            else {
                $data['status_code']            =   0;
                $data['status_text']            =   'Failed';
                $data['message']                =   'Playlist Not Found';
            }

    	} catch (Exception $e) {
    		$data['status_code']	=   0;
            $data['status_text']    =   'Failed';
            $data['message']        =   $e->getMessage();
    	}
    	return $data;
    }

    public function searchSong ($keyword, $update) {
    	try {
            //Save Search Keyword
            $update = filter_var($update, FILTER_VALIDATE_BOOLEAN);
            if($update){
                $USK = $this->getUserSearchKeywordModel();
                $USK->user_id       =   Auth::id();
                $USK->keyword       =   $keyword;
                $USK->created_at    =   Carbon::now();
                $USK->save();
            }
    		$keyword = '%'.$keyword.'%';
    		$PL = $this->getPlaylistModel()->select(DB::raw('playlists.id,playlists.name as title,playlists.cover_img_link as artwork_url,playlists.note,playlists.description'))->where('playlists.name','like',$keyword)->orWhere('playlists.description','like',$keyword)->join('playlist_track_ids as pt', function ($join) {
                    $join->on('pt.playlist_id','=','playlists.id');
            })->groupBy('playlists.id')->get();

            foreach ($PL as $playlist) {
                 $playlist['tracks'] = $this->getPlaylistTracksModel()->select(DB::raw('p.name as playlist_name,t.id,t.track_name as title,t.track_name as label_name,t.image_location as artwork_url,t.file_location as stream_url,t.catagory,if(tr.rating Is NULL, 0, tr.rating) As rating,if(tl.no_of_likes Is NULL, 0, tl.no_of_likes) As no_of_likes,if(tl.no_of_dislikes Is NULL, 0, tl.no_of_dislikes) As no_of_dislikes,t.length,t.note,t.genre,t.sub_genre,t.language,a.name as artist,t.country'))->join('tracks as t', function ($join) {
                    $join->on('t.id','=','playlist_track_ids.track_id');
                })->join('playlists as p', function($join) {
                    $join->on('p.id','=','playlist_track_ids.playlist_id');
                })->join('artists as a', function ($join) {
                    $join->on('a.id','=','t.artist_id');
                })->leftJoin('tracks_likes as tl', function ($join) {
                    $join->on('tl.track_id','=','t.id');
                })->leftJoin('track_ratings as tr', function ($join) {
                    $join->on('tr.track_id','=','t.id');
                })->where('playlist_track_ids.playlist_id',$playlist->id)->get();
            }

            $PLT = $this->getPlaylistTracksModel()->select(DB::raw('p.name as playlist_name,t.id,t.track_name as title,t.track_name as label_name,t.image_location as artwork_url,t.file_location as stream_url,t.catagory,t.rating,t.length,t.note,t.genre,t.sub_genre,t.language,a.name as artist,t.country'))->join('tracks as t', function ($join) {
                    $join->on('t.id','=','playlist_track_ids.track_id');
            })->join('playlists as p', function($join) {
                $join->on('p.id','=','playlist_track_ids.playlist_id');
            })->join('artists as a', function ($join) {
                $join->on('a.id','=','t.artist_id');
            })->orWhere('t.track_name','like',$keyword)->orWhere('t.catagory','like',$keyword)->orWhere('t.note','like',$keyword)->get();

            $data['playlists']      =   $PL;
            $data['tracks']         =   $PLT;
        	$data['status_code']	=   1;
	        $data['status_text']    =   'Success';
    	} catch (Exception $e) {
    		$data['status_code']	=   0;
            $data['status_text']    =   'Failed';
            $data['message']        =   $e->getMessage();
    	}
    	return $data;
    }

    public function getValueScreenDetails () {
        $value_screen = $this->getValueScreenDetailsModel()->all();
        $data = array();
        $data['status_code'] = 1;
        $data['status_text'] = 'Success';
        $data['message'] = 'Value Screen Fetched Successfully';
        $data['value_screen'] = $value_screen;

        return $data;
    }

    public function add_playlist_recent ($params) {
        $playlist_id = $params['playlist_id'];
        $data = array ();
        $PR = $this->getPlaylistRecentModel()->where('user_id',Auth::user()->id)->where('playlist_id',$playlist_id)->first();
        if ($PR) {
            $PR->updated_at     =   Carbon::now();
            $PR->update();
        }
        else {
            $PR = $this->getPlaylistRecentModel();
            $PR->user_id        =   Auth::user()->id;
            $PR->status         =   1;
            $PR->playlist_id    =   $playlist_id;
            $PR->updated_at     =   Carbon::now();
            $PR->created_at     =   Carbon::now();
            $PR->save();
        }
        $data['status_code']    =   1;
        $data['status_text']    =   'Success';
        $data['message']        =   'Recent playlist added successfully';
        return $data;
    }

    public function getFeedbackCategory () {
        $FC = $this->getFeedbackCategoryModel()->select('id','cat_name')->get();

        $data['status_code']              =   1;
        $data['status_text']              =   'Success';
        $data['message']                  =   'Feedback Category Fetched Successfully.';
        $data['feedback_category']        =   $FC;
        
        return $data;
    }

    public function Feedback ($params) {
        $FE = $this->getFeedbackModel();
        $FE->user_id                        =   Auth::user()->id;
        $FE->subject                        =   $params['subject'];
        $FE->feedback_cat                   =   $params['feedback_cat'];
        $FE->message                        =   $params['message'];
        $FE->created_at                     =   Carbon::now();
        $FE->updated_at                     =   Carbon::now();
        $FE->save();

        $data['status_code']    =   1;
        $data['status_text']    =   'Success';
        $data['message']        =   'Thank you. Your message has been sent.';

        return $data;
    }

    public function viewRecentPlaylist () {
        $user_id = Auth::user()->id;
        $RP = $this->getPlaylistModel()->select(DB::raw('playlists.*,playlists.name as title,playlists.cover_img_link as artwork_url,categories.name as subcatagory,parent_category.pcat_name as catagory'))->join('playlist_recents as pr', function ($join) {
                $join->on('pr.playlist_id','=','playlists.id');
        })->join('category_playlists', function ($join) {
            $join->on('category_playlists.playlist_id','=','playlists.id');
        })->join('categories', function ($join) {
            $join->on('categories.id','=','category_playlists.category_id');
        })->join('parent_category', function ($join) {
            $join->on('parent_category.id','=','categories.pcat_name');
        })->where('pr.user_id',$user_id)->orderBy('pr.updated_at','DESC')->get();
        if ($RP->count() < 1) {
            $data['status_code']    =   0;
            $data['status_text']    =   'Failed';
            $data['message']        =   'No Recent Playlist Found.';
        }
        else {
            $data['status_code']    =   1;
            $data['status_text']    =  'Success'; 
            $data['message']        =   'Playlist Fetched Successfully';
            $data['playlists']      =   $RP;
        }
        return $data;
    }

    public function addPlaylistFavorite ($params) {
        $playlist_id = $params['playlist_id'];
        $user_id = Auth::user()->id;
        $model = $this->getPlaylistFavoriteModel()->where('user_id', $user_id)->where('playlist_id', $playlist_id)->first();
        if ($model) {
            $data['status_code']    =   0;
            $data['status_text']    =   'Failed';
            $data['message']        =   'Playlist already exits with favorites';
        }
        else {
            $PF = $this->getPlaylistFavoriteModel();
            $PF->user_id            =   $user_id;
            $PF->playlist_id        =   $playlist_id;
            $PF->no_of_favorites    =   0;
            $PF->status             =   1;
            $PF->created_at         =   Carbon::now();
            $PF->updated_at         =   Carbon::now();
            $PF->save();

            $PFO = $this->getPlaylistFavoriteModel()->where('playlist_id', $playlist_id)->first();
            if ($PFO) {
                /*$no_of_favorites = $PFO[0]->no_of_favorites;
                foreach ($PFO as $pf) {
                    $pf->no_of_favorites    =   $no_of_favorites+1;
                    $pf->update();
                }*/
                $update_Favorite_data = DB::table('playlist_favorites')
                                            ->where('playlist_id','=',$playlist_id)
                                                ->update(array('no_of_favorites' => $PFO->no_of_favorites+1));
            }
            $data['status_code']    =   1;
            $data['status_text']    =   'Success';
            $data['message']        =   'Favorite playlist added successfully'; 
            $data['play_list_id']   =   $PF->playlist_id;
        }
        return $data;

    }

    public function removePlaylistFavorite ($params) {
        $playlist_id = $params['playlist_id'];
        $user_id = Auth::user()->id;
        $PF = $this->getPlaylistFavoriteModel()->where('playlist_id', $playlist_id)->where('user_id', $user_id)->first();
        if ($PF) {
            $PF->delete();
            $update_Favorite_data = DB::table('playlist_favorites')
                                            ->where('playlist_id','=',$playlist_id)
                                                ->update(array('no_of_favorites' => $PF->no_of_favorites-1));
            $data['status_code']    =   1;
            $data['status_text']    =   'Success';
            $data['message']        =   'Favorite playlist deleted successfully';
        }
        else {
            $data['status_code']    =   0;
            $data['status_text']    =   'Failed';             
            $data['message']        =   'Playlist not found.';
            $data['playlist_id']   =   $playlist_id;
        }
        return $data;
    }

    public function viewPlaylistFavorite ($params) {
        $user_id = Auth::user()->id;
        $FPL = $this->getPlaylistModel()->select(DB::raw('playlists.*,playlists.name as title,playlists.cover_img_link as artwork_url,categories.name as subcatagory,parent_category.pcat_name as catagory'))->join('playlist_favorites as pf', function ($join) {
            $join->on('pf.playlist_id','=','playlists.id');
        })->join('category_playlists', function ($join) {
            $join->on('category_playlists.playlist_id','=','playlists.id');
        })->join('categories', function ($join) {
            $join->on('categories.id','=','category_playlists.category_id');
        })->join('parent_category', function ($join) {
            $join->on('parent_category.id','=','categories.pcat_name');
        })->where('pf.user_id', $user_id)->get();
        if ($FPL->count() > 0) {
            $data['status_code']    =   1;
            $data['status_text']    =   'Success';             
            $data['message']        = 'Favorite Playlist fetched successfully';
            $data['playlist']       = $FPL;
        }
        else {
            $data['status_code']    =   0;
            $data['status_text']    =   'Failed';             
            $data['message']        =  'Favorite playlist not found';
        }
        return $data;
    }

    public function accountSetting ($params) {
        $email = $params['email'];
        $first_name = $params['first_name'];
        $last_name = $params['last_name'];
        $originalcountry = $params['originalcountry'];
        $dob = $params['dob'];
        $gender = $params['gender'];
        $currentcountry = $params['currentcountry'];
        $language = $params['language'];
        $user_id = Auth::user()->id;

        $USER = $this->getModel()->where('id', $user_id)->first();
        $USER->email                =   $email;
        if ($USER->password != $params['password'])
            $USER->password         =   bcrypt($params['password']);
        if ($gender == 1 || strcasecmp('male', $gender) == 0)
            $USER->gender           =   1;
        else if ($gender == 2 || strcasecmp('female', $gender) == 0)
            $USER->gender           =   2;
        $USER->first_name           =   $first_name;
        $USER->last_name            =   $last_name;
        $USER->country              =   $originalcountry;
        $USER->currentcountry       =   $currentcountry;
        $USER->dob                  =   $dob;
        $USER->language             =   $language;
        $USER->updated_at           =   Carbon::now();
        $USER->update();

        $data['status_code']    =    1;
        $data['status_text']    =    'Success'; 
        $data['DOB']            =    $dob;
        $data['message']        =    'Your Profile Updated Successfully.';

        return $data;
    }

    public function registerUserDevice ($params) {
        $os = $params['os'];
        $device_id = $params['device_id'];
        $user_id = Auth::user()->id;
        $this->getUserDeviceModel()->where('device_id',$device_id)->delete();
        $UD = $this->getUserDeviceModel()->where('user_id',$user_id)->first();
        if ($UD) {
            $UD->device_id          =   $device_id;
            $UD->os                 =   $os;
            $UD->updated_at         =   Carbon::now();
            $UD->update();
            $data['status_code']    =    1;
            $data['status_text']    =    'Success';
            $data['message']        =    'Your Device Updated Successfully.';
        }
        else {
            $ND = $this->getUserDeviceModel();
            $ND->user_id            =   $user_id;
            $ND->device_id          =   $device_id;
            $ND->os                 =   $os;
            $ND->created_at         =   Carbon::now();
            $ND->save();
            $data['status_code']    =    1;
            $data['status_text']    =    'Success';
            $data['message']        =    'Your Device Saved Successfully.';
        }
        return $data;
    }

    public function getPreferenceOne () {
        $PO = $this->getPreferenceOneModel()->get();
        $data['status_code']    =    1;
        $data['status_text']    =    'Success';
        $data['message']        =    'Preference Fetched Successfully.';
        $data['preference_one'] =   $PO;
        return $data;
    }

    public function getPreferenceTwo () {
        $PO = $this->getPreferenceTwoModel()->get();
        $data['status_code']    =    1;
        $data['status_text']    =    'Success';
        $data['message']        =    'Preference Fetched Successfully.';
        $data['preference_two'] =   $PO;
        return $data;
    }

    public function updateUserPreferenceOne ($params) {
        $preference = $params['preference'];
        $user_id = Auth::id();
        $this->getUserPreferenceModel()->where('user_id',$user_id)->whereNotNull('preference_one_id')->whereNull('preference_two_id')->delete();
        for ($i=0; $i<sizeof($preference); $i++) {
            $UP = $this->getUserPreferenceModel();
            $UP->user_id                =   $user_id;
            $UP->preference_one_id      =   $preference[$i]['id'];
            $UP->created_at             =   Carbon::now();
            $UP->save();
        }
        $data['status_code']    =    1;
        $data['status_text']    =    'Success';
        $data['message']        =    'Preference Updated Successfully.';
        return $data;
    }

    public function updateUserPreferenceTwo ($params) {
        $preference = $params['preference'];
        $user_id = Auth::id();
        $this->getUserPreferenceModel()->where('user_id',$user_id)->whereNull('preference_one_id')->whereNotNull('preference_two_id')->delete();
        for ($i=0; $i<sizeof($preference); $i++) {
            $UP = $this->getUserPreferenceModel();
            $UP->user_id                =   $user_id;
            $UP->preference_two_id      =   $preference[$i]['id'];
            $UP->created_at             =   Carbon::now();
            $UP->save();
        }
        $data['status_code']    =    1;
        $data['status_text']    =    'Success';
        $data['message']        =    'Preference Updated Successfully.';
        return $data;
    }

    public function getUserPreference () {
        $user_id = Auth::id();
        $UP1 = $this->getUserPreferenceModel()->select(DB::raw('preference_one.*'))->where('user_id',$user_id)->whereNull('preference_two_id')->join('preference_one', function($join) {
                $join->on('preference_one.id','=','user_preferences.preference_one_id');
        })->get();
        $UP2 = $this->getUserPreferenceModel()->select(DB::raw('preference_two.*'))->where('user_id',$user_id)->whereNull('preference_one_id')->join('preference_two', function($join) {
                $join->on('preference_two.id','=','user_preferences.preference_two_id');
        })->get();

        $data['status_code']    =    1;
        $data['status_text']    =    'Success';
        $data['message']        =    'Preference Fetched Successfully.';
        $data['preference_one'] =   $UP1;
        $data['preference_two'] =   $UP2;
        return $data;
    }

    public function checkFavourite ($params) {
        $playlist_id = $params['playlist_id'];
        $user_id = Auth::id();
        $PL = $this->getPlaylistFavoriteModel()->where('user_id',$user_id)->where('playlist_id',$playlist_id)->get();
        if ($PL->count() != 0) {
            $data['status_code']        =   1;
            $data['status_text']        =   'Success'; 
            $data['message']            =   'Success.';
            $data['is_favourite']       =   1;
        }
        else {
            $data['status_code']        =   0;
            $data['status_text']        =  'Failed'; 
            $data['message']            =   'Failed.';
            $data['is_favourite']       =   0;
        }

        return $data;
    }

    public function LikeDislike ($params) {
        $user_id = Auth::id();
        $TL = $this->getTrackLikesModel()->where('user_id',$user_id)->where('track_id',$params['track_id'])->first();
        if ($TL) {
            $TL->type                   =   $params['type'];
            if ($params['type'] == 1) {
                $TL->no_of_likes        =   1;
                $TL->no_of_dislikes     =   0;
            }
            else {
                $TL->no_of_likes        =   0;
                $TL->no_of_dislikes     =   1;
            }
            $TL->updated_at             =   Carbon::now();
            $TL->update();
        }
        else {
            $TL = $this->getTrackLikesModel();
            $TL->user_id                =   $user_id;
            $TL->track_id               =   $params['track_id'];
            $TL->type                   =   $params['type'];
            if ($params['type'] == 1)
                $TL->no_of_likes        =   1;
            else
                $TL->no_of_dislikes     =   1;
            $TL->created_at             =   Carbon::now();
            $TL->save();
        }

        $data['status_code']    =   1;
        $data['status_text']    =   'Success';
        if($params['type'] == 1)
          $data['message']      =   'Liked'; 
        elseif($params['type'] == 0)
          $data['message']      =   'Disliked';
        else
          $data['message']      =   'No Response';

        return $data;
    }

    public function LikeDislikeData ($params) {
        $user_id = Auth::id();
        $like = $this->getTrackLikesModel()->where('user_id',$user_id)->where('track_id',$params['track_id'])->where('type',1)->get()->count();
        $dislike = $this->getTrackLikesModel()->where('user_id',$user_id)->where('track_id',$params['track_id'])->where('type',0)->get()->count();

        $data['status_code']    =   1;
        $data['status_text']    =   'Success';
        $data['message']        =   'Like Dislike Data Fetched Successfully.';
        $data['like']           =   $like;
        $data['dislike']        =   $dislike;

        return $data;
    }

    public function rateTrack ($params) {
        $user_id = Auth::id();
        $track_id = $params['track_id'];
        $rating = $params['rating'];
        $UTR = $this->getTrackRatingsModel()->where('user_id',$user_id)->where('track_id',$track_id)->first();
        if ($UTR) {
            $UTR->rating            =   $rating;
            $UTR->updated_at        =   Carbon::now();
            $UTR->update();
            $data['status_code']    =   1;
            $data['status_text']    =   'Success';
            $data['message']        =   'Track Rating Updated Successfully.';
        }
        else {
            $UTR = $this->getTrackRatingsModel();
            $UTR->user_id           =   $user_id;
            $UTR->track_id          =   $track_id;
            $UTR->rating            =   $rating;
            $UTR->created_at        =   Carbon::now();
            $UTR->save();
            $data['status_code']    =   1;
            $data['status_text']    =   'Success';
            $data['message']        =   'Track Rating Submitted Successfully.';
        }
        $AR = $this->getTrackRatingsModel()->where('track_id',$track_id)->get();
        $average = 0;
        if ($AR->count() != 0) {
            $sum = 0;
            foreach ($AR as $row) {
                $sum += $row->rating;
            }
            $average = $sum/$AR->count();
        }
        $data['avg_rating']     =   $average;
        return $data;
    }

    public function viewRateTrack ($params) {
        $user_id = Auth::id();
        $track_id = $params['track_id'];
        $AR = $this->getTrackRatingsModel()->where('track_id',$track_id)->get();
        $average = 0;
        if ($AR->count() != 0) {
            $sum = 0;
            foreach ($AR as $row) {
                $sum += $row->rating;
            }
            $average = $sum/$AR->count();
        }
        $UTR = $this->getTrackRatingsModel()->where('user_id',$user_id)->where('track_id',$track_id)->first();
        if ($UTR) {
            $data['status_code']    =   1;
            $data['status_text']    =   'Success';
            $data['message']        =   'Rating fetched successfully';
            $data['user_rating']    =   $UTR->rating;
        }
        else {
            $data['status_code']    =   0;
            $data['status_text']    =   'Failed';
            $data['message']        =   'Rating not found';
            $data['user_rating']    =   0;
        }
        $data['avg_rating']     =   $average;

        return $data;
    }

    public function parentCategories () {
        $PC = $this->getParentCategoriesModel()->select('id','pcat_name')->orderByRaw("pcat_name='Featured',pcat_name='Activities & Moods',pcat_name='Genres'")->get();
        $data['status_code']    = 1;
        $data['status_text']    = 'Success';
        $data['message']        = 'Categories Fetched Successfully';
        $data['categoty_data']  =  $PC;
        
        return $data;
    }

    public function Categories ($params) {
        $pcat_id = $params['pcat_id'];
        $CAT = $this->getCategoriesModel()->select('parent_category.pcat_name','categories.name','categories.id')->join('parent_category', function($join) {
                $join->on('categories.pcat_name', '=', 'parent_category.id');
        })->where('parent_category.id',$pcat_id)->orderBy('categories.id','ASC')->get();

        $data['status_code']    = 1;
        $data['status_text']    = 'Success';
        $data['message']        = 'Categories Fetched Successfully';
        $data['categoty_data']  =  $CAT;
        
        return $data;
    }

    public function categoryPlaylist ($params) {
        $sub_cat_id = $params['sub_cat_id'];
        $CP = $this->getCategoryPlaylistModel()->select('category_playlists.id as cat_id','playlists.*','playlists.name','playlists.cover_img_link as artwork_url')->join('playlists','playlists.id','=','category_playlists.playlist_id')->where('category_playlists.category_id',$sub_cat_id)->where('playlists.status',1)->orderBy('total_listens', 'desc')->get();
        if ($CP->count() == 0) {
            $data['status_code']    =   0;
            $data['status_text']    =  'Failed'; 
            $data['message']        =   'No Playlists Found';
        }
        else {
            $data['status_code']    =   1;
            $data['status_text']    =  'Success'; 
            $data['message']        =   'Playlist Fetched Successfully';
            $data['playlists']      =   $CP;
        }
        return $data;
    }

    public function getCMS ($params) {
        $type = $params['type'];
        if($type=='terms_condition'){
            $type = 1;
        }
        if($type=='privacy_policy'){
            $type = 2;
        }
        if($type=='about_us'){
            $type = 3;
        }
        $CMS = $this->getCmsModel()->where('id',$type)->get();
        $data['status_code']    =   1;
        $data['status_text']    =   'Success';
        $data['message']        =   'Cms data fetched successfully.';
        $data['user_data']      =   $CMS;
        return $data;
    }

    public function allPlaylistSongs () {
        $PL = $this->getPlaylistModel()->select(DB::raw('playlists.*,categories.name as subcatagory,parent_category.pcat_name as catagory'))->join('category_playlists', function ($join) {
            $join->on('category_playlists.playlist_id','=','playlists.id');
        })->join('categories', function ($join) {
            $join->on('categories.id','=','category_playlists.category_id');
        })->join('parent_category', function ($join) {
            $join->on('parent_category.id','=','categories.pcat_name');
        })->get();
        if ($PL->count() == 0) {
            $data['status_code']    =   0;
            $data['status_text']    =  'Failed'; 
            $data['message']        =   'No Playlists Found.';
        }
        else {
            foreach ($PL as $play) {
                $play['tracks'] = $this->getPlaylistTracksModel()->select(DB::raw('p.name as playlist_name,t.id,t.track_name as title,t.track_name as label_name,t.image_location as artwork_url,t.file_location as stream_url,t.catagory,if(tr.rating Is NULL, 0, tr.rating) As rating,if(tl.no_of_likes Is NULL, 0, tl.no_of_likes) As no_of_likes,if(tl.no_of_dislikes Is NULL, 0, tl.no_of_dislikes) As no_of_dislikes,t.length,t.note,t.genre,t.sub_genre,t.language,a.name as artist,t.country'))->join('tracks as t', function ($join) {
                        $join->on('t.id','=','playlist_track_ids.track_id');
                })->join('playlists as p', function($join) {
                    $join->on('p.id','=','playlist_track_ids.playlist_id');
                })->join('artists as a', function ($join) {
                    $join->on('a.id','=','t.artist_id');
                })->leftJoin('tracks_likes as tl', function ($join) {
                    $join->on('tl.track_id','=','t.id');
                })->leftJoin('track_ratings as tr', function ($join) {
                    $join->on('tr.track_id','=','t.id');
                })->where('playlist_track_ids.playlist_id',$play->id)->get();
            }
            $data['status_code']    =   1;
            $data['status_text']    =  'Success'; 
            $data['message']        =  'Playlist Songs Fetched Successfully.';
            $data['playlists']      =   $PL;
        }
        return $data;
    }

    public function tellAFriend ($params) {
        $user_id = Auth::id();
        $mail = DB::table('mails')->where('id', '1')->first();
        if (array_key_exists('email_first', $params)) {
            $input['email'] = $params['email_first'];
            $emailData = array(
            'to'        => $input['email'], 
            'from'      => 'jwompa@gmail.com',
            'subject'   => $mail->subject,
            'view'      => 'admin.mail.tell_friend',
            );      
            Mail::send($emailData['view'], $emailData, function ($message) use ($emailData) {
                $message
                    ->to($emailData['to'])
                    ->from($emailData['from'])
                    ->subject($emailData['subject']);
            }); 
            $TF = $this->getTellFriendModel();
            $TF->user_id        =   $user_id;
            $TF->email          =   $input['email'];
            $TF->save();
        }
        if (array_key_exists('email_second', $params)) {
            $input['email'] = $params['email_second'];
            $emailData = array(
            'to'        => $input['email'], 
            'from'      => 'jwompa@gmail.com',
            'subject'   => $mail->subject,
            'view'      => 'admin.mail.tell_friend',
            );      
            Mail::send($emailData['view'], $emailData, function ($message) use ($emailData) {
                $message
                    ->to($emailData['to'])
                    ->from($emailData['from'])
                    ->subject($emailData['subject']);
            }); 
            $TF = $this->getTellFriendModel();
            $TF->user_id        =   $user_id;
            $TF->email          =   $input['email'];
            $TF->save();
        }
        if (array_key_exists('email_third', $params)) {
            $input['email'] = $params['email_third'];
            $emailData = array(
            'to'        => $input['email'], 
            'from'      => 'jwompa@gmail.com',
            'subject'   => $mail->subject,
            'view'      => 'admin.mail.tell_friend',
            );      
            Mail::send($emailData['view'], $emailData, function ($message) use ($emailData) {
                $message
                    ->to($emailData['to'])
                    ->from($emailData['from'])
                    ->subject($emailData['subject']);
            }); 
            $TF = $this->getTellFriendModel();
            $TF->user_id        =   $user_id;
            $TF->email          =   $input['email'];
            $TF->save();
        }
        if (array_key_exists('email_fourth', $params)) {
            $input['email'] = $params['email_fourth'];
            $emailData = array(
            'to'        => $input['email'], 
            'from'      => 'jwompa@gmail.com',
            'subject'   => $mail->subject,
            'view'      => 'admin.mail.tell_friend',
            );      
            Mail::send($emailData['view'], $emailData, function ($message) use ($emailData) {
                $message
                    ->to($emailData['to'])
                    ->from($emailData['from'])
                    ->subject($emailData['subject']);
            }); 
            $TF = $this->getTellFriendModel();
            $TF->user_id        =   $user_id;
            $TF->email          =   $input['email'];
            $TF->save();
        }
        if (array_key_exists('email_five', $params)) {
            $input['email'] = $params['email_five'];
            $emailData = array(
            'to'        => $input['email'], 
            'from'      => 'jwompa@gmail.com',
            'subject'   => $mail->subject,
            'view'      => 'admin.mail.tell_friend',
            );      
            Mail::send($emailData['view'], $emailData, function ($message) use ($emailData) {
                $message
                    ->to($emailData['to'])
                    ->from($emailData['from'])
                    ->subject($emailData['subject']);
            }); 
            $TF = $this->getTellFriendModel();
            $TF->user_id        =   $user_id;
            $TF->email          =   $input['email'];
            $TF->save();
        }
        $data['status_code']    =   1;                      
        $data['status_text']    =   'Success';
        $data['message']        =   'Email sent successfully';
        return $data;
    }

    public function trackListen ($params) {
        $playlist_id = $params['playlist_id'];
        $track_id = $params['track_id'];
        $user_id = Auth::id();
        $PL = $this->getPlaylistModel()->where('id',$playlist_id)->first();
        $TR = $this->getTracksModel()->where('id',$track_id)->first();
        $LS = $this->getListenSongModel();
        $LS->playlist_id            =   $PL->id;
        $LS->playlist_title         =   $PL->name;
        $LS->track_id               =   $TR->id;
        $LS->track_title            =   $TR->track_name;
        $LS->user_id                =   $user_id;
        $LS->status                 =   1;
        $LS->save();
        $listen_data = DB::table('listen_song')->select('no_of_listen')
            ->where('track_id','=',$track_id)->first();
            
        $update_listen_data = DB::table('listen_song')->where('track_id','=',$track_id)
        ->update(array('no_of_listen' => $listen_data->no_of_listen+1));

        $data['status_code']    =   1;
        $data['status_text']    =   'Success';
        $data['message']        =   'Track added successfully.';
        return $data;
    }

    public function trendySearch () {
        $now = Carbon::now();
        $start_of_month = $now->startOfMonth();
        $TS = $this->getUserSearchKeywordModel()->select(DB::raw('keyword,count(*) as count'))->where('created_at','>',$start_of_month)->orderBy('count','desc')->groupBy('keyword')->take(5)->get();
        $data['status_code']    =   1;
        $data['status_text']    =   'Success';
        $data['message']        =   'Trendy Search Fetched successfully.';
        $data['trendy_search']  =   $TS;
        return $data;
    }

    public function recentSearch ($params) {
        $user_id = Auth::id();
        $USK = $this->getUserSearchKeywordModel()->select('keyword','created_at')->where('user_id',$user_id)->orderBy('created_at','DESC')->get()->take(5);
        if ($USK->count() > 0) {
            $data['status_code']    =   1;
            $data['status_text']    =   'Success';
            $data['message']        =   'Recent Search Fetched successfully.';
            $data['recent_search']  =   $USK;
        }
        else {
            $data['status_code']    =   0;
            $data['status_text']    =   'Failed';
            $data['message']        =   'No Recent Search Found';
        }
        return $data;
    }

    public function skipTrack ($params) {
        $user_id = Auth::id();
        $playlist_id = $params['playlist_id'];
        $track_id = $params['track_id'];
        $ST = $this->getSkipTracksModel()->where('user_id',$user_id)->where('playlist_id',$playlist_id)->where('track_id',$track_id)->first();
        if ($ST) {
            $ST->no_of_skip             =   $ST->no_of_skip+1;
            $ST->updated_at             =   Carbon::now();
            $ST->update();
        }
        else {
            $ST = $this->getSkipTracksModel();
            $ST->user_id                =   $user_id;
            $ST->track_id               =   $track_id;
            $ST->playlist_id            =   $playlist_id;
            $ST->no_of_skip             =   1;
            $ST->created_at             =   Carbon::now();
            $ST->save();
        }

         /*get skip remain*/
        $PL = $this->getPlaylistModel()->select(DB::Raw('playlists.*,playlists.name as title'))->where('id',$playlist_id)->first();

        $ST = SkipSong::select(DB::raw('SUM(no_of_skip) as no_of_skip'))->where('user_id',$user_id)->where('playlist_id',$playlist_id)->groupBy('playlist_id')->first();
        $data['no_of_skip'] = 0;
        $data['remaining_skip'] = intval($PL['skip_count']);
        if (isset($ST) && !empty($ST)){
            if($ST['no_of_skip'] !=''){
                $data['no_of_skip'] = $ST['no_of_skip'];
                $remainCount = intval($PL['skip_count']) - intval($data['no_of_skip']);
                $remainCount = $remainCount < 0 ? 0 : $remainCount;
                $data['remaining_skip'] = $remainCount;
            }
        }

        $data['status_code']    =   1;
        $data['status_text']    =   'Success';
        $data['message']        =   'Track skip successfully.';
        return $data;
    }

    public function sendPushNotification ($params) {
        $device_id = $params['device_id'];
        $module = $params['module'];
        $id = $params['id'];
        $body = 'Notificaton';

        if (strcasecmp($module, 'playlist') == 0)
            $body = 'New Playlist';
        else if (strcasecmp($module, 'track') == 0)
            $body = 'New Track';
        else if (strcasecmp($module, 'profile') == 0)
            $body = 'Profile';
        else if (strcasecmp($module, 'news') == 0) {
            $body = 'News';
            if (isset($params['body']))
                $body = $params['body'];
        }

        if (isset($params['message']))
            $body = $params['message'];
        
        $optionBuilder = new OptionsBuilder();
        $optionBuilder->setTimeToLive(60*20);

        $notificationBuilder = new PayloadNotificationBuilder('Jwompa');
        $notificationBuilder->setBody($body)
                            ->setSound('default');

        $dataBuilder = new PayloadDataBuilder();
        $dataBuilder->addData(['module' => $module, 'id' => $id]);

        $option = $optionBuilder->build();
        $notification = $notificationBuilder->build();
        $data = $dataBuilder->build();

        $token = $device_id;

        $downstreamResponse = FCM::sendTo($token, $option, $notification, $data);

        return $downstreamResponse->numberFailure();
    }

    public function Splashboard ($params) {
        try {
            $user_id = Auth::user()->id;
            $limit = (array_key_exists('limit', $params))?$params['limit']:config('client.no_of_records');
            $SPL = $this->getSplashPlaylistModel()->select(DB::raw('playlists.*,categories.name as subcatagory,parent_category.pcat_name as catagory'))->join('playlists', function ($join) {
                $join->on('splash_playlists.playlist_id','=','playlists.id');
            })->join('category_playlists', function ($join) {
                $join->on('category_playlists.playlist_id','=','playlists.id');
            })->join('categories', function ($join) {
                $join->on('categories.id','=','category_playlists.category_id');
            })->join('parent_category', function ($join) {
                $join->on('parent_category.id','=','categories.pcat_name');
            })->where('playlists.status',1)->orderBy('sort_priority','ASC')->get();
            foreach ($SPL as $key => $list) {
                $ST = SkipSong::select(DB::raw('SUM(no_of_skip) as no_of_skip'))->where('user_id',$user_id)->where('playlist_id',$list->id)->groupBy('playlist_id')->first();
                $SPL[$key]['no_of_skip'] = 0;
                $SPL[$key]['remaining_skip'] = intval($list->skip_count);
                if (isset($ST) && !empty($ST)){
                    if($ST['no_of_skip'] !=''){
                        $SPL[$key]['no_of_skip'] = $ST['no_of_skip'];
                        $remainCount = intval($list->skip_count) - intval($ST['no_of_skip']);
                        $remainCount = $remainCount < 0 ? 0 : $remainCount;
                        $SPL[$key]['remaining_skip'] = $remainCount;
                    }
                } 
            }
            $data['status_code']    =   1;
            $data['status_text']    =   'Success';
            $data['message']        =   'Playlist fetched successfully';
            $data['playlists']      =   $SPL;
        } catch (Exception $e) {
            $data['status_code']    =   0;
            $data['status_text']    =   'Failed';
            $data['message']        =   $e->getMessage();
        }
        return $data;
    }

    public function getTracksById ($params) {
        $track_id = $params['track_id'];
        $track = $this->getPlaylistTracksModel()->select(DB::raw('p.name as playlist_name,t.id,t.track_name as title,t.track_name as label_name,t.image_location as artwork_url,t.file_location as stream_url,t.catagory,if(tr.rating Is NULL, 0, tr.rating) As rating,if(tl.no_of_likes Is NULL, 0, tl.no_of_likes) As no_of_likes,if(tl.no_of_dislikes Is NULL, 0, tl.no_of_dislikes) As no_of_dislikes,t.length,t.note,t.genre,t.sub_genre,t.language,a.name as artist,t.country'))->join('tracks as t', function ($join) {
                $join->on('t.id','=','playlist_track_ids.track_id');
            })->join('playlists as p', function($join) {
                $join->on('p.id','=','playlist_track_ids.playlist_id');
            })->join('artists as a', function ($join) {
                $join->on('a.id','=','t.artist_id');
            })->leftJoin('tracks_likes as tl', function ($join) {
                $join->on('tl.track_id','=','t.id');
            })->leftJoin('track_ratings as tr', function ($join) {
                $join->on('tr.track_id','=','t.id');
            })->where('t.id',$track_id)->first();
        if ($track) {
            $data['status_code']    =   1;
            $data['status_text']    =   'Success';
            $data['message']        =   'Track fetched successfully';
            $data['track']          =   $track;
        }
        else {
            $data['status_code']    =   0;
            $data['status_text']    =   'Failed';
            $data['message']        =   'Track Not Found';
        }
        return $data;
    }

    public function getPlaylistById ($params) {
        $playlist_id = $params['playlist_id'];
        try {
            $PL = $this->getPlaylistModel()->select(DB::raw('playlists.*,categories.name as subcatagory,parent_category.pcat_name as catagory'))->join('category_playlists', function ($join) {
                $join->on('category_playlists.playlist_id','=','playlists.id');
            })->join('categories', function ($join) {
                $join->on('categories.id','=','category_playlists.category_id');
            })->join('parent_category', function ($join) {
                $join->on('parent_category.id','=','categories.pcat_name');
            })->where('playlists.id',$playlist_id)->first();
            if ($PL) {
                $PL->total_listens      =   $PL->total_listens+1;
                $PL->update();

                $PLT = $this->getPlaylistTracksModel()->select(DB::raw('p.name as playlist_name,t.id,t.track_name as title,t.track_name as label_name,t.image_location as artwork_url,t.file_location as stream_url,t.catagory,if(tr.rating Is NULL, 0, tr.rating) As rating,if(tl.no_of_likes Is NULL, 0, tl.no_of_likes) As no_of_likes,if(tl.no_of_dislikes Is NULL, 0, tl.no_of_dislikes) As no_of_dislikes,t.length,t.note,t.genre,t.sub_genre,t.language,a.name as artist,t.country'))->join('tracks as t', function ($join) {
                    $join->on('t.id','=','playlist_track_ids.track_id');
                })->join('playlists as p', function($join) {
                    $join->on('p.id','=','playlist_track_ids.playlist_id');
                })->join('artists as a', function ($join) {
                    $join->on('a.id','=','t.artist_id');
                })->leftJoin('tracks_likes as tl', function ($join) {
                    $join->on('tl.track_id','=','t.id');
                })->leftJoin('track_ratings as tr', function ($join) {
                    $join->on('tr.track_id','=','t.id');
                })->where('playlist_track_ids.playlist_id',$playlist_id)->groupBy('t.id')->get();

                $PL['tracks'] = $PLT;
                $data['status_code']    =   1;
                $data['status_text']    =   'Success';
                $data['message']        =   'Playlist fetched successfully';
                $data['playlist']       =   $PL;
            }
            else {
                $data['status_code']    =   0;
                $data['status_text']    =   'Failed';
                $data['message']        =   'Playlist Not Found';
            }
            
            

        } catch (Exception $e) {
            $data['status_code']    =   0;
            $data['status_text']    =   'Failed';
            $data['message']        =   $e->getMessage();
        }
        return $data;
    }

    public function profileCompletionNotification () {
        $users = $this->getUserDeviceModel()->join('users','user_device.user_id','=','users.id')->whereNull('country')->orWhereNull('currentcountry')->orWhereNull('mobile')->orWhereNull('gender')->orWhereNull('dob')->orWhereNull('language')->orWhere('country','')->orWhere('currentcountry','')->orWhere('mobile','')->orWhere('gender',0)->orWhere('dob','')->orWhere('language','')->get();
        foreach ($users as $user) {
            $params['device_id'] = $user->device_id;
            $params['module'] = 'profile';
            $params['id'] = 0;
            $this->sendPushNotification($params);
        }
        return "successfully";
    }

}
