<?php
$router->group(['prefix' => config('routes.api_prefix')], function () use($router){
	$router->get('/getvaluescreendetails','DashboardController@getValueScreenDetails');
});
