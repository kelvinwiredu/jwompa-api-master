<?php

namespace Api\Mobile\Services;

use Exception;
use Illuminate\Auth\AuthManager;
use Illuminate\Database\DatabaseManager;
use Illuminate\Events\Dispatcher;
use Api\Users\Exceptions\UserNotFoundException;
use Api\Users\Events\UserWasCreated;
use Api\Users\Events\UserWasDeleted;
use Api\Users\Events\UserWasUpdated;
use Api\Mobile\Repositories\GenericRepository;

class GenericService
{
    private $auth;

    private $database;

    private $dispatcher;

    private $genericRepository;

    public function __construct(
        AuthManager $auth,
        DatabaseManager $database,
        Dispatcher $dispatcher,
        GenericRepository $genericRepository
    ) {
        $this->auth = $auth;
        $this->database = $database;
        $this->dispatcher = $dispatcher;
        $this->genericRepository = $genericRepository;
    }

    public function getPlayList () {
        return $this->genericRepository->getPlayList();
    }

    public function getPlaylistTracks ($playlist_id) {
        return $this->genericRepository->getPlaylistTracks($playlist_id);
    }

    public function searchSong ($keyword, $update) {
        return $this->genericRepository->searchSong($keyword, $update);
    }

    public function getValueScreenDetails () {
        return $this->genericRepository->getValueScreenDetails();
    }

    public function add_playlist_recent ($params) {
        return $this->genericRepository->add_playlist_recent($params);
    }

    public function getFeedbackCategory () {
        return $this->genericRepository->getFeedbackCategory();
    }

    public function Feedback ($params) {
        return $this->genericRepository->Feedback($params);
    }

    public function viewRecentPlaylist () {
        return $this->genericRepository->viewRecentPlaylist();
    }

    public function addPlaylistFavorite ($params) {
        return $this->genericRepository->addPlaylistFavorite($params);
    }

    public function removePlaylistFavorite ($params) {
        return $this->genericRepository->removePlaylistFavorite($params);
    }

    public function viewPlaylistFavorite ($params) {
        return $this->genericRepository->viewPlaylistFavorite($params);
    }

    public function accountSetting ($params) {
        return $this->genericRepository->accountSetting($params);
    }

    public function registerUserDevice ($params) {
        return $this->genericRepository->registerUserDevice($params);
    }

    public function getPreferenceOne () {
        return $this->genericRepository->getPreferenceOne();
    }

    public function getPreferenceTwo () {
        return $this->genericRepository->getPreferenceTwo();
    }

    public function updateUserPreferenceOne ($params) {
        return $this->genericRepository->updateUserPreferenceOne($params);
    }

    public function updateUserPreferenceTwo ($params) {
        return $this->genericRepository->updateUserPreferenceTwo($params);
    }

    public function getUserPreference () {
        return $this->genericRepository->getUserPreference();
    }

    public function checkFavourite ($params) {
        return $this->genericRepository->checkFavourite($params);
    }

    public function LikeDislike ($params) {
        return $this->genericRepository->LikeDislike($params);
    }

    public function LikeDislikeData ($params) {
        return $this->genericRepository->LikeDislikeData($params);
    }

    public function rateTrack ($params) {
        return $this->genericRepository->rateTrack($params);
    }

    public function viewRateTrack ($params) {
        return $this->genericRepository->viewRateTrack($params);
    }

    public function parentCategories () {
        return $this->genericRepository->parentCategories();
    }

    public function Categories ($params) {
        return $this->genericRepository->Categories($params);
    }

    public function categoryPlaylist ($params) {
        return $this->genericRepository->categoryPlaylist($params);
    }

    public function getCMS ($params) {
        return $this->genericRepository->getCMS($params);
    }

    public function allPlaylistSongs () {
        return $this->genericRepository->allPlaylistSongs();
    }

    public function tellAFriend ($params) {
        return $this->genericRepository->tellAFriend($params);
    }

    public function trackListen ($params) {
        return $this->genericRepository->trackListen($params);
    }

    public function trendySearch () {
        return $this->genericRepository->trendySearch();
    }

    public function recentSearch ($params) {
        return $this->genericRepository->recentSearch($params);
    }

    public function skipTrack ($params) {
        return $this->genericRepository->skipTrack($params);
    }

    public function sendPushNotification ($params) {
        return $this->genericRepository->sendPushNotification($params);
    }

    public function Splashboard ($params) {
        return $this->genericRepository->Splashboard($params);
    }

    public function getTracksById ($params) {
        return $this->genericRepository->getTracksById($params);
    }

    public function getPlaylistById ($params) {
        return $this->genericRepository->getPlaylistById($params);
    }
    
}
