<?php

namespace Api\Mobile\Requests;

use Infrastructure\Http\ApiRequest;

class UpdateUserPreferenceOneRequest extends ApiRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'preference' => 'array|required',
            'preference.*.id' => 'required|numeric',
        ];
    }
}
