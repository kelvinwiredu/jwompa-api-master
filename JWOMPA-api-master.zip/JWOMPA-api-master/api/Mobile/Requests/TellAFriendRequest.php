<?php

namespace Api\Mobile\Requests;

use Infrastructure\Http\ApiRequest;

class TellAFriendRequest extends ApiRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'email_first' => 'required|email',
            'email_second' => 'nullable|email',
            'email_third' => 'nullable|email',
            'email_fourth' => 'nullable|email',
            'email_five' => 'nullable|email',
        ];
    }
}
