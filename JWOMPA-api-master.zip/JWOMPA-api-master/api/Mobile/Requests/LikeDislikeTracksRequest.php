<?php

namespace Api\Mobile\Requests;

use Infrastructure\Http\ApiRequest;

class LikeDislikeTracksRequest extends ApiRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'track_id' => 'required|numeric',
            'type' => 'required|numeric'
        ];
    }
}
