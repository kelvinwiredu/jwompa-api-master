<?php

namespace Api\Mobile\Requests;

use Infrastructure\Http\ApiRequest;

class GetPlaylistByIdRequest extends ApiRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'playlist_id' => 'required|numeric',
        ];
    }
}
