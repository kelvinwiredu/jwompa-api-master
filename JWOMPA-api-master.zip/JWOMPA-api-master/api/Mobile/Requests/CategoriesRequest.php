<?php

namespace Api\Mobile\Requests;

use Infrastructure\Http\ApiRequest;

class CategoriesRequest extends ApiRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'pcat_id' => 'required|numeric',
        ];
    }
}
