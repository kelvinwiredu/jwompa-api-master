<?php

namespace Api\Mobile\Requests;

use Infrastructure\Http\ApiRequest;

class AccountSettingRequest extends ApiRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'email' => 'required|email',
            'password' => 'required',
            'first_name' => 'required',
            'last_name' => 'required',
            'gender' => 'required',
            'originalcountry' => 'required',
            'dob' => 'required',
            'currentcountry' => 'required',
            'language' => 'required'
        ];
    }
}
