<?php

namespace Api\Mobile\Requests;

use Infrastructure\Http\ApiRequest;

class FeedbackRequest extends ApiRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'subject' => 'required',
            'feedback_cat' => 'required|numeric',
            'message' => 'required'
        ];
    }
}
