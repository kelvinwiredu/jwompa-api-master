<?php

namespace Api\Mobile\Requests;

use Infrastructure\Http\ApiRequest;

class GetCMSRequest extends ApiRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'type' => 'required|string',
        ];
    }
}
