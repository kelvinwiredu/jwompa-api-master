<?php

namespace Api\Mobile\Requests;

use Infrastructure\Http\ApiRequest;

class RegisterUserDeviceRequest extends ApiRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'os' => 'required',
            'device_id' => 'required',
        ];
    }
}
