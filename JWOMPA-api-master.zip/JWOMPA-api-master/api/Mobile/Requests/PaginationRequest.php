<?php

namespace Api\Mobile\Requests;

use Infrastructure\Http\ApiRequest;

class PaginationRequest extends ApiRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'page' => 'nullable|numeric',
            'limit' => 'nullable|numeric'
        ];
    }
}
