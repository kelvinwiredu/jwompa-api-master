<?php

namespace Api\Mobile\Requests;

use Infrastructure\Http\ApiRequest;

class SkipTrackRequest extends ApiRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'playlist_id' => 'required|numeric',
            'track_id' => 'required|numeric',
        ];
    }
}
