<?php

namespace Api\Mobile\Console;

use Api\Mobile\Repositories\GenericRepository;
use Illuminate\Console\Command;

class ScheduleNotificationCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'push:notification';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Push Notification To User';

    /**
     * User repository to persist user in database
     *
     * @var GenericRepository
     */
    protected $genericRepository;

    /**
     * Create a new command instance.
     *
     * @param  GenericRepository  $genericRepository
     * @return void
     */
    public function __construct(GenericRepository $genericRepository)
    {
        parent::__construct();

        $this->genericRepository = $genericRepository;
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {

        $this->genericRepository->profileCompletionNotification();

        $this->info(sprintf('Command Executed Successfully'));
    }
}