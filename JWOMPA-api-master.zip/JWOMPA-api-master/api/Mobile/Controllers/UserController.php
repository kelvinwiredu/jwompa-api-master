<?php

namespace Api\Mobile\Controllers;

use Illuminate\Http\Request;
use Infrastructure\Http\Controller;
use Api\Mobile\Services\GenericService;

//Requests
use Api\Mobile\Requests\AccountSettingRequest;
use Api\Mobile\Requests\CreateUserRequest;
use Api\Mobile\Requests\GetPlaylistTracksRequest;
use Api\Mobile\Requests\SearchSongRequest;
use Api\Mobile\Requests\RegisterUserDeviceRequest;
use Api\Mobile\Requests\UpdateUserPreferenceOneRequest;
use Api\Mobile\Requests\TellAFriendRequest;
use Api\Mobile\Requests\TrackListenRequest;
use Api\Mobile\Requests\SkipTrackRequest;

use Validator;

/**
 * @resource Playlist
 *
 * 
 */
class UserController extends Controller
{
    private $genericService;

    public function __construct(GenericService $genericService)
    {
        $this->genericService = $genericService;
    }

    /**
     * Account Setting
     */
    public function accountSetting (AccountSettingRequest $request) {
        $params = $request->all();
        $response = $this->genericService->accountSetting($params);
        return response($response);
    }

    /**
     * Register User Device
     */
    public function registerUserDevice (RegisterUserDeviceRequest $request) {
        $params = $request->all();
        $response = $this->genericService->registerUserDevice($params);
        return response($response);
    }

    /**
     * Get Preference One
     */
    public function getPreferenceOne (Request $request) {
        $preference1 = $this->genericService->getPreferenceOne();
        return response($preference1);
    }

    /**
     * Get Preference Two
     */
    public function getPreferenceTwo (Request $request) {
        $preference2 = $this->genericService->getPreferenceTwo();
        return response($preference2);
    }

    /**
     * Update User Preference One
     */
    public function updateUserPreferenceOne (UpdateUserPreferenceOneRequest $request) {
        $params = $request->all();
        $response = $this->genericService->updateUserPreferenceOne($params);
        return response($response);
    }

    /**
     * Update User Preference Two
     */
    public function updateUserPreferenceTwo (UpdateUserPreferenceOneRequest $request) {
        $params = $request->all();
        $response = $this->genericService->updateUserPreferenceTwo($params);
        return response($response);
    }

    /**
     * Get User Preference
     */
    public function getUserPreference (Request $request) {
        $user_preference = $this->genericService->getUserPreference();
        return response($user_preference);
    }

    /**
     * Tell a Friend
     */
    public function tellAFriend (TellAFriendRequest $request) {
        $params = $request->all();
        $response = $this->genericService->tellAFriend($params);
        return response($response);
    }

    /**
     * Track Listen
     */
    public function trackListen (TrackListenRequest $request) {
        $params = $request->all();
        $response = $this->genericService->trackListen($params);
        return response($response);
    }

    /**
     * Recent Search
     */
    public function recentSearch (Request $request) {
        $params = $request->all();
        $response = $this->genericService->recentSearch($params);
        return response($response);
    }

    /**
     * Skip Track
     */
    public function skipTrack (SkipTrackRequest $request) {
        $params = $request->all();
        $response = $this->genericService->skipTrack($params);
        return response($response);
    }

    /**
     * Send Push Notification
     */
    public function sendPushNotification (Request $request) {
        $params = $request->all();
        $response = $this->genericService->sendPushNotification($params);
        return response($response);
    }

}
