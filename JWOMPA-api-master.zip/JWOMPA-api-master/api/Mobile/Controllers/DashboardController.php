<?php

namespace Api\Mobile\Controllers;

use Illuminate\Http\Request;
use Infrastructure\Http\Controller;
use Api\Mobile\Requests\CreateUserRequest;
use Api\Mobile\Requests\GetPlaylistTracksRequest;
use Api\Mobile\Requests\SearchSongRequest;
use Api\Mobile\Services\GenericService;

//Requests
use Api\Mobile\Requests\FeedbackRequest;
use Api\Mobile\Requests\GetCMSRequest;

use Validator;

/**
 * @resource Playlist
 *
 * 
 */
class DashboardController extends Controller
{
    private $genericService;

    public function __construct(GenericService $genericService)
    {
        $this->genericService = $genericService;
    }

    /**
     * Get Playlist
     */
    public function getPlayList (Request $request) {
        $playlists = $this->genericService->getPlayList();
        return response($playlists);
    }

    /**
     * Get Value Screen Details
     */
    public function getValueScreenDetails (Request $request) {
        $value_screen_details = $this->genericService->getValueScreenDetails();
        return response($value_screen_details);
    }

    /**
     * Get Feedback Category
     */
    public function getFeedbackCategory (Request $request) {
        $feedback_category = $this->genericService->getFeedbackCategory();
        return response($feedback_category);
    }

    /**
     * Submit Feedback
     */
    public function Feedback (FeedbackRequest $request) {
        $params = $request->all();
        $response = $this->genericService->Feedback($params);
        return response($response);
    }

    /**
     * CMS
     */
    public function getCMS (GetCMSRequest $request) {
        $params = $request->all();
        $response = $this->genericService->getCMS($params);
        return response($response);
    }

}
