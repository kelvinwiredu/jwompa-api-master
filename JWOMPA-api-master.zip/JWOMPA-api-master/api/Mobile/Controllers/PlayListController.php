<?php

namespace Api\Mobile\Controllers;

use Illuminate\Http\Request;
use Infrastructure\Http\Controller;
use Api\Mobile\Requests\CreateUserRequest;
use Api\Mobile\Requests\GetPlaylistTracksRequest;
use Api\Mobile\Requests\SearchSongRequest;
use Api\Mobile\Requests\LikeDislikeTracksRequest;
use Api\Mobile\Requests\LikeDislikeDataRequest;
use Api\Mobile\Requests\RateTrackRequest;
use Api\Mobile\Requests\ViewRateTrackRequest;
use Api\Mobile\Requests\CategoriesRequest;
use Api\Mobile\Requests\CategoryPlaylistRequest;
use Api\Mobile\Requests\PaginationRequest;
use Api\Mobile\Requests\GetTrackByIdRequest;
use Api\Mobile\Requests\GetPlaylistByIdRequest;

use Api\Mobile\Services\GenericService;

use Validator;

/**
 * @resource Playlist
 *
 * 
 */
class PlayListController extends Controller
{
    private $genericService;

    public function __construct(GenericService $genericService)
    {
        $this->genericService = $genericService;
    }

    /**
     * Get Playlist
     */
    public function getPlayList (Request $request) {
        $playlists = $this->genericService->getPlayList();
        return response($playlists);
    }

    /**
     * Get Playlist Tracks
     */
    public function getPlaylistTracks (GetPlaylistTracksRequest $request) {
        $validator = Validator::make($request->all(), [
            'playlist_id' => 'required'
        ]);
        if($validator->errors()->all()) {
            $data['status_code']    =   0;
            $data['status_text']    =   'Failed';
            $data['message']        =   $validator->errors()->first();
        }
        else {
            $playlist_id = $request->get('playlist_id');
            $playlist_tracks = $this->genericService->getPlaylistTracks($playlist_id);
            $data = $playlist_tracks;
        }
        return response($data);
    }

    /**
     * Search Song/PlayList
     */
    public function searchSong (SearchSongRequest $request) {
        $validator = Validator::make($request->all(), [
            'keyword' => 'required',
            'update' => 'required',
        ]);
        if($validator->errors()->all()) {
            $data['status_code']    =   0;
            $data['status_text']    =   'Failed';
            $data['message']        =   $validator->errors()->first();
        }
        else {
            $keyword = $request->get('keyword');
            $update = $request->get('update');
            $songs = $this->genericService->searchSong($keyword, $update);
            $data = $songs;
        }
        return response($data);
    }

    /**
     * Add Playlist Recent
     */
    public function add_playlist_recent (GetPlaylistTracksRequest $request) {
        $params = $request->all();
        $response = $this->genericService->add_playlist_recent($params);
        return response($response);
    }

    /**
     * View Recent Playlist
     */
    public function viewRecentPlaylist (Request $request) {
        $response = $this->genericService->viewRecentPlaylist();
        return response($response);
    }

    /**
     * Add Playlist Favorite
     */
    public function addPlaylistFavorite (GetPlaylistTracksRequest $request) {
        $params = $request->all();
        $response = $this->genericService->addPlaylistFavorite($params);
        return response($response);
    }

    /**
     * Remove Playlist Favorite
     */
    public function removePlaylistFavorite (GetPlaylistTracksRequest $request) {
        $params = $request->all();
        $response = $this->genericService->removePlaylistFavorite($params);
        return response($response);
    }

    /**
     * View Playlist Favorite
     */
    public function viewPlaylistFavorite (Request $request) {
        $params = $request->all();
        $response = $this->genericService->viewPlaylistFavorite($params);
        return response($response);
    }

    /**
     * Check Playlist Favorite
     */
    public function checkFavourite (GetPlaylistTracksRequest $request) {
        $params = $request->all();
        $response = $this->genericService->checkFavourite($params);
        return response($response);
    }

    /**
     * Like Dislike Tracks
     */
    public function LikeDislike (LikeDislikeTracksRequest $request) {
        $params = $request->all();
        $response = $this->genericService->LikeDislike($params);
        return response($response);
    }

    /**
     * Like Dislike Data
     */
    public function LikeDislikeData (LikeDislikeDataRequest $request) {
        $params = $request->all();
        $response = $this->genericService->LikeDislikeData($params);
        return response($response);
    }

    /**
     * Rate Track
     */
    public function rateTrack (RateTrackRequest $request) {
        $params = $request->all();
        $response = $this->genericService->rateTrack($params);
        return response($response);
    }

    /**
     * View Rate Track
     */
    public function viewRateTrack (ViewRateTrackRequest $request) {
        $params = $request->all();
        $response = $this->genericService->viewRateTrack($params);
        return response($response);
    }

    /**
     * Get Parent Categories
     */
    public function parentCategories (Request $request) {
        $parent_categories = $this->genericService->parentCategories();
        return response($parent_categories);
    }

    /**
     * Get Categories
     */
    public function Categories (CategoriesRequest $request) {
        $params = $request->all();
        $categories = $this->genericService->Categories($params);
        return response($categories);
    }

    /**
     * Get Category Playlist
     */
    public function categoryPlaylist (CategoryPlaylistRequest $request) {
        $params = $request->all();
        $category_playlist = $this->genericService->categoryPlaylist($params);
        return response($category_playlist);
    }

    /**
     * All Playlist Songs
     */
    public function allPlaylistSongs (Request $request) {
        $all_playlist_songs = $this->genericService->allPlaylistSongs();
        return response($all_playlist_songs);
    }

    /**
     * Trendy Search
     */
    public function trendySearch (Request $request) {
        $trendy_search = $this->genericService->trendySearch();
        return response($trendy_search);
    }

    /**
     * Splash Board
     */
    public function Splashboard (PaginationRequest $request) {
        $params = $request->all();
        $splashboard_playlist = $this->genericService->Splashboard($params);
        return response($splashboard_playlist);
    }

    /**
     * Get Track By Id
     */
    public function getTracksById (GetTrackByIdRequest $request) {
        $params = $request->all();
        $track = $this->genericService->getTracksById($params);
        return response($track);
    }

    /**
     * Get Playlist By Id
     */
    public function getPlaylistById (GetPlaylistByIdRequest $request) {
        $params = $request->all();
        $playlist = $this->genericService->getPlaylistById($params);
        return response($playlist);
    }

}
